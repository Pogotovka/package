#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class SharedApollo_apiCompiledField, SharedApollo_apiCustomScalarAdapters, SharedCountriesQueryCompanion, SharedCountriesQueryCountry, SharedCountriesQueryData, SharedGetCountryInfoQueryCompanion, SharedGetCountryInfoQuery, SharedGetCountryInfoQueryCountry, SharedGetCountryInfoQueryLanguage, SharedGetCountryInfoQueryData, SharedCountriesQuery_ResponseAdapter, SharedCountriesQuery_ResponseAdapterCountry, SharedCountriesQuery_ResponseAdapterData, SharedGetCountryInfoQuery_ResponseAdapter, SharedGetCountryInfoQuery_ResponseAdapterCountry, SharedGetCountryInfoQuery_ResponseAdapterData, SharedGetCountryInfoQuery_ResponseAdapterLanguage, SharedGetCountryInfoQuery_VariablesAdapter, SharedAppDatabaseQueries, SharedAppDatabaseCompanion, SharedKotlinUnit, SharedRuntimeTransacterTransaction, SharedKotlinThrowable, SharedRuntimeBaseTransacterImpl, SharedRuntimeTransacterImpl, SharedCountryListEntity, SharedRuntimeQuery<__covariant RowType>, SharedKoin_coreKoin, SharedFailure, SharedArrow_coreEither<__covariant A, __covariant B>, SharedKotlinNothing, SharedKotlinArray<T>, SharedKotlinException, SharedFailureNoConnection, SharedFailureNoData, SharedApollo_apiError, SharedFailureServerError, SharedFailureUnknownError, SharedApollo_apiHttpRequest, SharedApollo_apiHttpResponse, SharedApollo_runtimeApolloClient, SharedApollo_apiApolloRequest<D>, SharedCountriesQuerySelections, SharedApollo_apiCompiledSelection, SharedGetCountryInfoQuerySelections, SharedCountryCompanion, SharedApollo_apiObjectType, SharedGraphQLBooleanCompanion, SharedApollo_apiCustomScalarType, SharedGraphQLFloatCompanion, SharedGraphQLIDCompanion, SharedGraphQLIntCompanion, SharedGraphQLStringCompanion, SharedLanguageCompanion, SharedQueryCompanion, SharedApollo_apiCompiledArgumentDefinition, SharedDatabaseDriverFactory, SharedArrow_coreEitherCompanion, SharedArrow_coreOption<__covariant A>, SharedArrow_coreValidated<__covariant E, __covariant A>, SharedArrow_coreIor<__covariant A, __covariant B>, SharedKoin_coreKoinApplication, SharedKoin_coreModule, SharedApollo_apiOptional<__covariant V>, SharedApollo_apiExecutableVariables, SharedApollo_apiCompiledArgument, SharedApollo_apiCompiledFieldBuilder, SharedApollo_apiCompiledCondition, SharedApollo_apiCompiledType, SharedApollo_apiJsonNumber, SharedApollo_apiCustomScalarAdaptersKey, SharedApollo_apiCustomScalarAdaptersBuilder, SharedApollo_apiDeferredFragmentIdentifier, SharedApollo_apiJsonReaderToken, SharedRuntimeAfterVersion, SharedRuntimeExecutableQuery<__covariant RowType>, SharedKoin_coreScope, SharedKoin_coreParametersHolder, SharedKotlinLazyThreadSafetyMode, SharedKoin_coreLogger, SharedKoin_coreExtensionManager, SharedKoin_coreInstanceRegistry, SharedKoin_corePropertyRegistry, SharedKoin_coreScopeRegistry, SharedApollo_apiErrorLocation, SharedKotlinRuntimeException, SharedKotlinIllegalStateException, SharedApollo_apiHttpRequestBuilder, SharedApollo_apiHttpMethod, SharedApollo_apiHttpHeader, SharedApollo_apiHttpResponseBuilder, SharedApollo_runtimeApolloClientCompanion, SharedApollo_runtimeApolloCall<D>, SharedApollo_runtimeApolloClientBuilder, SharedApollo_apiApolloRequestBuilder<D>, SharedUuidUuid, SharedApollo_apiCompiledNamedType, SharedApollo_apiObjectTypeBuilder, SharedApollo_apiInterfaceType, SharedApollo_apiCompiledArgumentDefinitionBuilder, SharedArrow_coreOptionCompanion, SharedKotlinPair<__covariant A, __covariant B>, SharedArrow_coreEval<__covariant A>, SharedArrow_coreValidatedCompanion, SharedArrow_coreIorCompanion, SharedKoin_coreKoinApplicationCompanion, SharedKoin_coreLevel, SharedKoin_coreKoinDefinition<R>, SharedKoin_coreInstanceFactory<T>, SharedKoin_coreSingleInstanceFactory<T>, SharedKoin_coreScopeDSL, SharedApollo_apiOptionalCompanion, SharedKotlinEnumCompanion, SharedKotlinEnum<E>, SharedKotlinByteArray, SharedKoin_coreLockable, SharedStately_concurrencyThreadLocalRef<T>, SharedKoin_coreScopeRegistryCompanion, SharedOkioByteString, SharedOkioBuffer, SharedOkioTimeout, SharedApollo_apiApolloResponse<D>, SharedKotlinx_coroutines_coreCoroutineDispatcher, SharedApollo_apiInterfaceTypeBuilder, SharedArrow_coreEvalCompanion, SharedKoin_coreBeanDefinition<T>, SharedKoin_coreInstanceFactoryCompanion, SharedKoin_coreInstanceContext, SharedApollo_apiOptionalAbsent, SharedApollo_apiOptionalPresent<V>, SharedKotlinByteIterator, SharedOkioByteStringCompanion, SharedOkioBufferUnsafeCursor, SharedOkioTimeoutCompanion, SharedApollo_apiApolloResponseBuilder<D>, SharedApollo_apiApolloException, SharedKotlinAbstractCoroutineContextElement, SharedKotlinx_coroutines_coreCoroutineDispatcherKey, SharedApollo_runtimeWsProtocol, SharedArrow_coreEvalAlways<__covariant A>, SharedArrow_coreEvalLater<__covariant A>, SharedKoin_coreKind, SharedKoin_coreCallbacks<T>, NSData, SharedKotlinAbstractCoroutineContextKey<B, E>, SharedApollo_runtimeWsFrameType;

@protocol SharedApollo_apiAdapter, SharedApollo_apiJsonWriter, SharedApollo_apiExecutable, SharedApollo_apiOperation, SharedApollo_apiQuery, SharedApollo_apiExecutableData, SharedApollo_apiOperationData, SharedApollo_apiQueryData, SharedApollo_apiJsonReader, SharedRuntimeTransactionWithoutReturn, SharedRuntimeTransactionWithReturn, SharedRuntimeTransacterBase, SharedRuntimeTransacter, SharedAppDatabase, SharedRuntimeSqlDriver, SharedRuntimeSqlSchema, SharedKoin_coreKoinComponent, SharedApollo_runtimeHttpInterceptorChain, SharedApollo_runtimeHttpInterceptor, SharedIDynamicApolloClient, SharedKotlinx_coroutines_coreFlow, SharedApollo_runtimeApolloInterceptorChain, SharedApollo_runtimeApolloInterceptor, SharedIBookTripRepository, SharedICountryUseCase, SharedArrow_coreMonoid, SharedKotlinSuspendFunction0, SharedApollo_apiUpload, SharedOkioCloseable, SharedApollo_apiExecutionContextKey, SharedApollo_apiExecutionContextElement, SharedApollo_apiExecutionContext, SharedRuntimeTransactionCallbacks, SharedRuntimeQueryListener, SharedRuntimeQueryResult, SharedRuntimeSqlPreparedStatement, SharedRuntimeSqlCursor, SharedRuntimeCloseable, SharedKoin_coreKoinScopeComponent, SharedKoin_coreQualifier, SharedKotlinKClass, SharedKotlinLazy, SharedKotlinIterator, SharedApollo_apiHttpBody, SharedOkioBufferedSource, SharedApollo_apiExecutionOptions, SharedApollo_apiMutationData, SharedApollo_apiMutation, SharedApollo_apiSubscriptionData, SharedApollo_apiSubscription, SharedApollo_runtimeNetworkTransport, SharedKotlinx_coroutines_coreFlowCollector, SharedArrow_coreSemigroup, SharedKotlinFunction, SharedOkioBufferedSink, SharedKotlinComparable, SharedKoin_coreScopeCallback, SharedKotlinKDeclarationContainer, SharedKotlinKAnnotatedElement, SharedKotlinKClassifier, SharedKoin_coreKoinExtension, SharedOkioSink, SharedOkioSource, SharedApollo_apiMutableExecutionOptions, SharedApollo_runtimeApolloClientListener, SharedApollo_runtimeHttpEngine, SharedApollo_runtimeNetworkMonitor, SharedApollo_runtimeWebSocketEngine, SharedKotlinSuspendFunction2, SharedApollo_runtimeWsProtocolFactory, SharedKotlinCoroutineContextKey, SharedKotlinCoroutineContextElement, SharedKotlinCoroutineContext, SharedKotlinContinuation, SharedKotlinContinuationInterceptor, SharedKotlinx_coroutines_coreRunnable, SharedApollo_runtimeWebSocketConnection, SharedApollo_runtimeWsProtocolListener, SharedKotlinx_coroutines_coreCoroutineScope;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface SharedBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface SharedBase (SharedBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface SharedMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface SharedMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorSharedKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface SharedNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface SharedByte : SharedNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface SharedUByte : SharedNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface SharedShort : SharedNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface SharedUShort : SharedNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface SharedInt : SharedNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface SharedUInt : SharedNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface SharedLong : SharedNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface SharedULong : SharedNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface SharedFloat : SharedNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface SharedDouble : SharedNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface SharedBoolean : SharedNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end

__attribute__((swift_name("Apollo_apiExecutable")))
@protocol SharedApollo_apiExecutable
@required
- (id<SharedApollo_apiAdapter>)adapter __attribute__((swift_name("adapter()")));
- (SharedApollo_apiCompiledField *)rootField __attribute__((swift_name("rootField()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)serializeVariablesWriter:(id<SharedApollo_apiJsonWriter>)writer customScalarAdapters:(SharedApollo_apiCustomScalarAdapters *)customScalarAdapters withDefaultValues:(BOOL)withDefaultValues error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("serializeVariables(writer:customScalarAdapters:withDefaultValues:)")));
@property (readonly) BOOL ignoreErrors __attribute__((swift_name("ignoreErrors")));
@end

__attribute__((swift_name("Apollo_apiOperation")))
@protocol SharedApollo_apiOperation <SharedApollo_apiExecutable>
@required
- (NSString *)document __attribute__((swift_name("document()")));
- (NSString *)id __attribute__((swift_name("id()")));
- (NSString *)name __attribute__((swift_name("name()")));
@end

__attribute__((swift_name("Apollo_apiQuery")))
@protocol SharedApollo_apiQuery <SharedApollo_apiOperation>
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CountriesQuery")))
@interface SharedCountriesQuery : SharedBase <SharedApollo_apiQuery>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) SharedCountriesQueryCompanion *companion __attribute__((swift_name("companion")));
- (id<SharedApollo_apiAdapter>)adapter __attribute__((swift_name("adapter()")));
- (NSString *)document __attribute__((swift_name("document()")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)id __attribute__((swift_name("id()")));
- (NSString *)name __attribute__((swift_name("name()")));
- (SharedApollo_apiCompiledField *)rootField __attribute__((swift_name("rootField()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)serializeVariablesWriter:(id<SharedApollo_apiJsonWriter>)writer customScalarAdapters:(SharedApollo_apiCustomScalarAdapters *)customScalarAdapters withDefaultValues:(BOOL)withDefaultValues error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("serializeVariables(writer:customScalarAdapters:withDefaultValues:)")));
@property (readonly) BOOL ignoreErrors __attribute__((swift_name("ignoreErrors")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CountriesQuery.Companion")))
@interface SharedCountriesQueryCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedCountriesQueryCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *OPERATION_DOCUMENT __attribute__((swift_name("OPERATION_DOCUMENT")));
@property (readonly) NSString *OPERATION_ID __attribute__((swift_name("OPERATION_ID")));
@property (readonly) NSString *OPERATION_NAME __attribute__((swift_name("OPERATION_NAME")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CountriesQuery.Country")))
@interface SharedCountriesQueryCountry : SharedBase
- (instancetype)initWithName:(NSString * _Nullable)name emojiU:(NSString * _Nullable)emojiU currency:(NSString * _Nullable)currency __attribute__((swift_name("init(name:emojiU:currency:)"))) __attribute__((objc_designated_initializer));
- (SharedCountriesQueryCountry *)doCopyName:(NSString * _Nullable)name emojiU:(NSString * _Nullable)emojiU currency:(NSString * _Nullable)currency __attribute__((swift_name("doCopy(name:emojiU:currency:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable currency __attribute__((swift_name("currency")));
@property (readonly) NSString * _Nullable emojiU __attribute__((swift_name("emojiU")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@end

__attribute__((swift_name("Apollo_apiExecutableData")))
@protocol SharedApollo_apiExecutableData
@required
@end

__attribute__((swift_name("Apollo_apiOperationData")))
@protocol SharedApollo_apiOperationData <SharedApollo_apiExecutableData>
@required
@end

__attribute__((swift_name("Apollo_apiQueryData")))
@protocol SharedApollo_apiQueryData <SharedApollo_apiOperationData>
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CountriesQuery.Data")))
@interface SharedCountriesQueryData : SharedBase <SharedApollo_apiQueryData>
- (instancetype)initWithCountries:(NSArray<id> * _Nullable)countries __attribute__((swift_name("init(countries:)"))) __attribute__((objc_designated_initializer));
- (SharedCountriesQueryData *)doCopyCountries:(NSArray<id> * _Nullable)countries __attribute__((swift_name("doCopy(countries:)")));
- (NSArray<SharedCountriesQueryCountry *> * _Nullable)countriesFilterNotNull __attribute__((swift_name("countriesFilterNotNull()")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<id> * _Nullable countries __attribute__((swift_name("countries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetCountryInfoQuery")))
@interface SharedGetCountryInfoQuery : SharedBase <SharedApollo_apiQuery>
- (instancetype)initWithCountryCode:(NSString *)countryCode __attribute__((swift_name("init(countryCode:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedGetCountryInfoQueryCompanion *companion __attribute__((swift_name("companion")));
- (id<SharedApollo_apiAdapter>)adapter __attribute__((swift_name("adapter()")));
- (SharedGetCountryInfoQuery *)doCopyCountryCode:(NSString *)countryCode __attribute__((swift_name("doCopy(countryCode:)")));
- (NSString *)document __attribute__((swift_name("document()")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)id __attribute__((swift_name("id()")));
- (NSString *)name __attribute__((swift_name("name()")));
- (SharedApollo_apiCompiledField *)rootField __attribute__((swift_name("rootField()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)serializeVariablesWriter:(id<SharedApollo_apiJsonWriter>)writer customScalarAdapters:(SharedApollo_apiCustomScalarAdapters *)customScalarAdapters withDefaultValues:(BOOL)withDefaultValues error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("serializeVariables(writer:customScalarAdapters:withDefaultValues:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *countryCode __attribute__((swift_name("countryCode")));
@property (readonly) BOOL ignoreErrors __attribute__((swift_name("ignoreErrors")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetCountryInfoQuery.Companion")))
@interface SharedGetCountryInfoQueryCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedGetCountryInfoQueryCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *OPERATION_DOCUMENT __attribute__((swift_name("OPERATION_DOCUMENT")));
@property (readonly) NSString *OPERATION_ID __attribute__((swift_name("OPERATION_ID")));
@property (readonly) NSString *OPERATION_NAME __attribute__((swift_name("OPERATION_NAME")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetCountryInfoQuery.Country")))
@interface SharedGetCountryInfoQueryCountry : SharedBase
- (instancetype)initWithName:(NSString * _Nullable)name native:(NSString * _Nullable)native emoji:(NSString * _Nullable)emoji currency:(NSString * _Nullable)currency languages:(NSArray<id> * _Nullable)languages __attribute__((swift_name("init(name:native:emoji:currency:languages:)"))) __attribute__((objc_designated_initializer));
- (SharedGetCountryInfoQueryCountry *)doCopyName:(NSString * _Nullable)name native:(NSString * _Nullable)native emoji:(NSString * _Nullable)emoji currency:(NSString * _Nullable)currency languages:(NSArray<id> * _Nullable)languages __attribute__((swift_name("doCopy(name:native:emoji:currency:languages:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSArray<SharedGetCountryInfoQueryLanguage *> * _Nullable)languagesFilterNotNull __attribute__((swift_name("languagesFilterNotNull()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable currency __attribute__((swift_name("currency")));
@property (readonly) NSString * _Nullable emoji __attribute__((swift_name("emoji")));
@property (readonly) NSArray<id> * _Nullable languages __attribute__((swift_name("languages")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@property (readonly) NSString * _Nullable native __attribute__((swift_name("native")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetCountryInfoQuery.Data")))
@interface SharedGetCountryInfoQueryData : SharedBase <SharedApollo_apiQueryData>
- (instancetype)initWithCountry:(SharedGetCountryInfoQueryCountry * _Nullable)country __attribute__((swift_name("init(country:)"))) __attribute__((objc_designated_initializer));
- (SharedGetCountryInfoQueryData *)doCopyCountry:(SharedGetCountryInfoQueryCountry * _Nullable)country __attribute__((swift_name("doCopy(country:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SharedGetCountryInfoQueryCountry * _Nullable country __attribute__((swift_name("country")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetCountryInfoQuery.Language")))
@interface SharedGetCountryInfoQueryLanguage : SharedBase
- (instancetype)initWithCode:(NSString * _Nullable)code name:(NSString * _Nullable)name __attribute__((swift_name("init(code:name:)"))) __attribute__((objc_designated_initializer));
- (SharedGetCountryInfoQueryLanguage *)doCopyCode:(NSString * _Nullable)code name:(NSString * _Nullable)name __attribute__((swift_name("doCopy(code:name:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable code __attribute__((swift_name("code")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CountriesQuery_ResponseAdapter")))
@interface SharedCountriesQuery_ResponseAdapter : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)countriesQuery_ResponseAdapter __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedCountriesQuery_ResponseAdapter *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("Apollo_apiAdapter")))
@protocol SharedApollo_apiAdapter
@required

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id _Nullable)fromJsonReader:(id<SharedApollo_apiJsonReader>)reader customScalarAdapters:(SharedApollo_apiCustomScalarAdapters *)customScalarAdapters error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("fromJson(reader:customScalarAdapters:)"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)toJsonWriter:(id<SharedApollo_apiJsonWriter>)writer customScalarAdapters:(SharedApollo_apiCustomScalarAdapters *)customScalarAdapters value:(id _Nullable)value error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("toJson(writer:customScalarAdapters:value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CountriesQuery_ResponseAdapter.Country")))
@interface SharedCountriesQuery_ResponseAdapterCountry : SharedBase <SharedApollo_apiAdapter>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)country __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedCountriesQuery_ResponseAdapterCountry *shared __attribute__((swift_name("shared")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (SharedCountriesQueryCountry * _Nullable)fromJsonReader:(id<SharedApollo_apiJsonReader>)reader customScalarAdapters:(SharedApollo_apiCustomScalarAdapters *)customScalarAdapters error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("fromJson(reader:customScalarAdapters:)"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)toJsonWriter:(id<SharedApollo_apiJsonWriter>)writer customScalarAdapters:(SharedApollo_apiCustomScalarAdapters *)customScalarAdapters value:(SharedCountriesQueryCountry *)value error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("toJson(writer:customScalarAdapters:value:)")));
@property (readonly) NSArray<NSString *> *RESPONSE_NAMES __attribute__((swift_name("RESPONSE_NAMES")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CountriesQuery_ResponseAdapter.Data")))
@interface SharedCountriesQuery_ResponseAdapterData : SharedBase <SharedApollo_apiAdapter>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)data __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedCountriesQuery_ResponseAdapterData *shared __attribute__((swift_name("shared")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (SharedCountriesQueryData * _Nullable)fromJsonReader:(id<SharedApollo_apiJsonReader>)reader customScalarAdapters:(SharedApollo_apiCustomScalarAdapters *)customScalarAdapters error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("fromJson(reader:customScalarAdapters:)"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)toJsonWriter:(id<SharedApollo_apiJsonWriter>)writer customScalarAdapters:(SharedApollo_apiCustomScalarAdapters *)customScalarAdapters value:(SharedCountriesQueryData *)value error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("toJson(writer:customScalarAdapters:value:)")));
@property (readonly) NSArray<NSString *> *RESPONSE_NAMES __attribute__((swift_name("RESPONSE_NAMES")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetCountryInfoQuery_ResponseAdapter")))
@interface SharedGetCountryInfoQuery_ResponseAdapter : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)getCountryInfoQuery_ResponseAdapter __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedGetCountryInfoQuery_ResponseAdapter *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetCountryInfoQuery_ResponseAdapter.Country")))
@interface SharedGetCountryInfoQuery_ResponseAdapterCountry : SharedBase <SharedApollo_apiAdapter>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)country __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedGetCountryInfoQuery_ResponseAdapterCountry *shared __attribute__((swift_name("shared")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (SharedGetCountryInfoQueryCountry * _Nullable)fromJsonReader:(id<SharedApollo_apiJsonReader>)reader customScalarAdapters:(SharedApollo_apiCustomScalarAdapters *)customScalarAdapters error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("fromJson(reader:customScalarAdapters:)"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)toJsonWriter:(id<SharedApollo_apiJsonWriter>)writer customScalarAdapters:(SharedApollo_apiCustomScalarAdapters *)customScalarAdapters value:(SharedGetCountryInfoQueryCountry *)value error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("toJson(writer:customScalarAdapters:value:)")));
@property (readonly) NSArray<NSString *> *RESPONSE_NAMES __attribute__((swift_name("RESPONSE_NAMES")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetCountryInfoQuery_ResponseAdapter.Data")))
@interface SharedGetCountryInfoQuery_ResponseAdapterData : SharedBase <SharedApollo_apiAdapter>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)data __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedGetCountryInfoQuery_ResponseAdapterData *shared __attribute__((swift_name("shared")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (SharedGetCountryInfoQueryData * _Nullable)fromJsonReader:(id<SharedApollo_apiJsonReader>)reader customScalarAdapters:(SharedApollo_apiCustomScalarAdapters *)customScalarAdapters error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("fromJson(reader:customScalarAdapters:)"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)toJsonWriter:(id<SharedApollo_apiJsonWriter>)writer customScalarAdapters:(SharedApollo_apiCustomScalarAdapters *)customScalarAdapters value:(SharedGetCountryInfoQueryData *)value error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("toJson(writer:customScalarAdapters:value:)")));
@property (readonly) NSArray<NSString *> *RESPONSE_NAMES __attribute__((swift_name("RESPONSE_NAMES")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetCountryInfoQuery_ResponseAdapter.Language")))
@interface SharedGetCountryInfoQuery_ResponseAdapterLanguage : SharedBase <SharedApollo_apiAdapter>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)language __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedGetCountryInfoQuery_ResponseAdapterLanguage *shared __attribute__((swift_name("shared")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (SharedGetCountryInfoQueryLanguage * _Nullable)fromJsonReader:(id<SharedApollo_apiJsonReader>)reader customScalarAdapters:(SharedApollo_apiCustomScalarAdapters *)customScalarAdapters error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("fromJson(reader:customScalarAdapters:)"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)toJsonWriter:(id<SharedApollo_apiJsonWriter>)writer customScalarAdapters:(SharedApollo_apiCustomScalarAdapters *)customScalarAdapters value:(SharedGetCountryInfoQueryLanguage *)value error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("toJson(writer:customScalarAdapters:value:)")));
@property (readonly) NSArray<NSString *> *RESPONSE_NAMES __attribute__((swift_name("RESPONSE_NAMES")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetCountryInfoQuery_VariablesAdapter")))
@interface SharedGetCountryInfoQuery_VariablesAdapter : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)getCountryInfoQuery_VariablesAdapter __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedGetCountryInfoQuery_VariablesAdapter *shared __attribute__((swift_name("shared")));
- (void)serializeVariablesWriter:(id<SharedApollo_apiJsonWriter>)writer value:(SharedGetCountryInfoQuery *)value customScalarAdapters:(SharedApollo_apiCustomScalarAdapters *)customScalarAdapters withDefaultValues:(BOOL)withDefaultValues __attribute__((swift_name("serializeVariables(writer:value:customScalarAdapters:withDefaultValues:)")));
@end

__attribute__((swift_name("RuntimeTransacterBase")))
@protocol SharedRuntimeTransacterBase
@required
@end

__attribute__((swift_name("RuntimeTransacter")))
@protocol SharedRuntimeTransacter <SharedRuntimeTransacterBase>
@required
- (void)transactionNoEnclosing:(BOOL)noEnclosing body:(void (^)(id<SharedRuntimeTransactionWithoutReturn>))body __attribute__((swift_name("transaction(noEnclosing:body:)")));
- (id _Nullable)transactionWithResultNoEnclosing:(BOOL)noEnclosing bodyWithReturn:(id _Nullable (^)(id<SharedRuntimeTransactionWithReturn>))bodyWithReturn __attribute__((swift_name("transactionWithResult(noEnclosing:bodyWithReturn:)")));
@end

__attribute__((swift_name("AppDatabase")))
@protocol SharedAppDatabase <SharedRuntimeTransacter>
@required
@property (readonly) SharedAppDatabaseQueries *appDatabaseQueries __attribute__((swift_name("appDatabaseQueries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AppDatabaseCompanion")))
@interface SharedAppDatabaseCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedAppDatabaseCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedAppDatabase>)invokeDriver:(id<SharedRuntimeSqlDriver>)driver __attribute__((swift_name("invoke(driver:)")));
@property (readonly) id<SharedRuntimeSqlSchema> Schema __attribute__((swift_name("Schema")));
@end

__attribute__((swift_name("RuntimeBaseTransacterImpl")))
@interface SharedRuntimeBaseTransacterImpl : SharedBase
- (instancetype)initWithDriver:(id<SharedRuntimeSqlDriver>)driver __attribute__((swift_name("init(driver:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (NSString *)createArgumentsCount:(int32_t)count __attribute__((swift_name("createArguments(count:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)notifyQueriesIdentifier:(int32_t)identifier tableProvider:(void (^)(SharedKotlinUnit *(^)(NSString *)))tableProvider __attribute__((swift_name("notifyQueries(identifier:tableProvider:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (id _Nullable)postTransactionCleanupTransaction:(SharedRuntimeTransacterTransaction *)transaction enclosing:(SharedRuntimeTransacterTransaction * _Nullable)enclosing thrownException:(SharedKotlinThrowable * _Nullable)thrownException returnValue:(id _Nullable)returnValue __attribute__((swift_name("postTransactionCleanup(transaction:enclosing:thrownException:returnValue:)")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) id<SharedRuntimeSqlDriver> driver __attribute__((swift_name("driver")));
@end

__attribute__((swift_name("RuntimeTransacterImpl")))
@interface SharedRuntimeTransacterImpl : SharedRuntimeBaseTransacterImpl <SharedRuntimeTransacter>
- (instancetype)initWithDriver:(id<SharedRuntimeSqlDriver>)driver __attribute__((swift_name("init(driver:)"))) __attribute__((objc_designated_initializer));
- (void)transactionNoEnclosing:(BOOL)noEnclosing body:(void (^)(id<SharedRuntimeTransactionWithoutReturn>))body __attribute__((swift_name("transaction(noEnclosing:body:)")));
- (id _Nullable)transactionWithResultNoEnclosing:(BOOL)noEnclosing bodyWithReturn:(id _Nullable (^)(id<SharedRuntimeTransactionWithReturn>))bodyWithReturn __attribute__((swift_name("transactionWithResult(noEnclosing:bodyWithReturn:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AppDatabaseQueries")))
@interface SharedAppDatabaseQueries : SharedRuntimeTransacterImpl
- (instancetype)initWithDriver:(id<SharedRuntimeSqlDriver>)driver __attribute__((swift_name("init(driver:)"))) __attribute__((objc_designated_initializer));
- (void)insertCountryName:(NSString * _Nullable)name native:(NSString * _Nullable)native emoji:(NSString * _Nullable)emoji currency:(NSString * _Nullable)currency __attribute__((swift_name("insertCountry(name:native:emoji:currency:)")));
- (void)removeAllCountries __attribute__((swift_name("removeAllCountries()")));
- (SharedRuntimeQuery<SharedCountryListEntity *> *)selectAllCountries __attribute__((swift_name("selectAllCountries()")));
- (SharedRuntimeQuery<id> *)selectAllCountriesMapper:(id (^)(NSString * _Nullable, NSString * _Nullable, NSString * _Nullable, NSString * _Nullable))mapper __attribute__((swift_name("selectAllCountries(mapper:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CountryListEntity")))
@interface SharedCountryListEntity : SharedBase
- (instancetype)initWithName:(NSString * _Nullable)name native:(NSString * _Nullable)native emoji:(NSString * _Nullable)emoji currency:(NSString * _Nullable)currency __attribute__((swift_name("init(name:native:emoji:currency:)"))) __attribute__((objc_designated_initializer));
- (SharedCountryListEntity *)doCopyName:(NSString * _Nullable)name native:(NSString * _Nullable)native emoji:(NSString * _Nullable)emoji currency:(NSString * _Nullable)currency __attribute__((swift_name("doCopy(name:native:emoji:currency:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable currency __attribute__((swift_name("currency")));
@property (readonly) NSString * _Nullable emoji __attribute__((swift_name("emoji")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@property (readonly) NSString * _Nullable native __attribute__((swift_name("native")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DatabaseDriverFactory")))
@interface SharedDatabaseDriverFactory : SharedBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (id<SharedRuntimeSqlDriver>)createDriver __attribute__((swift_name("createDriver()")));
@end

__attribute__((swift_name("Koin_coreKoinComponent")))
@protocol SharedKoin_coreKoinComponent
@required
- (SharedKoin_coreKoin *)getKoin __attribute__((swift_name("getKoin()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CoreDataNetwork")))
@interface SharedCoreDataNetwork : SharedBase <SharedKoin_coreKoinComponent>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 * @note annotations
 *   kotlin.experimental.ExperimentalNativeApi
 * @note This method converts all Kotlin exceptions to errors.
*/
- (void)getAllCountriesWithCompletionHandler:(void (^)(SharedArrow_coreEither<SharedFailure *, SharedCountriesQueryData *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAllCountries(completionHandler:)")));

/**
 * @note annotations
 *   kotlin.experimental.ExperimentalNativeApi
 * @note This method converts all Kotlin exceptions to errors.
*/
- (void)getAllCountriesFromDBWithCompletionHandler:(void (^)(SharedArrow_coreEither<SharedKotlinNothing *, NSArray<SharedCountryListEntity *> *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAllCountriesFromDB(completionHandler:)")));

/**
 * @note annotations
 *   kotlin.experimental.ExperimentalNativeApi
 * @note This method converts all Kotlin exceptions to errors.
*/
- (void)getCountryInfoByCodeCountryCode:(NSString *)countryCode completionHandler:(void (^)(SharedArrow_coreEither<SharedFailure *, SharedGetCountryInfoQueryData *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getCountryInfoByCode(countryCode:completionHandler:)")));

/**
 * @note annotations
 *   kotlin.experimental.ExperimentalNativeApi
 * @note This method converts all Kotlin exceptions to errors.
*/
- (BOOL)setNewTokenNewToken:(NSString *)newToken error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("setNewToken(newToken:)")));

/**
 * @note annotations
 *   kotlin.experimental.ExperimentalNativeApi
 * @note This method converts all Kotlin exceptions to errors.
*/
- (BOOL)setUrlUrl:(NSString *)url error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("setUrl(url:)")));
@end

__attribute__((swift_name("KotlinThrowable")))
@interface SharedKotlinThrowable : SharedBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));

/**
 * @note annotations
 *   kotlin.experimental.ExperimentalNativeApi
*/
- (SharedKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SharedKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
- (NSError *)asError __attribute__((swift_name("asError()")));
@end

__attribute__((swift_name("KotlinException")))
@interface SharedKotlinException : SharedKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("Failure")))
@interface SharedFailure : SharedKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(SharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Failure.NoConnection")))
@interface SharedFailureNoConnection : SharedFailure
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)noConnection __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedFailureNoConnection *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Failure.NoData")))
@interface SharedFailureNoData : SharedFailure
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)noData __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedFailureNoData *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Failure.ServerError")))
@interface SharedFailureServerError : SharedFailure
- (instancetype)initWithError:(SharedApollo_apiError * _Nullable)error __attribute__((swift_name("init(error:)"))) __attribute__((objc_designated_initializer));
- (SharedFailureServerError *)doCopyError:(SharedApollo_apiError * _Nullable)error __attribute__((swift_name("doCopy(error:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SharedApollo_apiError * _Nullable error __attribute__((swift_name("error")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Failure.UnknownError")))
@interface SharedFailureUnknownError : SharedFailure
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unknownError __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedFailureUnknownError *shared __attribute__((swift_name("shared")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("Apollo_runtimeHttpInterceptor")))
@protocol SharedApollo_runtimeHttpInterceptor
@required
- (void)dispose __attribute__((swift_name("dispose()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)interceptRequest:(SharedApollo_apiHttpRequest *)request chain:(id<SharedApollo_runtimeHttpInterceptorChain>)chain completionHandler:(void (^)(SharedApollo_apiHttpResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("intercept(request:chain:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AuthorizationInterceptor")))
@interface SharedAuthorizationInterceptor : SharedBase <SharedApollo_runtimeHttpInterceptor>
- (instancetype)initWithToken:(NSString *)token __attribute__((swift_name("init(token:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)interceptRequest:(SharedApollo_apiHttpRequest *)request chain:(id<SharedApollo_runtimeHttpInterceptorChain>)chain completionHandler:(void (^)(SharedApollo_apiHttpResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("intercept(request:chain:completionHandler:)")));
@property (readonly) NSString *token __attribute__((swift_name("token")));
@end

__attribute__((swift_name("IDynamicApolloClient")))
@protocol SharedIDynamicApolloClient
@required
- (SharedApollo_runtimeApolloClient *)buildApi __attribute__((swift_name("buildApi()")));
- (void)setBaseUrlUrl:(NSString *)url __attribute__((swift_name("setBaseUrl(url:)")));
- (void)setTokenNewToken:(NSString *)newToken __attribute__((swift_name("setToken(newToken:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DynamicApolloClient")))
@interface SharedDynamicApolloClient : SharedBase <SharedIDynamicApolloClient>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (SharedApollo_runtimeApolloClient *)buildApi __attribute__((swift_name("buildApi()")));
- (void)setBaseUrlUrl:(NSString *)url __attribute__((swift_name("setBaseUrl(url:)")));
- (void)setTokenNewToken:(NSString *)newToken __attribute__((swift_name("setToken(newToken:)")));
@end

__attribute__((swift_name("Apollo_runtimeApolloInterceptor")))
@protocol SharedApollo_runtimeApolloInterceptor
@required
- (id<SharedKotlinx_coroutines_coreFlow>)interceptRequest:(SharedApollo_apiApolloRequest<id<SharedApollo_apiOperationData>> *)request chain:(id<SharedApollo_runtimeApolloInterceptorChain>)chain __attribute__((swift_name("intercept(request:chain:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LoggingApolloInterceptor")))
@interface SharedLoggingApolloInterceptor : SharedBase <SharedApollo_runtimeApolloInterceptor>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (id<SharedKotlinx_coroutines_coreFlow>)interceptRequest:(SharedApollo_apiApolloRequest<id<SharedApollo_apiOperationData>> *)request chain:(id<SharedApollo_runtimeApolloInterceptorChain>)chain __attribute__((swift_name("intercept(request:chain:)")));
@end

__attribute__((swift_name("IBookTripRepository")))
@protocol SharedIBookTripRepository
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAllCountriesWithCompletionHandler:(void (^)(SharedArrow_coreEither<SharedFailure *, SharedCountriesQueryData *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAllCountries(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getCountryInfoByCodeCountryCode:(NSString *)countryCode completionHandler:(void (^)(SharedArrow_coreEither<SharedFailure *, SharedGetCountryInfoQueryData *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getCountryInfoByCode(countryCode:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BookTripRepository")))
@interface SharedBookTripRepository : SharedBase <SharedIBookTripRepository>
- (instancetype)initWithDynamicApolloClient:(id<SharedIDynamicApolloClient>)dynamicApolloClient __attribute__((swift_name("init(dynamicApolloClient:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAllCountriesWithCompletionHandler:(void (^)(SharedArrow_coreEither<SharedFailure *, SharedCountriesQueryData *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAllCountries(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getCountryInfoByCodeCountryCode:(NSString *)countryCode completionHandler:(void (^)(SharedArrow_coreEither<SharedFailure *, SharedGetCountryInfoQueryData *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getCountryInfoByCode(countryCode:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CountriesQuerySelections")))
@interface SharedCountriesQuerySelections : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)countriesQuerySelections __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedCountriesQuerySelections *shared __attribute__((swift_name("shared")));
@property (readonly) NSArray<SharedApollo_apiCompiledSelection *> *__root __attribute__((swift_name("__root")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GetCountryInfoQuerySelections")))
@interface SharedGetCountryInfoQuerySelections : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)getCountryInfoQuerySelections __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedGetCountryInfoQuerySelections *shared __attribute__((swift_name("shared")));
@property (readonly) NSArray<SharedApollo_apiCompiledSelection *> *__root __attribute__((swift_name("__root")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Country")))
@interface SharedCountry : SharedBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) SharedCountryCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Country.Companion")))
@interface SharedCountryCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedCountryCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) SharedApollo_apiObjectType *type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GraphQLBoolean")))
@interface SharedGraphQLBoolean : SharedBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) SharedGraphQLBooleanCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GraphQLBoolean.Companion")))
@interface SharedGraphQLBooleanCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedGraphQLBooleanCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) SharedApollo_apiCustomScalarType *type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GraphQLFloat")))
@interface SharedGraphQLFloat : SharedBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) SharedGraphQLFloatCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GraphQLFloat.Companion")))
@interface SharedGraphQLFloatCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedGraphQLFloatCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) SharedApollo_apiCustomScalarType *type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GraphQLID")))
@interface SharedGraphQLID : SharedBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) SharedGraphQLIDCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GraphQLID.Companion")))
@interface SharedGraphQLIDCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedGraphQLIDCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) SharedApollo_apiCustomScalarType *type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GraphQLInt")))
@interface SharedGraphQLInt : SharedBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) SharedGraphQLIntCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GraphQLInt.Companion")))
@interface SharedGraphQLIntCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedGraphQLIntCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) SharedApollo_apiCustomScalarType *type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GraphQLString")))
@interface SharedGraphQLString : SharedBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) SharedGraphQLStringCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GraphQLString.Companion")))
@interface SharedGraphQLStringCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedGraphQLStringCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) SharedApollo_apiCustomScalarType *type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Language")))
@interface SharedLanguage : SharedBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) SharedLanguageCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Language.Companion")))
@interface SharedLanguageCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedLanguageCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) SharedApollo_apiObjectType *type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Query")))
@interface SharedQuery : SharedBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) SharedQueryCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Query.Companion")))
@interface SharedQueryCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedQueryCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) SharedApollo_apiCompiledArgumentDefinition *__country_code __attribute__((swift_name("__country_code")));
@property (readonly) SharedApollo_apiObjectType *type __attribute__((swift_name("type")));
@end

__attribute__((swift_name("ICountryUseCase")))
@protocol SharedICountryUseCase
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAllCountriesWithCompletionHandler:(void (^)(SharedArrow_coreEither<SharedFailure *, SharedCountriesQueryData *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAllCountries(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAllCountriesFromDBWithCompletionHandler:(void (^)(SharedArrow_coreEither<SharedKotlinNothing *, NSArray<SharedCountryListEntity *> *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAllCountriesFromDB(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getCountryInfoByCodeCountryCode:(NSString *)countryCode completionHandler:(void (^)(SharedArrow_coreEither<SharedFailure *, SharedGetCountryInfoQueryData *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getCountryInfoByCode(countryCode:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CountryUseCase")))
@interface SharedCountryUseCase : SharedBase <SharedICountryUseCase>
- (instancetype)initWithDatabaseDriverFactory:(SharedDatabaseDriverFactory *)databaseDriverFactory bookTripRepository:(id<SharedIBookTripRepository>)bookTripRepository __attribute__((swift_name("init(databaseDriverFactory:bookTripRepository:)"))) __attribute__((objc_designated_initializer));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAllCountriesWithCompletionHandler:(void (^)(SharedArrow_coreEither<SharedFailure *, SharedCountriesQueryData *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAllCountries(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getAllCountriesFromDBWithCompletionHandler:(void (^)(SharedArrow_coreEither<SharedKotlinNothing *, NSArray<SharedCountryListEntity *> *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getAllCountriesFromDB(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getCountryInfoByCodeCountryCode:(NSString *)countryCode completionHandler:(void (^)(SharedArrow_coreEither<SharedFailure *, SharedGetCountryInfoQueryData *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getCountryInfoByCode(countryCode:completionHandler:)")));
@end

__attribute__((swift_name("Arrow_coreEither")))
@interface SharedArrow_coreEither<__covariant A, __covariant B> : SharedBase
@property (class, readonly, getter=companion) SharedArrow_coreEitherCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)allPredicate:(SharedBoolean *(^)(B _Nullable))predicate __attribute__((swift_name("all(predicate:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer when or fold instead")));
- (id _Nullable)bifoldLeftC:(id _Nullable)c f:(id _Nullable (^)(id _Nullable, A _Nullable))f g:(id _Nullable (^)(id _Nullable, B _Nullable))g __attribute__((swift_name("bifoldLeft(c:f:g:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer when or fold instead")));
- (id _Nullable)bifoldMapMN:(id<SharedArrow_coreMonoid>)MN f:(id _Nullable (^)(A _Nullable))f g:(id _Nullable (^)(B _Nullable))g __attribute__((swift_name("bifoldMap(MN:f:g:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer when or fold instead")));
- (SharedArrow_coreEither<id, id> *)bimapLeftOperation:(id _Nullable (^)(A _Nullable))leftOperation rightOperation:(id _Nullable (^)(B _Nullable))rightOperation __attribute__((swift_name("bimap(leftOperation:rightOperation:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using the Either DSL, or map + mapLeft")));
- (NSArray<SharedArrow_coreEither<id, id> *> *)bitraverseFe:(id (^)(A _Nullable))fe fa:(id (^)(B _Nullable))fa __attribute__((swift_name("bitraverse(fe:fa:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer explicit fold instead")));
- (SharedArrow_coreEither<id, id> * _Nullable)bitraverseNullableFl:(id _Nullable (^)(A _Nullable))fl fr:(id _Nullable (^)(B _Nullable))fr __attribute__((swift_name("bitraverseNullable(fl:fr:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer explicit fold instead")));
- (SharedArrow_coreOption<SharedArrow_coreEither<id, id> *> *)bitraverseOptionFl:(SharedArrow_coreOption<id> *(^)(A _Nullable))fl fr:(SharedArrow_coreOption<id> *(^)(B _Nullable))fr __attribute__((swift_name("bitraverseOption(fl:fr:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer explicit fold instead")));
- (SharedArrow_coreValidated<id, SharedArrow_coreEither<id, id> *> *)bitraverseValidatedFe:(SharedArrow_coreValidated<id, id> *(^)(A _Nullable))fe fa:(SharedArrow_coreValidated<id, id> *(^)(B _Nullable))fa __attribute__((swift_name("bitraverseValidated(fe:fa:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer explicit fold instead")));
- (BOOL)existPredicate:(SharedBoolean *(^)(B _Nullable))predicate __attribute__((swift_name("exist(predicate:)"))) __attribute__((deprecated("Facilitates the migration from Validated to Either.")));
- (BOOL)existsPredicate:(SharedBoolean *(^)(B _Nullable))predicate __attribute__((swift_name("exists(predicate:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer isRight")));
- (B _Nullable)findOrNullPredicate:(SharedBoolean *(^)(B _Nullable))predicate __attribute__((swift_name("findOrNull(predicate:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer Kotlin nullable syntax instead")));
- (id _Nullable)foldIfLeft:(id _Nullable (^)(A _Nullable))ifLeft ifRight:(id _Nullable (^)(B _Nullable))ifRight __attribute__((swift_name("fold(ifLeft:ifRight:)")));
- (id _Nullable)foldLeftInitial:(id _Nullable)initial rightOperation:(id _Nullable (^)(id _Nullable, B _Nullable))rightOperation __attribute__((swift_name("foldLeft(initial:rightOperation:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer when or fold instead")));
- (id _Nullable)foldMapMN:(id<SharedArrow_coreMonoid>)MN f:(id _Nullable (^)(B _Nullable))f __attribute__((swift_name("foldMap(MN:f:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer when or fold instead")));
- (SharedArrow_coreOption<B> *)getOrNone __attribute__((swift_name("getOrNone()")));
- (B _Nullable)getOrNull __attribute__((swift_name("getOrNull()")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()"))) __attribute__((deprecated("This API is considered redundant. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nUse isLeft()")));
- (BOOL)isLeft __attribute__((swift_name("isLeft()")));
- (BOOL)isLeftPredicate:(SharedBoolean *(^)(A _Nullable))predicate __attribute__((swift_name("isLeft(predicate:)")));
- (BOOL)isNotEmpty __attribute__((swift_name("isNotEmpty()"))) __attribute__((deprecated("This API is considered redundant. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nUse isRight()")));
- (BOOL)isRight __attribute__((swift_name("isRight()")));
- (BOOL)isRightPredicate:(SharedBoolean *(^)(B _Nullable))predicate __attribute__((swift_name("isRight(predicate:)")));
- (A _Nullable)leftOrNull __attribute__((swift_name("leftOrNull()")));
- (SharedArrow_coreEither<A, id> *)mapF:(id _Nullable (^)(B _Nullable))f __attribute__((swift_name("map(f:)")));
- (SharedArrow_coreEither<id, B> *)mapLeftF:(id _Nullable (^)(A _Nullable))f __attribute__((swift_name("mapLeft(f:)")));
- (SharedArrow_coreEither<A, B> *)onLeftAction:(void (^)(A _Nullable))action __attribute__((swift_name("onLeft(action:)")));
- (SharedArrow_coreEither<A, B> *)onRightAction:(void (^)(B _Nullable))action __attribute__((swift_name("onRight(action:)")));
- (SharedArrow_coreOption<B> *)orNone __attribute__((swift_name("orNone()"))) __attribute__((deprecated("orNone is being renamed to getOrNone to be more consistent with the Kotlin Standard Library naming")));
- (B _Nullable)orNull __attribute__((swift_name("orNull()"))) __attribute__((deprecated("orNull is being renamed to getOrNull to be more consistent with the Kotlin Standard Library naming")));
- (SharedArrow_coreEither<A, NSArray<id> *> *)replicateN:(int32_t)n __attribute__((swift_name("replicate(n:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using the Either DSL, or map")));
- (SharedArrow_coreEither<B, A> *)swap __attribute__((swift_name("swap()")));
- (SharedArrow_coreEither<A, B> *)tapF:(void (^)(B _Nullable))f __attribute__((swift_name("tap(f:)"))) __attribute__((deprecated("tap is being renamed to onRight to be more consistent with the Kotlin Standard Library naming")));
- (SharedArrow_coreEither<A, B> *)tapLeftF:(void (^)(A _Nullable))f __attribute__((swift_name("tapLeft(f:)"))) __attribute__((deprecated("tapLeft is being renamed to onLeft to be more consistent with the Kotlin Standard Library naming")));
- (SharedArrow_coreEither<A, B> *)toEither __attribute__((swift_name("toEither()"))) __attribute__((deprecated("Facilitates the migration from Validated to Either, you can simply remove this method call.")));
- (SharedArrow_coreIor<A, B> *)toIor __attribute__((swift_name("toIor()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (SharedArrow_coreValidated<A, B> *)toValidated __attribute__((swift_name("toValidated()"))) __attribute__((deprecated("Validated functionality is being merged into Either.\nYou can find more details about how to migrate on the Github release page, or the 1.2.0 release post.")));
- (SharedArrow_coreValidated<NSArray<id> *, B> *)toValidatedNel __attribute__((swift_name("toValidatedNel()"))) __attribute__((deprecated("Validated functionality is being merged into Either.\nValidatedNel is being replaced by EitherNel")));
- (SharedArrow_coreOption<SharedArrow_coreEither<A, id> *> *)traverseFa:(SharedArrow_coreOption<id> *(^)(B _Nullable))fa __attribute__((swift_name("traverse(fa:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using the Either DSL, or explicit fold or when")));
- (SharedArrow_coreValidated<id, SharedArrow_coreEither<A, id> *> *)traverseFa_:(SharedArrow_coreValidated<id, id> *(^)(B _Nullable))fa __attribute__((swift_name("traverse(fa_:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using the Either DSL, or explicit fold or when")));
- (NSArray<SharedArrow_coreEither<A, id> *> *)traverseFa__:(id (^)(B _Nullable))fa __attribute__((swift_name("traverse(fa__:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using the Either DSL, or explicit fold or when")));
- (SharedArrow_coreEither<A, id> * _Nullable)traverseNullableFa:(id _Nullable (^)(B _Nullable))fa __attribute__((swift_name("traverseNullable(fa:)"))) __attribute__((deprecated("This API is considered redundant. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nUse orNull() and Kotlin nullable types")));
- (SharedArrow_coreOption<SharedArrow_coreEither<A, id> *> *)traverseOptionFa:(SharedArrow_coreOption<id> *(^)(B _Nullable))fa __attribute__((swift_name("traverseOption(fa:)"))) __attribute__((deprecated("traverseOption is being renamed to traverse to simplify the Arrow API")));
- (SharedArrow_coreValidated<id, SharedArrow_coreEither<A, id> *> *)traverseValidatedFa:(SharedArrow_coreValidated<id, id> *(^)(B _Nullable))fa __attribute__((swift_name("traverseValidated(fa:)"))) __attribute__((deprecated("traverseValidated is being renamed to traverse to simplify the Arrow API")));
- (SharedArrow_coreEither<A, SharedKotlinUnit *> *)void __attribute__((swift_name("void()"))) __attribute__((deprecated("This API is considered redundant. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nMap with Unit")));
@end

@interface SharedArrow_coreEither (Extensions)
- (SharedArrow_coreEither<id, id> *)onFailureFn:(void (^)(id _Nullable))fn __attribute__((swift_name("onFailure(fn:)")));
- (SharedArrow_coreEither<id, id> *)onSuccessFn:(void (^)(id _Nullable))fn __attribute__((swift_name("onSuccess(fn:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KoinKt")))
@interface SharedKoinKt : SharedBase
+ (SharedKoin_coreKoinApplication *)doInitKoin __attribute__((swift_name("doInitKoin()")));
+ (SharedKoin_coreKoinApplication *)doInitKoinAppDeclaration:(void (^)(SharedKoin_coreKoinApplication *))appDeclaration __attribute__((swift_name("doInitKoin(appDeclaration:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NetworkManagerKt")))
@interface SharedNetworkManagerKt : SharedBase

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
+ (void)consumeRequestRequest:(id<SharedKotlinSuspendFunction0>)request completionHandler:(void (^)(SharedArrow_coreEither<SharedFailure *, id<SharedApollo_apiOperationData>> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("consumeRequest(request:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NetworkModuleKt")))
@interface SharedNetworkModuleKt : SharedBase
@property (class, readonly) SharedKoin_coreModule *apolloModule __attribute__((swift_name("apolloModule")));
@property (class, readonly) SharedKoin_coreModule *dispatcherModule __attribute__((swift_name("dispatcherModule")));
@property (class, readonly) SharedKoin_coreModule *repositoryModule __attribute__((swift_name("repositoryModule")));
@property (class, readonly) SharedKoin_coreModule *useCasesModule __attribute__((swift_name("useCasesModule")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlatformModule_iosKt")))
@interface SharedPlatformModule_iosKt : SharedBase
+ (SharedKoin_coreModule *)platformModule __attribute__((swift_name("platformModule()")));
@end

__attribute__((swift_name("OkioIOException")))
@interface SharedOkioIOException : SharedKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end

__attribute__((swift_name("Apollo_apiCompiledSelection")))
@interface SharedApollo_apiCompiledSelection : SharedBase
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiCompiledField")))
@interface SharedApollo_apiCompiledField : SharedApollo_apiCompiledSelection
- (SharedApollo_apiOptional<id> *)argumentValueName:(NSString *)name variables:(SharedApollo_apiExecutableVariables *)variables __attribute__((swift_name("argumentValue(name:variables:)")));

/**
 * @note annotations
 *   com.apollographql.apollo3.annotations.ApolloExperimental
*/
- (NSDictionary<NSString *, id> *)argumentValuesVariables:(SharedApollo_apiExecutableVariables *)variables filter:(SharedBoolean *(^)(SharedApollo_apiCompiledArgument *))filter __attribute__((swift_name("argumentValues(variables:filter:)")));
- (NSString *)nameWithArgumentsVariables:(SharedApollo_apiExecutableVariables *)variables __attribute__((swift_name("nameWithArguments(variables:)")));
- (SharedApollo_apiCompiledFieldBuilder *)doNewBuilder __attribute__((swift_name("doNewBuilder()")));
- (id _Nullable)resolveArgumentName:(NSString *)name variables:(SharedApollo_apiExecutableVariables *)variables __attribute__((swift_name("resolveArgument(name:variables:)"))) __attribute__((deprecated("This function does not distinguish between null and absent arguments. Use argumentValue instead")));
@property (readonly) NSString * _Nullable alias __attribute__((swift_name("alias")));
@property (readonly) NSArray<SharedApollo_apiCompiledArgument *> *arguments __attribute__((swift_name("arguments")));
@property (readonly) NSArray<SharedApollo_apiCompiledCondition *> *condition __attribute__((swift_name("condition")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *responseName __attribute__((swift_name("responseName")));
@property (readonly) NSArray<SharedApollo_apiCompiledSelection *> *selections __attribute__((swift_name("selections")));
@property (readonly) SharedApollo_apiCompiledType *type __attribute__((swift_name("type")));
@end

__attribute__((swift_name("OkioCloseable")))
@protocol SharedOkioCloseable
@required

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)closeAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("close()")));
@end

__attribute__((swift_name("Apollo_apiJsonWriter")))
@protocol SharedApollo_apiJsonWriter <SharedOkioCloseable>
@required

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<SharedApollo_apiJsonWriter> _Nullable)beginArrayAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("beginArray()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<SharedApollo_apiJsonWriter> _Nullable)beginObjectAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("beginObject()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<SharedApollo_apiJsonWriter> _Nullable)endArrayAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("endArray()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<SharedApollo_apiJsonWriter> _Nullable)endObjectAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("endObject()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)flushAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("flush()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<SharedApollo_apiJsonWriter> _Nullable)nameName:(NSString *)name error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("name(name:)")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<SharedApollo_apiJsonWriter> _Nullable)nullValueAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("nullValue()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<SharedApollo_apiJsonWriter> _Nullable)valueValue:(id<SharedApollo_apiUpload>)value error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("value(value:)")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<SharedApollo_apiJsonWriter> _Nullable)valueValue:(SharedApollo_apiJsonNumber *)value error_:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("value(value_:)")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<SharedApollo_apiJsonWriter> _Nullable)valueValue:(BOOL)value error__:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("value(value__:)")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<SharedApollo_apiJsonWriter> _Nullable)valueValue:(double)value error___:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("value(value___:)")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<SharedApollo_apiJsonWriter> _Nullable)valueValue:(int32_t)value error____:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("value(value____:)")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<SharedApollo_apiJsonWriter> _Nullable)valueValue:(int64_t)value error_____:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("value(value_____:)")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<SharedApollo_apiJsonWriter> _Nullable)valueValue:(NSString *)value error______:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("value(value______:)")));
@property (readonly) NSString *path __attribute__((swift_name("path")));
@end

__attribute__((swift_name("Apollo_apiExecutionContext")))
@protocol SharedApollo_apiExecutionContext
@required
- (id _Nullable)foldInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, id<SharedApollo_apiExecutionContextElement>))operation __attribute__((swift_name("fold(initial:operation:)")));
- (id<SharedApollo_apiExecutionContextElement> _Nullable)getKey:(id<SharedApollo_apiExecutionContextKey>)key __attribute__((swift_name("get(key:)")));
- (id<SharedApollo_apiExecutionContext>)minusKeyKey:(id<SharedApollo_apiExecutionContextKey>)key __attribute__((swift_name("minusKey(key:)")));
- (id<SharedApollo_apiExecutionContext>)plusContext:(id<SharedApollo_apiExecutionContext>)context __attribute__((swift_name("plus(context:)")));
@end

__attribute__((swift_name("Apollo_apiExecutionContextElement")))
@protocol SharedApollo_apiExecutionContextElement <SharedApollo_apiExecutionContext>
@required
@property (readonly) id<SharedApollo_apiExecutionContextKey> key __attribute__((swift_name("key")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiCustomScalarAdapters")))
@interface SharedApollo_apiCustomScalarAdapters : SharedBase <SharedApollo_apiExecutionContextElement>
@property (class, readonly, getter=companion) SharedApollo_apiCustomScalarAdaptersKey *companion __attribute__((swift_name("companion")));
- (id<SharedApollo_apiAdapter> _Nullable)adapterForName:(NSString *)name __attribute__((swift_name("adapterFor(name:)")));

/**
 * @note annotations
 *   com.apollographql.apollo3.annotations.ApolloExperimental
*/
- (SharedApollo_apiError * _Nullable)firstErrorStartingWithPath:(NSArray<id> *)path __attribute__((swift_name("firstErrorStartingWith(path:)")));
- (SharedApollo_apiCustomScalarAdaptersBuilder *)doNewBuilder __attribute__((swift_name("doNewBuilder()")));
- (id<SharedApollo_apiAdapter>)responseAdapterForCustomScalar:(SharedApollo_apiCustomScalarType *)customScalar __attribute__((swift_name("responseAdapterFor(customScalar:)")));
@property (readonly) NSSet<SharedApollo_apiDeferredFragmentIdentifier *> * _Nullable deferredFragmentIdentifiers __attribute__((swift_name("deferredFragmentIdentifiers")));
@property (readonly) NSArray<SharedApollo_apiError *> * _Nullable errors __attribute__((swift_name("errors")));
@property (readonly) NSSet<NSString *> * _Nullable falseVariables __attribute__((swift_name("falseVariables")));
@property (readonly) id<SharedApollo_apiExecutionContextKey> key __attribute__((swift_name("key")));
@end

__attribute__((swift_name("Apollo_apiJsonReader")))
@protocol SharedApollo_apiJsonReader <SharedOkioCloseable>
@required

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<SharedApollo_apiJsonReader> _Nullable)beginArrayAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("beginArray()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<SharedApollo_apiJsonReader> _Nullable)beginObjectAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("beginObject()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<SharedApollo_apiJsonReader> _Nullable)endArrayAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("endArray()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (id<SharedApollo_apiJsonReader> _Nullable)endObjectAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("endObject()")));
- (NSArray<id> *)getPath __attribute__((swift_name("getPath()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)hasNextAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("hasNext()"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)nextBooleanAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("nextBoolean()"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (double)nextDoubleAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("nextDouble()"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (int32_t)nextIntAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("nextInt()"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (int64_t)nextLongAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("nextLong()"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (NSString * _Nullable)nextNameAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("nextName()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (SharedKotlinNothing * _Nullable)nextNullAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("nextNull()"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (SharedApollo_apiJsonNumber * _Nullable)nextNumberAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("nextNumber()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (NSString * _Nullable)nextStringAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("nextString()"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (SharedApollo_apiJsonReaderToken * _Nullable)peekAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("peek()")));
- (void)rewind __attribute__((swift_name("rewind()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (int32_t)selectNameNames:(NSArray<NSString *> *)names error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("selectName(names:)"))) __attribute__((swift_error(nonnull_error)));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)skipValueAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("skipValue()")));
@end

__attribute__((swift_name("RuntimeTransactionCallbacks")))
@protocol SharedRuntimeTransactionCallbacks
@required
- (void)afterCommitFunction:(void (^)(void))function __attribute__((swift_name("afterCommit(function:)")));
- (void)afterRollbackFunction:(void (^)(void))function __attribute__((swift_name("afterRollback(function:)")));
@end

__attribute__((swift_name("RuntimeTransactionWithoutReturn")))
@protocol SharedRuntimeTransactionWithoutReturn <SharedRuntimeTransactionCallbacks>
@required
- (void)rollback __attribute__((swift_name("rollback()")));
- (void)transactionBody:(void (^)(id<SharedRuntimeTransactionWithoutReturn>))body __attribute__((swift_name("transaction(body:)")));
@end

__attribute__((swift_name("RuntimeTransactionWithReturn")))
@protocol SharedRuntimeTransactionWithReturn <SharedRuntimeTransactionCallbacks>
@required
- (void)rollbackReturnValue:(id _Nullable)returnValue __attribute__((swift_name("rollback(returnValue:)")));
- (id _Nullable)transactionBody_:(id _Nullable (^)(id<SharedRuntimeTransactionWithReturn>))body __attribute__((swift_name("transaction(body_:)")));
@end

__attribute__((swift_name("RuntimeCloseable")))
@protocol SharedRuntimeCloseable
@required
- (void)close __attribute__((swift_name("close_()")));
@end

__attribute__((swift_name("RuntimeSqlDriver")))
@protocol SharedRuntimeSqlDriver <SharedRuntimeCloseable>
@required
- (void)addListenerQueryKeys:(SharedKotlinArray<NSString *> *)queryKeys listener:(id<SharedRuntimeQueryListener>)listener __attribute__((swift_name("addListener(queryKeys:listener:)")));
- (SharedRuntimeTransacterTransaction * _Nullable)currentTransaction __attribute__((swift_name("currentTransaction()")));
- (id<SharedRuntimeQueryResult>)executeIdentifier:(SharedInt * _Nullable)identifier sql:(NSString *)sql parameters:(int32_t)parameters binders:(void (^ _Nullable)(id<SharedRuntimeSqlPreparedStatement>))binders __attribute__((swift_name("execute(identifier:sql:parameters:binders:)")));
- (id<SharedRuntimeQueryResult>)executeQueryIdentifier:(SharedInt * _Nullable)identifier sql:(NSString *)sql mapper:(id<SharedRuntimeQueryResult> (^)(id<SharedRuntimeSqlCursor>))mapper parameters:(int32_t)parameters binders:(void (^ _Nullable)(id<SharedRuntimeSqlPreparedStatement>))binders __attribute__((swift_name("executeQuery(identifier:sql:mapper:parameters:binders:)")));
- (id<SharedRuntimeQueryResult>)doNewTransaction __attribute__((swift_name("doNewTransaction()")));
- (void)notifyListenersQueryKeys:(SharedKotlinArray<NSString *> *)queryKeys __attribute__((swift_name("notifyListeners(queryKeys:)")));
- (void)removeListenerQueryKeys:(SharedKotlinArray<NSString *> *)queryKeys listener:(id<SharedRuntimeQueryListener>)listener __attribute__((swift_name("removeListener(queryKeys:listener:)")));
@end

__attribute__((swift_name("RuntimeSqlSchema")))
@protocol SharedRuntimeSqlSchema
@required
- (id<SharedRuntimeQueryResult>)createDriver:(id<SharedRuntimeSqlDriver>)driver __attribute__((swift_name("create(driver:)")));
- (id<SharedRuntimeQueryResult>)migrateDriver:(id<SharedRuntimeSqlDriver>)driver oldVersion:(int64_t)oldVersion newVersion:(int64_t)newVersion callbacks:(SharedKotlinArray<SharedRuntimeAfterVersion *> *)callbacks __attribute__((swift_name("migrate(driver:oldVersion:newVersion:callbacks:)")));
@property (readonly) int64_t version __attribute__((swift_name("version")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinUnit")))
@interface SharedKotlinUnit : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unit __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKotlinUnit *shared __attribute__((swift_name("shared")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("RuntimeTransacterTransaction")))
@interface SharedRuntimeTransacterTransaction : SharedBase <SharedRuntimeTransactionCallbacks>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)afterCommitFunction:(void (^)(void))function __attribute__((swift_name("afterCommit(function:)")));
- (void)afterRollbackFunction:(void (^)(void))function __attribute__((swift_name("afterRollback(function:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (id<SharedRuntimeQueryResult>)endTransactionSuccessful:(BOOL)successful __attribute__((swift_name("endTransaction(successful:)")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) SharedRuntimeTransacterTransaction * _Nullable enclosingTransaction __attribute__((swift_name("enclosingTransaction")));
@end

__attribute__((swift_name("RuntimeExecutableQuery")))
@interface SharedRuntimeExecutableQuery<__covariant RowType> : SharedBase
- (instancetype)initWithMapper:(RowType (^)(id<SharedRuntimeSqlCursor>))mapper __attribute__((swift_name("init(mapper:)"))) __attribute__((objc_designated_initializer));
- (id<SharedRuntimeQueryResult>)executeMapper:(id<SharedRuntimeQueryResult> (^)(id<SharedRuntimeSqlCursor>))mapper __attribute__((swift_name("execute(mapper:)")));
- (NSArray<RowType> *)executeAsList __attribute__((swift_name("executeAsList()")));
- (RowType)executeAsOne __attribute__((swift_name("executeAsOne()")));
- (RowType _Nullable)executeAsOneOrNull __attribute__((swift_name("executeAsOneOrNull()")));
@property (readonly) RowType (^mapper)(id<SharedRuntimeSqlCursor>) __attribute__((swift_name("mapper")));
@end

__attribute__((swift_name("RuntimeQuery")))
@interface SharedRuntimeQuery<__covariant RowType> : SharedRuntimeExecutableQuery<RowType>
- (instancetype)initWithMapper:(RowType (^)(id<SharedRuntimeSqlCursor>))mapper __attribute__((swift_name("init(mapper:)"))) __attribute__((objc_designated_initializer));
- (void)addListenerListener:(id<SharedRuntimeQueryListener>)listener __attribute__((swift_name("addListener(listener:)")));
- (void)removeListenerListener:(id<SharedRuntimeQueryListener>)listener __attribute__((swift_name("removeListener(listener:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreKoin")))
@interface SharedKoin_coreKoin : SharedBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)close __attribute__((swift_name("close()")));
- (void)createEagerInstances __attribute__((swift_name("createEagerInstances()")));
- (SharedKoin_coreScope *)createScopeT:(id<SharedKoin_coreKoinScopeComponent>)t __attribute__((swift_name("createScope(t:)")));
- (SharedKoin_coreScope *)createScopeScopeId:(NSString *)scopeId __attribute__((swift_name("createScope(scopeId:)")));
- (SharedKoin_coreScope *)createScopeScopeId:(NSString *)scopeId source:(id _Nullable)source __attribute__((swift_name("createScope(scopeId:source:)")));
- (SharedKoin_coreScope *)createScopeScopeId:(NSString *)scopeId qualifier:(id<SharedKoin_coreQualifier>)qualifier source:(id _Nullable)source __attribute__((swift_name("createScope(scopeId:qualifier:source:)")));
- (void)declareInstance:(id _Nullable)instance qualifier:(id<SharedKoin_coreQualifier> _Nullable)qualifier secondaryTypes:(NSArray<id<SharedKotlinKClass>> *)secondaryTypes allowOverride:(BOOL)allowOverride __attribute__((swift_name("declare(instance:qualifier:secondaryTypes:allowOverride:)")));
- (void)deletePropertyKey:(NSString *)key __attribute__((swift_name("deleteProperty(key:)")));
- (void)deleteScopeScopeId:(NSString *)scopeId __attribute__((swift_name("deleteScope(scopeId:)")));
- (id)getQualifier:(id<SharedKoin_coreQualifier> _Nullable)qualifier parameters:(SharedKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("get(qualifier:parameters:)")));
- (id _Nullable)getClazz:(id<SharedKotlinKClass>)clazz qualifier:(id<SharedKoin_coreQualifier> _Nullable)qualifier parameters:(SharedKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("get(clazz:qualifier:parameters:)")));
- (NSArray<id> *)getAll __attribute__((swift_name("getAll()")));
- (SharedKoin_coreScope *)getOrCreateScopeScopeId:(NSString *)scopeId __attribute__((swift_name("getOrCreateScope(scopeId:)")));
- (SharedKoin_coreScope *)getOrCreateScopeScopeId:(NSString *)scopeId qualifier:(id<SharedKoin_coreQualifier>)qualifier source:(id _Nullable)source __attribute__((swift_name("getOrCreateScope(scopeId:qualifier:source:)")));
- (id _Nullable)getOrNullQualifier:(id<SharedKoin_coreQualifier> _Nullable)qualifier parameters:(SharedKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("getOrNull(qualifier:parameters:)")));
- (id _Nullable)getOrNullClazz:(id<SharedKotlinKClass>)clazz qualifier:(id<SharedKoin_coreQualifier> _Nullable)qualifier parameters:(SharedKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("getOrNull(clazz:qualifier:parameters:)")));
- (id _Nullable)getPropertyKey:(NSString *)key __attribute__((swift_name("getProperty(key:)")));
- (id)getPropertyKey:(NSString *)key defaultValue:(id)defaultValue __attribute__((swift_name("getProperty(key:defaultValue:)")));
- (SharedKoin_coreScope *)getScopeScopeId:(NSString *)scopeId __attribute__((swift_name("getScope(scopeId:)")));
- (SharedKoin_coreScope * _Nullable)getScopeOrNullScopeId:(NSString *)scopeId __attribute__((swift_name("getScopeOrNull(scopeId:)")));
- (id<SharedKotlinLazy>)injectQualifier:(id<SharedKoin_coreQualifier> _Nullable)qualifier mode:(SharedKotlinLazyThreadSafetyMode *)mode parameters:(SharedKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("inject(qualifier:mode:parameters:)")));
- (id<SharedKotlinLazy>)injectOrNullQualifier:(id<SharedKoin_coreQualifier> _Nullable)qualifier mode:(SharedKotlinLazyThreadSafetyMode *)mode parameters:(SharedKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("injectOrNull(qualifier:mode:parameters:)")));
- (void)loadModulesModules:(NSArray<SharedKoin_coreModule *> *)modules allowOverride:(BOOL)allowOverride createEagerInstances:(BOOL)createEagerInstances __attribute__((swift_name("loadModules(modules:allowOverride:createEagerInstances:)")));
- (void)setPropertyKey:(NSString *)key value:(id)value __attribute__((swift_name("setProperty(key:value:)")));
- (void)setupLoggerLogger:(SharedKoin_coreLogger *)logger __attribute__((swift_name("setupLogger(logger:)")));
- (void)unloadModulesModules:(NSArray<SharedKoin_coreModule *> *)modules __attribute__((swift_name("unloadModules(modules:)")));
@property (readonly) SharedKoin_coreExtensionManager *extensionManager __attribute__((swift_name("extensionManager")));
@property (readonly) SharedKoin_coreInstanceRegistry *instanceRegistry __attribute__((swift_name("instanceRegistry")));
@property (readonly) SharedKoin_coreLogger *logger __attribute__((swift_name("logger")));
@property (readonly) SharedKoin_corePropertyRegistry *propertyRegistry __attribute__((swift_name("propertyRegistry")));
@property (readonly) SharedKoin_coreScopeRegistry *scopeRegistry __attribute__((swift_name("scopeRegistry")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinNothing")))
@interface SharedKotlinNothing : SharedBase
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface SharedKotlinArray<T> : SharedBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(SharedInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<SharedKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiError")))
@interface SharedApollo_apiError : SharedBase
- (instancetype)initWithMessage:(NSString *)message locations:(NSArray<SharedApollo_apiErrorLocation *> * _Nullable)locations path:(NSArray<id> * _Nullable)path extensions:(NSDictionary<NSString *, id> * _Nullable)extensions nonStandardFields:(NSDictionary<NSString *, id> * _Nullable)nonStandardFields __attribute__((swift_name("init(message:locations:path:extensions:nonStandardFields:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("Use Error.Builder instead")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSDictionary<NSString *, id> * _Nullable extensions __attribute__((swift_name("extensions")));
@property (readonly) NSArray<SharedApollo_apiErrorLocation *> * _Nullable locations __attribute__((swift_name("locations")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@property (readonly) NSDictionary<NSString *, id> * _Nullable nonStandardFields __attribute__((swift_name("nonStandardFields")));
@property (readonly) NSArray<id> * _Nullable path __attribute__((swift_name("path")));
@end

__attribute__((swift_name("KotlinRuntimeException")))
@interface SharedKotlinRuntimeException : SharedKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinIllegalStateException")))
@interface SharedKotlinIllegalStateException : SharedKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.4")
*/
__attribute__((swift_name("KotlinCancellationException")))
@interface SharedKotlinCancellationException : SharedKotlinIllegalStateException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiHttpRequest")))
@interface SharedApollo_apiHttpRequest : SharedBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (SharedApollo_apiHttpRequestBuilder *)doNewBuilderMethod:(SharedApollo_apiHttpMethod *)method url:(NSString *)url __attribute__((swift_name("doNewBuilder(method:url:)")));
@property (readonly) id<SharedApollo_apiHttpBody> _Nullable body __attribute__((swift_name("body")));
@property (readonly) id<SharedApollo_apiExecutionContext> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) NSArray<SharedApollo_apiHttpHeader *> *headers __attribute__((swift_name("headers")));
@property (readonly) SharedApollo_apiHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) NSString *url __attribute__((swift_name("url")));
@end

__attribute__((swift_name("Apollo_runtimeHttpInterceptorChain")))
@protocol SharedApollo_runtimeHttpInterceptorChain
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)proceedRequest:(SharedApollo_apiHttpRequest *)request completionHandler:(void (^)(SharedApollo_apiHttpResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("proceed(request:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiHttpResponse")))
@interface SharedApollo_apiHttpResponse : SharedBase
- (SharedApollo_apiHttpResponseBuilder *)doNewBuilder __attribute__((swift_name("doNewBuilder()")));
@property (readonly) id<SharedOkioBufferedSource> _Nullable body __attribute__((swift_name("body")));
@property (readonly) NSArray<SharedApollo_apiHttpHeader *> *headers __attribute__((swift_name("headers")));
@property (readonly) int32_t statusCode __attribute__((swift_name("statusCode")));
@end

__attribute__((swift_name("Apollo_apiExecutionOptions")))
@protocol SharedApollo_apiExecutionOptions
@required
@property (readonly) SharedBoolean * _Nullable canBeBatched __attribute__((swift_name("canBeBatched")));
@property (readonly) SharedBoolean * _Nullable enableAutoPersistedQueries __attribute__((swift_name("enableAutoPersistedQueries")));
@property (readonly) id<SharedApollo_apiExecutionContext> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) NSArray<SharedApollo_apiHttpHeader *> * _Nullable httpHeaders __attribute__((swift_name("httpHeaders")));
@property (readonly) SharedApollo_apiHttpMethod * _Nullable httpMethod __attribute__((swift_name("httpMethod")));
@property (readonly) SharedBoolean * _Nullable sendApqExtensions __attribute__((swift_name("sendApqExtensions")));
@property (readonly) SharedBoolean * _Nullable sendDocument __attribute__((swift_name("sendDocument")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_runtimeApolloClient")))
@interface SharedApollo_runtimeApolloClient : SharedBase <SharedApollo_apiExecutionOptions, SharedOkioCloseable>
@property (class, readonly, getter=companion) SharedApollo_runtimeApolloClientCompanion *companion __attribute__((swift_name("companion")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)closeAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("close()")));
- (void)dispose __attribute__((swift_name("dispose()"))) __attribute__((unavailable("Use close() instead")));
- (id<SharedKotlinx_coroutines_coreFlow>)executeAsFlowApolloRequest:(SharedApollo_apiApolloRequest<id<SharedApollo_apiOperationData>> *)apolloRequest __attribute__((swift_name("executeAsFlow(apolloRequest:)")));
- (SharedApollo_runtimeApolloCall<id<SharedApollo_apiMutationData>> *)mutationMutation:(id<SharedApollo_apiMutation>)mutation __attribute__((swift_name("mutation(mutation:)")));
- (SharedApollo_runtimeApolloClientBuilder *)doNewBuilder __attribute__((swift_name("doNewBuilder()")));
- (SharedApollo_runtimeApolloCall<id<SharedApollo_apiQueryData>> *)queryQuery:(id<SharedApollo_apiQuery>)query __attribute__((swift_name("query(query:)")));
- (SharedApollo_runtimeApolloCall<id<SharedApollo_apiSubscriptionData>> *)subscriptionSubscription:(id<SharedApollo_apiSubscription>)subscription __attribute__((swift_name("subscription(subscription:)")));
@property (readonly) SharedBoolean * _Nullable canBeBatched __attribute__((swift_name("canBeBatched")));
@property (readonly) SharedApollo_apiCustomScalarAdapters *customScalarAdapters __attribute__((swift_name("customScalarAdapters")));
@property (readonly) SharedBoolean * _Nullable enableAutoPersistedQueries __attribute__((swift_name("enableAutoPersistedQueries")));
@property (readonly) id<SharedApollo_apiExecutionContext> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) NSArray<SharedApollo_apiHttpHeader *> * _Nullable httpHeaders __attribute__((swift_name("httpHeaders")));
@property (readonly) SharedApollo_apiHttpMethod * _Nullable httpMethod __attribute__((swift_name("httpMethod")));
@property (readonly) NSArray<id<SharedApollo_runtimeApolloInterceptor>> *interceptors __attribute__((swift_name("interceptors")));
@property (readonly) id<SharedApollo_runtimeNetworkTransport> networkTransport __attribute__((swift_name("networkTransport")));
@property (readonly) SharedBoolean * _Nullable sendApqExtensions __attribute__((swift_name("sendApqExtensions")));
@property (readonly) SharedBoolean * _Nullable sendDocument __attribute__((swift_name("sendDocument")));
@property (readonly) id<SharedApollo_runtimeNetworkTransport> subscriptionNetworkTransport __attribute__((swift_name("subscriptionNetworkTransport")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreFlow")))
@protocol SharedKotlinx_coroutines_coreFlow
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)collectCollector:(id<SharedKotlinx_coroutines_coreFlowCollector>)collector completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("collect(collector:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiApolloRequest")))
@interface SharedApollo_apiApolloRequest<D> : SharedBase <SharedApollo_apiExecutionOptions>
- (SharedApollo_apiApolloRequestBuilder<D> *)doNewBuilder __attribute__((swift_name("doNewBuilder()")));

/**
 * @note annotations
 *   com.apollographql.apollo3.annotations.ApolloExperimental
*/
- (SharedApollo_apiApolloRequestBuilder<id<SharedApollo_apiOperationData>> *)doNewBuilderOperation:(id<SharedApollo_apiOperation>)operation __attribute__((swift_name("doNewBuilder(operation:)")));
@property (readonly) SharedBoolean * _Nullable canBeBatched __attribute__((swift_name("canBeBatched")));
@property (readonly) SharedBoolean * _Nullable enableAutoPersistedQueries __attribute__((swift_name("enableAutoPersistedQueries")));
@property (readonly) id<SharedApollo_apiExecutionContext> executionContext __attribute__((swift_name("executionContext")));

/**
 * @note annotations
 *   com.apollographql.apollo3.annotations.ApolloExperimental
*/
@property (readonly) SharedBoolean * _Nullable failFastIfOffline __attribute__((swift_name("failFastIfOffline")));
@property (readonly) NSArray<SharedApollo_apiHttpHeader *> * _Nullable httpHeaders __attribute__((swift_name("httpHeaders")));
@property (readonly) SharedApollo_apiHttpMethod * _Nullable httpMethod __attribute__((swift_name("httpMethod")));
@property (readonly) SharedBoolean * _Nullable ignoreApolloClientHttpHeaders __attribute__((swift_name("ignoreApolloClientHttpHeaders")));
@property (readonly) id<SharedApollo_apiOperation> operation __attribute__((swift_name("operation")));
@property (readonly) SharedUuidUuid *requestUuid __attribute__((swift_name("requestUuid")));

/**
 * @note annotations
 *   com.apollographql.apollo3.annotations.ApolloExperimental
*/
@property (readonly) SharedBoolean * _Nullable retryOnError __attribute__((swift_name("retryOnError")));
@property (readonly) SharedBoolean * _Nullable sendApqExtensions __attribute__((swift_name("sendApqExtensions")));
@property (readonly) SharedBoolean * _Nullable sendDocument __attribute__((swift_name("sendDocument")));
@end

__attribute__((swift_name("Apollo_runtimeApolloInterceptorChain")))
@protocol SharedApollo_runtimeApolloInterceptorChain
@required
- (id<SharedKotlinx_coroutines_coreFlow>)proceedRequest:(SharedApollo_apiApolloRequest<id<SharedApollo_apiOperationData>> *)request __attribute__((swift_name("proceed(request:)")));
@end

__attribute__((swift_name("Apollo_apiCompiledType")))
@interface SharedApollo_apiCompiledType : SharedBase
- (SharedApollo_apiCompiledNamedType *)leafType __attribute__((swift_name("leafType()"))) __attribute__((deprecated("Use rawType instead")));
- (SharedApollo_apiCompiledNamedType *)rawType __attribute__((swift_name("rawType()")));
@end

__attribute__((swift_name("Apollo_apiCompiledNamedType")))
@interface SharedApollo_apiCompiledNamedType : SharedApollo_apiCompiledType
- (SharedApollo_apiCompiledNamedType *)leafType __attribute__((swift_name("leafType()"))) __attribute__((deprecated("Use rawType instead")));
- (SharedApollo_apiCompiledNamedType *)rawType __attribute__((swift_name("rawType()")));
@property (readonly, getter=name_) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiObjectType")))
@interface SharedApollo_apiObjectType : SharedApollo_apiCompiledNamedType
- (SharedApollo_apiObjectTypeBuilder *)doNewBuilder __attribute__((swift_name("doNewBuilder()")));
@property (readonly) NSArray<NSString *> *embeddedFields __attribute__((swift_name("embeddedFields")));
@property (readonly) NSArray<SharedApollo_apiInterfaceType *> *implements __attribute__((swift_name("implements")));
@property (readonly) NSArray<NSString *> *keyFields __attribute__((swift_name("keyFields")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiCustomScalarType")))
@interface SharedApollo_apiCustomScalarType : SharedApollo_apiCompiledNamedType
- (instancetype)initWithName:(NSString *)name className:(NSString *)className __attribute__((swift_name("init(name:className:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSString *className __attribute__((swift_name("className")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiCompiledArgumentDefinition")))
@interface SharedApollo_apiCompiledArgumentDefinition : SharedBase
- (SharedApollo_apiCompiledArgumentDefinitionBuilder *)doNewBuilder __attribute__((swift_name("doNewBuilder()")));
@property (readonly) BOOL isKey __attribute__((swift_name("isKey")));

/**
 * @note annotations
 *   com.apollographql.apollo3.annotations.ApolloExperimental
*/
@property (readonly) BOOL isPagination __attribute__((swift_name("isPagination")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Arrow_coreEitherCompanion")))
@interface SharedArrow_coreEitherCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedArrow_coreEitherCompanion *shared __attribute__((swift_name("shared")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
 *   kotlin.jvm.JvmName(name="tryCatch")
*/
- (SharedArrow_coreEither<SharedKotlinThrowable *, id> *)catchF:(id _Nullable (^)(void))f __attribute__((swift_name("catch(f:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
 *   kotlin.jvm.JvmName(name="tryCatch")
*/
- (SharedArrow_coreEither<id, id> *)catchFe:(id _Nullable (^)(SharedKotlinThrowable *))fe f:(id _Nullable (^)(void))f __attribute__((swift_name("catch(fe:f:)"))) __attribute__((deprecated("This API is considered redundant. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nCompose catch with mapLeft instead")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
 *   kotlin.jvm.JvmName(name="tryCatchAndFlatten")
*/
- (SharedArrow_coreEither<SharedKotlinThrowable *, id> *)catchAndFlattenF:(SharedArrow_coreEither<SharedKotlinThrowable *, id> *(^)(void))f __attribute__((swift_name("catchAndFlatten(f:)"))) __attribute__((deprecated("This API is considered redundant. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nCompose catch with flatten instead")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedArrow_coreEither<SharedKotlinThrowable *, id> *)catchOrThrowF:(id _Nullable (^)(void))f __attribute__((swift_name("catchOrThrow(f:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedArrow_coreEither<id, id> *)conditionallyTest:(BOOL)test ifFalse:(id _Nullable (^)(void))ifFalse ifTrue:(id _Nullable (^)(void))ifTrue __attribute__((swift_name("conditionally(test:ifFalse:ifTrue:)"))) __attribute__((deprecated("This API is considered redundant. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer explicit if-else statements, or ensure inside Either DSL")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedArrow_coreEither<SharedKotlinUnit *, id> *)fromNullableA:(id _Nullable)a __attribute__((swift_name("fromNullable(a:)"))) __attribute__((deprecated("This API is considered redundant. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer Kotlin nullable syntax, or ensureNotNull inside Either DSL")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedArrow_coreEither<id, id> *(^)(SharedArrow_coreEither<id, id> *))liftF:(id _Nullable (^)(id _Nullable))f __attribute__((swift_name("lift(f:)"))) __attribute__((deprecated("This API is considered redundant. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer explicitly creating lambdas")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedArrow_coreEither<id, id> *(^)(SharedArrow_coreEither<id, id> *))liftFa:(id _Nullable (^)(id _Nullable))fa fb:(id _Nullable (^)(id _Nullable))fb __attribute__((swift_name("lift(fa:fb:)"))) __attribute__((deprecated("This API is considered redundant. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer explicitly creating lambdas")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (id _Nullable)resolveF:(SharedArrow_coreEither<id, id> *(^)(void))f success:(SharedArrow_coreEither<SharedKotlinThrowable *, id> *(^)(id _Nullable))success error:(SharedArrow_coreEither<SharedKotlinThrowable *, id> *(^)(id _Nullable))error throwable:(SharedArrow_coreEither<SharedKotlinThrowable *, id> *(^)(SharedKotlinThrowable *))throwable unrecoverableState:(SharedArrow_coreEither<SharedKotlinThrowable *, SharedKotlinUnit *> *(^)(SharedKotlinThrowable *))unrecoverableState __attribute__((swift_name("resolve(f:success:error:throwable:unrecoverableState:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using recover, catch and the either DSL to work with errors")));
- (SharedArrow_coreEither<NSArray<id> *, id> *)zipOrAccumulateA:(SharedArrow_coreEither<id, id> *)a b:(SharedArrow_coreEither<id, id> *)b transform:(id _Nullable (^)(id _Nullable, id _Nullable))transform __attribute__((swift_name("zipOrAccumulate(a:b:transform:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmName(name="zipOrAccumulateNonEmptyList")
*/
- (SharedArrow_coreEither<NSArray<id> *, id> *)zipOrAccumulateA:(SharedArrow_coreEither<NSArray<id> *, id> *)a b:(SharedArrow_coreEither<NSArray<id> *, id> *)b transform_:(id _Nullable (^)(id _Nullable, id _Nullable))transform __attribute__((swift_name("zipOrAccumulate(a:b:transform_:)")));
- (SharedArrow_coreEither<NSArray<id> *, id> *)zipOrAccumulateA:(SharedArrow_coreEither<id, id> *)a b:(SharedArrow_coreEither<id, id> *)b c:(SharedArrow_coreEither<id, id> *)c transform:(id _Nullable (^)(id _Nullable, id _Nullable, id _Nullable))transform __attribute__((swift_name("zipOrAccumulate(a:b:c:transform:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmName(name="zipOrAccumulateNonEmptyList")
*/
- (SharedArrow_coreEither<NSArray<id> *, id> *)zipOrAccumulateA:(SharedArrow_coreEither<NSArray<id> *, id> *)a b:(SharedArrow_coreEither<NSArray<id> *, id> *)b c:(SharedArrow_coreEither<NSArray<id> *, id> *)c transform_:(id _Nullable (^)(id _Nullable, id _Nullable, id _Nullable))transform __attribute__((swift_name("zipOrAccumulate(a:b:c:transform_:)")));
- (SharedArrow_coreEither<id, id> *)zipOrAccumulateCombine:(id _Nullable (^)(id _Nullable, id _Nullable))combine a:(SharedArrow_coreEither<id, id> *)a b:(SharedArrow_coreEither<id, id> *)b transform:(id _Nullable (^)(id _Nullable, id _Nullable))transform __attribute__((swift_name("zipOrAccumulate(combine:a:b:transform:)")));
- (SharedArrow_coreEither<NSArray<id> *, id> *)zipOrAccumulateA:(SharedArrow_coreEither<id, id> *)a b:(SharedArrow_coreEither<id, id> *)b c:(SharedArrow_coreEither<id, id> *)c d:(SharedArrow_coreEither<id, id> *)d transform:(id _Nullable (^)(id _Nullable, id _Nullable, id _Nullable, id _Nullable))transform __attribute__((swift_name("zipOrAccumulate(a:b:c:d:transform:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmName(name="zipOrAccumulateNonEmptyList")
*/
- (SharedArrow_coreEither<NSArray<id> *, id> *)zipOrAccumulateA:(SharedArrow_coreEither<NSArray<id> *, id> *)a b:(SharedArrow_coreEither<NSArray<id> *, id> *)b c:(SharedArrow_coreEither<NSArray<id> *, id> *)c d:(SharedArrow_coreEither<NSArray<id> *, id> *)d transform_:(id _Nullable (^)(id _Nullable, id _Nullable, id _Nullable, id _Nullable))transform __attribute__((swift_name("zipOrAccumulate(a:b:c:d:transform_:)")));
- (SharedArrow_coreEither<id, id> *)zipOrAccumulateCombine:(id _Nullable (^)(id _Nullable, id _Nullable))combine a:(SharedArrow_coreEither<id, id> *)a b:(SharedArrow_coreEither<id, id> *)b c:(SharedArrow_coreEither<id, id> *)c transform:(id _Nullable (^)(id _Nullable, id _Nullable, id _Nullable))transform __attribute__((swift_name("zipOrAccumulate(combine:a:b:c:transform:)")));
- (SharedArrow_coreEither<NSArray<id> *, id> *)zipOrAccumulateA:(SharedArrow_coreEither<id, id> *)a b:(SharedArrow_coreEither<id, id> *)b c:(SharedArrow_coreEither<id, id> *)c d:(SharedArrow_coreEither<id, id> *)d e:(SharedArrow_coreEither<id, id> *)e transform:(id _Nullable (^)(id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable))transform __attribute__((swift_name("zipOrAccumulate(a:b:c:d:e:transform:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmName(name="zipOrAccumulateNonEmptyList")
*/
- (SharedArrow_coreEither<NSArray<id> *, id> *)zipOrAccumulateA:(SharedArrow_coreEither<NSArray<id> *, id> *)a b:(SharedArrow_coreEither<NSArray<id> *, id> *)b c:(SharedArrow_coreEither<NSArray<id> *, id> *)c d:(SharedArrow_coreEither<NSArray<id> *, id> *)d e:(SharedArrow_coreEither<NSArray<id> *, id> *)e transform_:(id _Nullable (^)(id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable))transform __attribute__((swift_name("zipOrAccumulate(a:b:c:d:e:transform_:)")));
- (SharedArrow_coreEither<id, id> *)zipOrAccumulateCombine:(id _Nullable (^)(id _Nullable, id _Nullable))combine a:(SharedArrow_coreEither<id, id> *)a b:(SharedArrow_coreEither<id, id> *)b c:(SharedArrow_coreEither<id, id> *)c d:(SharedArrow_coreEither<id, id> *)d transform:(id _Nullable (^)(id _Nullable, id _Nullable, id _Nullable, id _Nullable))transform __attribute__((swift_name("zipOrAccumulate(combine:a:b:c:d:transform:)")));
- (SharedArrow_coreEither<NSArray<id> *, id> *)zipOrAccumulateA:(SharedArrow_coreEither<id, id> *)a b:(SharedArrow_coreEither<id, id> *)b c:(SharedArrow_coreEither<id, id> *)c d:(SharedArrow_coreEither<id, id> *)d e:(SharedArrow_coreEither<id, id> *)e f:(SharedArrow_coreEither<id, id> *)f transform:(id _Nullable (^)(id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable))transform __attribute__((swift_name("zipOrAccumulate(a:b:c:d:e:f:transform:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmName(name="zipOrAccumulateNonEmptyList")
*/
- (SharedArrow_coreEither<NSArray<id> *, id> *)zipOrAccumulateA:(SharedArrow_coreEither<NSArray<id> *, id> *)a b:(SharedArrow_coreEither<NSArray<id> *, id> *)b c:(SharedArrow_coreEither<NSArray<id> *, id> *)c d:(SharedArrow_coreEither<NSArray<id> *, id> *)d e:(SharedArrow_coreEither<NSArray<id> *, id> *)e f:(SharedArrow_coreEither<NSArray<id> *, id> *)f transform_:(id _Nullable (^)(id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable))transform __attribute__((swift_name("zipOrAccumulate(a:b:c:d:e:f:transform_:)")));
- (SharedArrow_coreEither<id, id> *)zipOrAccumulateCombine:(id _Nullable (^)(id _Nullable, id _Nullable))combine a:(SharedArrow_coreEither<id, id> *)a b:(SharedArrow_coreEither<id, id> *)b c:(SharedArrow_coreEither<id, id> *)c d:(SharedArrow_coreEither<id, id> *)d e:(SharedArrow_coreEither<id, id> *)e transform:(id _Nullable (^)(id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable))transform __attribute__((swift_name("zipOrAccumulate(combine:a:b:c:d:e:transform:)")));
- (SharedArrow_coreEither<NSArray<id> *, id> *)zipOrAccumulateA:(SharedArrow_coreEither<id, id> *)a b:(SharedArrow_coreEither<id, id> *)b c:(SharedArrow_coreEither<id, id> *)c d:(SharedArrow_coreEither<id, id> *)d e:(SharedArrow_coreEither<id, id> *)e f:(SharedArrow_coreEither<id, id> *)f g:(SharedArrow_coreEither<id, id> *)g transform:(id _Nullable (^)(id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable))transform __attribute__((swift_name("zipOrAccumulate(a:b:c:d:e:f:g:transform:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmName(name="zipOrAccumulateNonEmptyList")
*/
- (SharedArrow_coreEither<NSArray<id> *, id> *)zipOrAccumulateA:(SharedArrow_coreEither<NSArray<id> *, id> *)a b:(SharedArrow_coreEither<NSArray<id> *, id> *)b c:(SharedArrow_coreEither<NSArray<id> *, id> *)c d:(SharedArrow_coreEither<NSArray<id> *, id> *)d e:(SharedArrow_coreEither<NSArray<id> *, id> *)e f:(SharedArrow_coreEither<NSArray<id> *, id> *)f g:(SharedArrow_coreEither<NSArray<id> *, id> *)g transform_:(id _Nullable (^)(id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable))transform __attribute__((swift_name("zipOrAccumulate(a:b:c:d:e:f:g:transform_:)")));
- (SharedArrow_coreEither<id, id> *)zipOrAccumulateCombine:(id _Nullable (^)(id _Nullable, id _Nullable))combine a:(SharedArrow_coreEither<id, id> *)a b:(SharedArrow_coreEither<id, id> *)b c:(SharedArrow_coreEither<id, id> *)c d:(SharedArrow_coreEither<id, id> *)d e:(SharedArrow_coreEither<id, id> *)e f:(SharedArrow_coreEither<id, id> *)f transform:(id _Nullable (^)(id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable))transform __attribute__((swift_name("zipOrAccumulate(combine:a:b:c:d:e:f:transform:)")));
- (SharedArrow_coreEither<NSArray<id> *, id> *)zipOrAccumulateA:(SharedArrow_coreEither<id, id> *)a b:(SharedArrow_coreEither<id, id> *)b c:(SharedArrow_coreEither<id, id> *)c d:(SharedArrow_coreEither<id, id> *)d e:(SharedArrow_coreEither<id, id> *)e f:(SharedArrow_coreEither<id, id> *)f g:(SharedArrow_coreEither<id, id> *)g h:(SharedArrow_coreEither<id, id> *)h transform:(id _Nullable (^)(id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable))transform __attribute__((swift_name("zipOrAccumulate(a:b:c:d:e:f:g:h:transform:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmName(name="zipOrAccumulateNonEmptyList")
*/
- (SharedArrow_coreEither<NSArray<id> *, id> *)zipOrAccumulateA:(SharedArrow_coreEither<NSArray<id> *, id> *)a b:(SharedArrow_coreEither<NSArray<id> *, id> *)b c:(SharedArrow_coreEither<NSArray<id> *, id> *)c d:(SharedArrow_coreEither<NSArray<id> *, id> *)d e:(SharedArrow_coreEither<NSArray<id> *, id> *)e f:(SharedArrow_coreEither<NSArray<id> *, id> *)f g:(SharedArrow_coreEither<NSArray<id> *, id> *)g h:(SharedArrow_coreEither<NSArray<id> *, id> *)h transform_:(id _Nullable (^)(id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable))transform __attribute__((swift_name("zipOrAccumulate(a:b:c:d:e:f:g:h:transform_:)")));
- (SharedArrow_coreEither<id, id> *)zipOrAccumulateCombine:(id _Nullable (^)(id _Nullable, id _Nullable))combine a:(SharedArrow_coreEither<id, id> *)a b:(SharedArrow_coreEither<id, id> *)b c:(SharedArrow_coreEither<id, id> *)c d:(SharedArrow_coreEither<id, id> *)d e:(SharedArrow_coreEither<id, id> *)e f:(SharedArrow_coreEither<id, id> *)f g:(SharedArrow_coreEither<id, id> *)g transform:(id _Nullable (^)(id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable))transform __attribute__((swift_name("zipOrAccumulate(combine:a:b:c:d:e:f:g:transform:)")));
- (SharedArrow_coreEither<NSArray<id> *, id> *)zipOrAccumulateA:(SharedArrow_coreEither<id, id> *)a b:(SharedArrow_coreEither<id, id> *)b c:(SharedArrow_coreEither<id, id> *)c d:(SharedArrow_coreEither<id, id> *)d e:(SharedArrow_coreEither<id, id> *)e f:(SharedArrow_coreEither<id, id> *)f g:(SharedArrow_coreEither<id, id> *)g h:(SharedArrow_coreEither<id, id> *)h i:(SharedArrow_coreEither<id, id> *)i transform:(id _Nullable (^)(id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable))transform __attribute__((swift_name("zipOrAccumulate(a:b:c:d:e:f:g:h:i:transform:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmName(name="zipOrAccumulateNonEmptyList")
*/
- (SharedArrow_coreEither<NSArray<id> *, id> *)zipOrAccumulateA:(SharedArrow_coreEither<NSArray<id> *, id> *)a b:(SharedArrow_coreEither<NSArray<id> *, id> *)b c:(SharedArrow_coreEither<NSArray<id> *, id> *)c d:(SharedArrow_coreEither<NSArray<id> *, id> *)d e:(SharedArrow_coreEither<NSArray<id> *, id> *)e f:(SharedArrow_coreEither<NSArray<id> *, id> *)f g:(SharedArrow_coreEither<NSArray<id> *, id> *)g h:(SharedArrow_coreEither<NSArray<id> *, id> *)h i:(SharedArrow_coreEither<NSArray<id> *, id> *)i transform_:(id _Nullable (^)(id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable))transform __attribute__((swift_name("zipOrAccumulate(a:b:c:d:e:f:g:h:i:transform_:)")));
- (SharedArrow_coreEither<id, id> *)zipOrAccumulateCombine:(id _Nullable (^)(id _Nullable, id _Nullable))combine a:(SharedArrow_coreEither<id, id> *)a b:(SharedArrow_coreEither<id, id> *)b c:(SharedArrow_coreEither<id, id> *)c d:(SharedArrow_coreEither<id, id> *)d e:(SharedArrow_coreEither<id, id> *)e f:(SharedArrow_coreEither<id, id> *)f g:(SharedArrow_coreEither<id, id> *)g h:(SharedArrow_coreEither<id, id> *)h transform:(id _Nullable (^)(id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable))transform __attribute__((swift_name("zipOrAccumulate(combine:a:b:c:d:e:f:g:h:transform:)")));
- (SharedArrow_coreEither<NSArray<id> *, id> *)zipOrAccumulateA:(SharedArrow_coreEither<id, id> *)a b:(SharedArrow_coreEither<id, id> *)b c:(SharedArrow_coreEither<id, id> *)c d:(SharedArrow_coreEither<id, id> *)d e:(SharedArrow_coreEither<id, id> *)e f:(SharedArrow_coreEither<id, id> *)f g:(SharedArrow_coreEither<id, id> *)g h:(SharedArrow_coreEither<id, id> *)h i:(SharedArrow_coreEither<id, id> *)i j:(SharedArrow_coreEither<id, id> *)j transform:(id _Nullable (^)(id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable))transform __attribute__((swift_name("zipOrAccumulate(a:b:c:d:e:f:g:h:i:j:transform:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmName(name="zipOrAccumulateNonEmptyList")
*/
- (SharedArrow_coreEither<NSArray<id> *, id> *)zipOrAccumulateA:(SharedArrow_coreEither<NSArray<id> *, id> *)a b:(SharedArrow_coreEither<NSArray<id> *, id> *)b c:(SharedArrow_coreEither<NSArray<id> *, id> *)c d:(SharedArrow_coreEither<NSArray<id> *, id> *)d e:(SharedArrow_coreEither<NSArray<id> *, id> *)e f:(SharedArrow_coreEither<NSArray<id> *, id> *)f g:(SharedArrow_coreEither<NSArray<id> *, id> *)g h:(SharedArrow_coreEither<NSArray<id> *, id> *)h i:(SharedArrow_coreEither<NSArray<id> *, id> *)i j:(SharedArrow_coreEither<NSArray<id> *, id> *)j transform_:(id _Nullable (^)(id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable))transform __attribute__((swift_name("zipOrAccumulate(a:b:c:d:e:f:g:h:i:j:transform_:)")));
- (SharedArrow_coreEither<id, id> *)zipOrAccumulateCombine:(id _Nullable (^)(id _Nullable, id _Nullable))combine a:(SharedArrow_coreEither<id, id> *)a b:(SharedArrow_coreEither<id, id> *)b c:(SharedArrow_coreEither<id, id> *)c d:(SharedArrow_coreEither<id, id> *)d e:(SharedArrow_coreEither<id, id> *)e f:(SharedArrow_coreEither<id, id> *)f g:(SharedArrow_coreEither<id, id> *)g h:(SharedArrow_coreEither<id, id> *)h i:(SharedArrow_coreEither<id, id> *)i transform:(id _Nullable (^)(id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable))transform __attribute__((swift_name("zipOrAccumulate(combine:a:b:c:d:e:f:g:h:i:transform:)")));
- (SharedArrow_coreEither<id, id> *)zipOrAccumulateCombine:(id _Nullable (^)(id _Nullable, id _Nullable))combine a:(SharedArrow_coreEither<id, id> *)a b:(SharedArrow_coreEither<id, id> *)b c:(SharedArrow_coreEither<id, id> *)c d:(SharedArrow_coreEither<id, id> *)d e:(SharedArrow_coreEither<id, id> *)e f:(SharedArrow_coreEither<id, id> *)f g:(SharedArrow_coreEither<id, id> *)g h:(SharedArrow_coreEither<id, id> *)h i:(SharedArrow_coreEither<id, id> *)i j:(SharedArrow_coreEither<id, id> *)j transform:(id _Nullable (^)(id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable))transform __attribute__((swift_name("zipOrAccumulate(combine:a:b:c:d:e:f:g:h:i:j:transform:)")));
@end

__attribute__((swift_name("Arrow_coreSemigroup")))
@protocol SharedArrow_coreSemigroup
@required
- (id _Nullable)appendA:(id _Nullable)a b:(id _Nullable)b __attribute__((swift_name("append(a:b:)")));
- (id _Nullable)combine:(id _Nullable)receiver b:(id _Nullable)b __attribute__((swift_name("combine(_:b:)")));
- (id _Nullable)maybeCombine:(id _Nullable)receiver b:(id _Nullable)b __attribute__((swift_name("maybeCombine(_:b:)")));
- (id _Nullable)plus:(id _Nullable)receiver b:(id _Nullable)b __attribute__((swift_name("plus(_:b:)")));
@end

__attribute__((swift_name("Arrow_coreMonoid")))
@protocol SharedArrow_coreMonoid <SharedArrow_coreSemigroup>
@required
- (id _Nullable)combineAll:(id)receiver __attribute__((swift_name("combineAll(_:)"))) __attribute__((deprecated("use fold instead")));
- (id _Nullable)combineAllElems:(NSArray<id> *)elems __attribute__((swift_name("combineAll(elems:)"))) __attribute__((deprecated("use fold instead")));
- (id _Nullable)empty __attribute__((swift_name("empty()")));
- (id _Nullable)fold:(id)receiver __attribute__((swift_name("fold(_:)")));
- (id _Nullable)foldElems:(NSArray<id> *)elems __attribute__((swift_name("fold(elems:)")));
@end

__attribute__((swift_name("Arrow_coreOption")))
@interface SharedArrow_coreOption<__covariant A> : SharedBase
@property (class, readonly, getter=companion) SharedArrow_coreOptionCompanion *companion __attribute__((swift_name("companion")));
- (SharedArrow_coreOption<SharedArrow_coreIor<A, id> *> *)alignB:(SharedArrow_coreOption<id> *)b __attribute__((swift_name("align(b:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using a simple fold, or when expression")));
- (SharedArrow_coreOption<id> *)alignB:(SharedArrow_coreOption<id> *)b f:(id _Nullable (^)(SharedArrow_coreIor<A, id> *))f __attribute__((swift_name("align(b:f:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using a simple fold, or when expression")));
- (BOOL)allPredicate:(SharedBoolean *(^)(A _Nullable))predicate __attribute__((swift_name("all(predicate:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using the Option DSL, or fold or map")));
- (SharedArrow_coreOption<id> *)andValue:(SharedArrow_coreOption<id> *)value __attribute__((swift_name("and(value:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using the Option DSL or flatMap")));
- (SharedArrow_coreOption<SharedArrow_coreOption<id> *> *)crosswalkF:(SharedArrow_coreOption<id> *(^)(A _Nullable))f __attribute__((swift_name("crosswalk(f:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using the Option DSL or fold")));
- (NSDictionary<id, SharedArrow_coreOption<id> *> *)crosswalkMapF:(NSDictionary<id, id> *(^)(A _Nullable))f __attribute__((swift_name("crosswalkMap(f:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using the Option DSL or fold")));
- (SharedArrow_coreOption<id> * _Nullable)crosswalkNullF:(id _Nullable (^)(A _Nullable))f __attribute__((swift_name("crosswalkNull(f:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using the Option DSL or fold")));
- (BOOL)existsPredicate:(SharedBoolean *(^)(A _Nullable))predicate __attribute__((swift_name("exists(predicate:)"))) __attribute__((deprecated("This API is considered redundant. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPlease use Option's member function isSome. This will be removed towards Arrow 2.0")));
- (SharedArrow_coreOption<A> *)filterPredicate:(SharedBoolean *(^)(A _Nullable))predicate __attribute__((swift_name("filter(predicate:)")));
- (SharedArrow_coreOption<A> *)filterNotPredicate:(SharedBoolean *(^)(A _Nullable))predicate __attribute__((swift_name("filterNot(predicate:)")));
- (A _Nullable)findOrNullPredicate:(SharedBoolean *(^)(A _Nullable))predicate __attribute__((swift_name("findOrNull(predicate:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer Kotlin nullable syntax instead")));
- (SharedArrow_coreOption<id> *)flatMapF:(SharedArrow_coreOption<id> *(^)(A _Nullable))f __attribute__((swift_name("flatMap(f:)")));
- (id _Nullable)foldIfEmpty:(id _Nullable (^)(void))ifEmpty ifSome:(id _Nullable (^)(A _Nullable))ifSome __attribute__((swift_name("fold(ifEmpty:ifSome:)")));
- (id _Nullable)foldLeftInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, A _Nullable))operation __attribute__((swift_name("foldLeft(initial:operation:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer when or fold instead")));
- (id _Nullable)foldMapMB:(id<SharedArrow_coreMonoid>)MB f:(id _Nullable (^)(A _Nullable))f __attribute__((swift_name("foldMap(MB:f:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer when or fold instead")));
- (A _Nullable)getOrNull __attribute__((swift_name("getOrNull()")));
- (BOOL)isDefined __attribute__((swift_name("isDefined()"))) __attribute__((deprecated("Duplicated API. Please use Option's member function isSome. This will be removed towards Arrow 2.0")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()"))) __attribute__((deprecated("Duplicated API. Please use Option's member function isNone. This will be removed towards Arrow 2.0")));
- (BOOL)isNone __attribute__((swift_name("isNone()")));
- (BOOL)isNotEmpty __attribute__((swift_name("isNotEmpty()"))) __attribute__((deprecated("Duplicated API. Please use Option's member function isSome. This will be removed towards Arrow 2.0")));
- (BOOL)isSome __attribute__((swift_name("isSome()")));
- (BOOL)isSomePredicate:(SharedBoolean *(^)(A _Nullable))predicate __attribute__((swift_name("isSome(predicate:)")));
- (SharedArrow_coreOption<id> *)mapF:(id _Nullable (^)(A _Nullable))f __attribute__((swift_name("map(f:)")));
- (SharedArrow_coreOption<id> *)mapNotNullF:(id _Nullable (^)(A _Nullable))f __attribute__((swift_name("mapNotNull(f:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using the Option DSL, or fold or map")));
- (BOOL)nonEmpty __attribute__((swift_name("nonEmpty()"))) __attribute__((deprecated("Duplicated API. Please use Option's member function isSome. This will be removed towards Arrow 2.0")));
- (SharedArrow_coreOption<A> *)onNoneAction:(void (^)(void))action __attribute__((swift_name("onNone(action:)")));
- (SharedArrow_coreOption<A> *)onSomeAction:(void (^)(A _Nullable))action __attribute__((swift_name("onSome(action:)")));
- (A _Nullable)orNull __attribute__((swift_name("orNull()"))) __attribute__((deprecated("orNull is being renamed to getOrNull to be more consistent with the Kotlin Standard Library naming")));
- (SharedArrow_coreOption<SharedKotlinPair<A, id> *> *)padZipOther:(SharedArrow_coreOption<id> *)other __attribute__((swift_name("padZip(other:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using a simple fold, or when expression")));
- (SharedArrow_coreOption<id> *)padZipOther:(SharedArrow_coreOption<id> *)other f:(id _Nullable (^)(A _Nullable, id _Nullable))f __attribute__((swift_name("padZip(other:f:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using a simple fold, or when expression")));
- (SharedArrow_coreOption<SharedKotlinPair<id, A> *> *)pairLeftLeft:(id _Nullable)left __attribute__((swift_name("pairLeft(left:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using the Option DSL or map")));
- (SharedArrow_coreOption<SharedKotlinPair<A, id> *> *)pairRightRight:(id _Nullable)right __attribute__((swift_name("pairRight(right:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using the Option DSL or map")));
- (id _Nullable)reduceOrNullInitial:(id _Nullable (^)(A _Nullable))initial operation:(id _Nullable (^)(id _Nullable, A _Nullable))operation __attribute__((swift_name("reduceOrNull(initial:operation:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer when or fold instead")));
- (SharedArrow_coreEval<id> *)reduceRightEvalOrNullInitial:(id _Nullable (^)(A _Nullable))initial operation:(SharedArrow_coreEval<id> *(^)(A _Nullable, SharedArrow_coreEval<id> *))operation __attribute__((swift_name("reduceRightEvalOrNull(initial:operation:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer when or fold instead")));
- (SharedArrow_coreOption<NSArray<id> *> *)replicateN:(int32_t)n __attribute__((swift_name("replicate(n:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using the Option DSL or map")));
- (SharedArrow_coreOption<A> *)tapF:(void (^)(A _Nullable))f __attribute__((swift_name("tap(f:)"))) __attribute__((deprecated("tap is being renamed to onSome to be more consistent with the Kotlin Standard Library naming")));
- (SharedArrow_coreOption<A> *)tapNoneF:(void (^)(void))f __attribute__((swift_name("tapNone(f:)"))) __attribute__((deprecated("tapNone is being renamed to onNone to be more consistent with the Kotlin Standard Library naming")));
- (SharedArrow_coreEither<id, A> *)toEitherIfEmpty:(id _Nullable (^)(void))ifEmpty __attribute__((swift_name("toEither(ifEmpty:)")));
- (NSArray<id> *)toList __attribute__((swift_name("toList()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (SharedArrow_coreEither<id, SharedArrow_coreOption<id> *> *)traverseFa:(SharedArrow_coreEither<id, id> *(^)(A _Nullable))fa __attribute__((swift_name("traverse(fa:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using the Option DSL, or explicit fold or when")));
- (SharedArrow_coreValidated<id, SharedArrow_coreOption<id> *> *)traverseFa_:(SharedArrow_coreValidated<id, id> *(^)(A _Nullable))fa __attribute__((swift_name("traverse(fa_:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using the Option DSL, or explicit fold or when")));
- (NSArray<SharedArrow_coreOption<id> *> *)traverseFa__:(id (^)(A _Nullable))fa __attribute__((swift_name("traverse(fa__:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using the Option DSL, or explicit fold or when")));
- (SharedArrow_coreEither<id, SharedArrow_coreOption<id> *> *)traverseEitherFa:(SharedArrow_coreEither<id, id> *(^)(A _Nullable))fa __attribute__((swift_name("traverseEither(fa:)"))) __attribute__((deprecated("traverseEither is being renamed to traverse to simplify the Arrow API")));
- (SharedArrow_coreValidated<id, SharedArrow_coreOption<id> *> *)traverseValidatedFa:(SharedArrow_coreValidated<id, id> *(^)(A _Nullable))fa __attribute__((swift_name("traverseValidated(fa:)"))) __attribute__((deprecated("traverseValidated is being renamed to traverse to simplify the Arrow API")));
- (SharedArrow_coreOption<SharedKotlinUnit *> *)void __attribute__((swift_name("void()"))) __attribute__((deprecated("This API is considered redundant. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nReplace with map with Unit")));
- (SharedArrow_coreOption<SharedKotlinPair<A, id> *> *)zipOther:(SharedArrow_coreOption<id> *)other __attribute__((swift_name("zip(other:)"))) __attribute__((deprecated("Prefer using the inline option DSL")));
- (SharedArrow_coreOption<id> *)zipB:(SharedArrow_coreOption<id> *)b map:(id _Nullable (^)(A _Nullable, id _Nullable))map __attribute__((swift_name("zip(b:map:)"))) __attribute__((deprecated("Prefer using the inline option DSL")));
- (SharedArrow_coreOption<id> *)zipB:(SharedArrow_coreOption<id> *)b c:(SharedArrow_coreOption<id> *)c map:(id _Nullable (^)(A _Nullable, id _Nullable, id _Nullable))map __attribute__((swift_name("zip(b:c:map:)"))) __attribute__((deprecated("Prefer using the inline option DSL")));
- (SharedArrow_coreOption<id> *)zipB:(SharedArrow_coreOption<id> *)b c:(SharedArrow_coreOption<id> *)c d:(SharedArrow_coreOption<id> *)d map:(id _Nullable (^)(A _Nullable, id _Nullable, id _Nullable, id _Nullable))map __attribute__((swift_name("zip(b:c:d:map:)"))) __attribute__((deprecated("Prefer using the inline option DSL")));
- (SharedArrow_coreOption<id> *)zipB:(SharedArrow_coreOption<id> *)b c:(SharedArrow_coreOption<id> *)c d:(SharedArrow_coreOption<id> *)d e:(SharedArrow_coreOption<id> *)e map:(id _Nullable (^)(A _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable))map __attribute__((swift_name("zip(b:c:d:e:map:)"))) __attribute__((deprecated("Prefer using the inline option DSL")));
- (SharedArrow_coreOption<id> *)zipB:(SharedArrow_coreOption<id> *)b c:(SharedArrow_coreOption<id> *)c d:(SharedArrow_coreOption<id> *)d e:(SharedArrow_coreOption<id> *)e f:(SharedArrow_coreOption<id> *)f map:(id _Nullable (^)(A _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable))map __attribute__((swift_name("zip(b:c:d:e:f:map:)"))) __attribute__((deprecated("Prefer using the inline option DSL")));
- (SharedArrow_coreOption<id> *)zipB:(SharedArrow_coreOption<id> *)b c:(SharedArrow_coreOption<id> *)c d:(SharedArrow_coreOption<id> *)d e:(SharedArrow_coreOption<id> *)e f:(SharedArrow_coreOption<id> *)f g:(SharedArrow_coreOption<id> *)g map:(id _Nullable (^)(A _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable))map __attribute__((swift_name("zip(b:c:d:e:f:g:map:)"))) __attribute__((deprecated("Prefer using the inline option DSL")));
- (SharedArrow_coreOption<id> *)zipB:(SharedArrow_coreOption<id> *)b c:(SharedArrow_coreOption<id> *)c d:(SharedArrow_coreOption<id> *)d e:(SharedArrow_coreOption<id> *)e f:(SharedArrow_coreOption<id> *)f g:(SharedArrow_coreOption<id> *)g h:(SharedArrow_coreOption<id> *)h map:(id _Nullable (^)(A _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable))map __attribute__((swift_name("zip(b:c:d:e:f:g:h:map:)"))) __attribute__((deprecated("Prefer using the inline option DSL")));
- (SharedArrow_coreOption<id> *)zipB:(SharedArrow_coreOption<id> *)b c:(SharedArrow_coreOption<id> *)c d:(SharedArrow_coreOption<id> *)d e:(SharedArrow_coreOption<id> *)e f:(SharedArrow_coreOption<id> *)f g:(SharedArrow_coreOption<id> *)g h:(SharedArrow_coreOption<id> *)h i:(SharedArrow_coreOption<id> *)i map:(id _Nullable (^)(A _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable))map __attribute__((swift_name("zip(b:c:d:e:f:g:h:i:map:)"))) __attribute__((deprecated("Prefer using the inline option DSL")));
- (SharedArrow_coreOption<id> *)zipB:(SharedArrow_coreOption<id> *)b c:(SharedArrow_coreOption<id> *)c d:(SharedArrow_coreOption<id> *)d e:(SharedArrow_coreOption<id> *)e f:(SharedArrow_coreOption<id> *)f g:(SharedArrow_coreOption<id> *)g h:(SharedArrow_coreOption<id> *)h i:(SharedArrow_coreOption<id> *)i j:(SharedArrow_coreOption<id> *)j map:(id _Nullable (^)(A _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable, id _Nullable))map __attribute__((swift_name("zip(b:c:d:e:f:g:h:i:j:map:)"))) __attribute__((deprecated("Prefer using the inline option DSL")));
@end

__attribute__((swift_name("Arrow_coreValidated")))
@interface SharedArrow_coreValidated<__covariant E, __covariant A> : SharedBase
@property (class, readonly, getter=companion) SharedArrow_coreValidatedCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)allPredicate:(SharedBoolean *(^)(A _Nullable))predicate __attribute__((swift_name("all(predicate:)"))) __attribute__((deprecated("Validated functionality is being merged into Either, but this API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nUse fold on Either after refactoring")));
- (id _Nullable)bifoldLeftC:(id _Nullable)c fe:(id _Nullable (^)(id _Nullable, E _Nullable))fe fa:(id _Nullable (^)(id _Nullable, A _Nullable))fa __attribute__((swift_name("bifoldLeft(c:fe:fa:)"))) __attribute__((deprecated("Validated functionality is being merged into Either, but this API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer when or fold instead")));
- (id _Nullable)bifoldMapMN:(id<SharedArrow_coreMonoid>)MN g:(id _Nullable (^)(E _Nullable))g f:(id _Nullable (^)(A _Nullable))f __attribute__((swift_name("bifoldMap(MN:g:f:)"))) __attribute__((deprecated("Validated functionality is being merged into Either, but this API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer when or fold instead")));
- (SharedArrow_coreValidated<id, id> *)bimapFe:(id _Nullable (^)(E _Nullable))fe fa:(id _Nullable (^)(A _Nullable))fa __attribute__((swift_name("bimap(fe:fa:)"))) __attribute__((deprecated("Validated functionality is being merged into Either.\nUse map and mapLeft on Either after refactoring")));
- (NSArray<SharedArrow_coreValidated<id, id> *> *)bitraverseFe:(id (^)(E _Nullable))fe fa:(id (^)(A _Nullable))fa __attribute__((swift_name("bitraverse(fe:fa:)"))) __attribute__((deprecated("Validated functionality is being merged into Either, but this API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer explicit fold instead")));
- (SharedArrow_coreEither<id, SharedArrow_coreValidated<id, id> *> *)bitraverseEitherFe:(SharedArrow_coreEither<id, id> *(^)(E _Nullable))fe fa:(SharedArrow_coreEither<id, id> *(^)(A _Nullable))fa __attribute__((swift_name("bitraverseEither(fe:fa:)"))) __attribute__((deprecated("Validated functionality is being merged into Either, but this API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer explicit fold instead")));
- (SharedArrow_coreValidated<id, id> * _Nullable)bitraverseNullableFe:(id _Nullable (^)(E _Nullable))fe fa:(id _Nullable (^)(A _Nullable))fa __attribute__((swift_name("bitraverseNullable(fe:fa:)"))) __attribute__((deprecated("Validated functionality is being merged into Either, but this API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer explicit fold instead")));
- (SharedArrow_coreOption<SharedArrow_coreValidated<id, id> *> *)bitraverseOptionFe:(SharedArrow_coreOption<id> *(^)(E _Nullable))fe fa:(SharedArrow_coreOption<id> *(^)(A _Nullable))fa __attribute__((swift_name("bitraverseOption(fe:fa:)"))) __attribute__((deprecated("Validated functionality is being merged into Either, but this API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer explicit fold instead")));
- (BOOL)existPredicate:(SharedBoolean *(^)(A _Nullable))predicate __attribute__((swift_name("exist(predicate:)"))) __attribute__((deprecated("Validated functionality is being merged into Either.\nUse isRight on Either after refactoring")));
- (A _Nullable)findOrNullPredicate:(SharedBoolean *(^)(A _Nullable))predicate __attribute__((swift_name("findOrNull(predicate:)"))) __attribute__((deprecated("Validated functionality is being merged into Either, but this API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nUse getOrNull and takeIf on Either after refactoring")));
- (id _Nullable)foldFe:(id _Nullable (^)(E _Nullable))fe fa:(id _Nullable (^)(A _Nullable))fa __attribute__((swift_name("fold(fe:fa:)"))) __attribute__((deprecated("Validated functionality is being merged into Either.\nUse fold on Either after refactoring")));
- (id _Nullable)foldLeftB:(id _Nullable)b f:(id _Nullable (^)(id _Nullable, A _Nullable))f __attribute__((swift_name("foldLeft(b:f:)"))) __attribute__((deprecated("Validated functionality is being merged into Either.\nUse fold on Either after refactoring")));
- (id _Nullable)foldMapMB:(id<SharedArrow_coreMonoid>)MB f:(id _Nullable (^)(A _Nullable))f __attribute__((swift_name("foldMap(MB:f:)"))) __attribute__((deprecated("Validated functionality is being merged into Either.\nUse fold on Either after refactoring instead")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()"))) __attribute__((deprecated("Validated functionality is being merged into Either.\nUse isRight on Either after refactoring")));
- (BOOL)isNotEmpty __attribute__((swift_name("isNotEmpty()"))) __attribute__((deprecated("Validated functionality is being merged into Either.\nUse isRight on Either after refactoring")));
- (SharedArrow_coreValidated<E, id> *)mapF:(id _Nullable (^)(A _Nullable))f __attribute__((swift_name("map(f:)"))) __attribute__((deprecated("Validated functionality is being merged into Either.\nUse map on Either after refactoring")));
- (SharedArrow_coreValidated<id, A> *)mapLeftF:(id _Nullable (^)(E _Nullable))f __attribute__((swift_name("mapLeft(f:)"))) __attribute__((deprecated("Validated functionality is being merged into Either.\nUse mapLeft on Either after refactoring")));
- (SharedArrow_coreValidated<A, E> *)swap __attribute__((swift_name("swap()"))) __attribute__((deprecated("Validated functionality is being merged into Either.\nUse swap on Either after refactoring")));
- (SharedArrow_coreValidated<E, A> *)tapF:(void (^)(A _Nullable))f __attribute__((swift_name("tap(f:)"))) __attribute__((deprecated("Validated functionality is being merged into Either.\nUse onRight on Either after refactoring")));
- (SharedArrow_coreValidated<E, A> *)tapInvalidF:(void (^)(E _Nullable))f __attribute__((swift_name("tapInvalid(f:)"))) __attribute__((deprecated("Validated functionality is being merged into Either.\nUse onLeft on Either after refactoring")));
- (SharedArrow_coreEither<E, A> *)toEither __attribute__((swift_name("toEither()"))) __attribute__((deprecated("Validated functionality is being merged into Either.\nDrop this call after refactoring")));
- (NSArray<id> *)toList __attribute__((swift_name("toList()"))) __attribute__((deprecated("Validated functionality is being merged into Either, but this API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nUse fold instead")));
- (SharedArrow_coreOption<A> *)toOption __attribute__((swift_name("toOption()"))) __attribute__((deprecated("Validated functionality is being merged into Either.\nUse getOrNone on Either after refactoring")));
- (NSString *)description __attribute__((swift_name("description()")));
- (SharedArrow_coreValidated<NSArray<id> *, A> *)toValidatedNel __attribute__((swift_name("toValidatedNel()"))) __attribute__((deprecated("Validated functionality is being merged into Either.\nUse toEitherNel directly instead")));
- (SharedArrow_coreEither<id, SharedArrow_coreValidated<E, id> *> *)traverseFa:(SharedArrow_coreEither<id, id> *(^)(A _Nullable))fa __attribute__((swift_name("traverse(fa:)"))) __attribute__((deprecated("Validated functionality is being merged into Either, but this API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using the Either DSL, or explicit fold or when")));
- (SharedArrow_coreOption<SharedArrow_coreValidated<E, id> *> *)traverseFa_:(SharedArrow_coreOption<id> *(^)(A _Nullable))fa __attribute__((swift_name("traverse(fa_:)"))) __attribute__((deprecated("Validated functionality is being merged into Either, but this API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using the Either DSL, or explicit fold or when")));
- (NSArray<SharedArrow_coreValidated<E, id> *> *)traverseFa__:(id (^)(A _Nullable))fa __attribute__((swift_name("traverse(fa__:)"))) __attribute__((deprecated("Validated functionality is being merged into Either, but this API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using the Either DSL, or explicit fold or when")));
- (SharedArrow_coreEither<id, SharedArrow_coreValidated<E, id> *> *)traverseEitherFa:(SharedArrow_coreEither<id, id> *(^)(A _Nullable))fa __attribute__((swift_name("traverseEither(fa:)"))) __attribute__((deprecated("traverseEither is being renamed to traverse to simplify the Arrow API")));
- (SharedArrow_coreValidated<E, id> * _Nullable)traverseNullableFa:(id _Nullable (^)(A _Nullable))fa __attribute__((swift_name("traverseNullable(fa:)"))) __attribute__((deprecated("Validated functionality is being merged into Either, but this API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nUse orNull() and Kotlin nullable types")));
- (SharedArrow_coreOption<SharedArrow_coreValidated<E, id> *> *)traverseOptionFa:(SharedArrow_coreOption<id> *(^)(A _Nullable))fa __attribute__((swift_name("traverseOption(fa:)"))) __attribute__((deprecated("traverseOption is being renamed to traverse to simplify the Arrow API")));
- (SharedArrow_coreValidated<E, SharedKotlinUnit *> *)void __attribute__((swift_name("void()"))) __attribute__((deprecated("Validated functionality is being merged into Either, but this API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nUse map on Either after refactoring instead")));
- (SharedArrow_coreValidated<id, id> *)withEitherF:(SharedArrow_coreEither<id, id> *(^)(SharedArrow_coreEither<E, A> *))f __attribute__((swift_name("withEither(f:)"))) __attribute__((deprecated("Validated functionality is being merged into Either.\nUse Either directly instead")));
@property (readonly) BOOL isInvalid __attribute__((swift_name("isInvalid"))) __attribute__((deprecated("Validated functionality is being merged into Either.\nUse isLeft on Either after refactoring")));
@property (readonly) BOOL isValid __attribute__((swift_name("isValid"))) __attribute__((deprecated("Validated functionality is being merged into Either.\nUse isRight on Either after refactoring")));
@end

__attribute__((swift_name("Arrow_coreIor")))
@interface SharedArrow_coreIor<__covariant A, __covariant B> : SharedBase
@property (class, readonly, getter=companion) SharedArrow_coreIorCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)allPredicate:(SharedBoolean *(^)(B _Nullable))predicate __attribute__((swift_name("all(predicate:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using fold, or map + getOrElse. See the Arrow web migration guide for more info.")));
- (NSArray<SharedArrow_coreIor<id, id> *> *)bicrosswalkFa:(id (^)(A _Nullable))fa fb:(id (^)(B _Nullable))fb __attribute__((swift_name("bicrosswalk(fa:fb:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using Ior DSL, or explicit fold, or when. See the Arrow web migration guide for more info.")));
- (NSDictionary<id, SharedArrow_coreIor<id, id> *> *)bicrosswalkMapFa:(NSDictionary<id, id> *(^)(A _Nullable))fa fb:(NSDictionary<id, id> *(^)(B _Nullable))fb __attribute__((swift_name("bicrosswalkMap(fa:fb:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using Ior DSL, or explicit fold, or when. See the Arrow web migration guide for more info.")));
- (SharedArrow_coreIor<id, id> * _Nullable)bicrosswalkNullFa:(id _Nullable (^)(A _Nullable))fa fb:(id _Nullable (^)(B _Nullable))fb __attribute__((swift_name("bicrosswalkNull(fa:fb:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using Ior DSL, or explicit fold, or when. See the Arrow web migration guide for more info.")));
- (id _Nullable)bifoldLeftC:(id _Nullable)c f:(id _Nullable (^)(id _Nullable, A _Nullable))f g:(id _Nullable (^)(id _Nullable, B _Nullable))g __attribute__((swift_name("bifoldLeft(c:f:g:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer when or fold instead")));
- (id _Nullable)bifoldMapMN:(id<SharedArrow_coreMonoid>)MN f:(id _Nullable (^)(A _Nullable))f g:(id _Nullable (^)(B _Nullable))g __attribute__((swift_name("bifoldMap(MN:f:g:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer when or fold instead. See the Arrow web migration guide for more info.")));
- (SharedArrow_coreIor<id, id> *)bimapFa:(id _Nullable (^)(A _Nullable))fa fb:(id _Nullable (^)(B _Nullable))fb __attribute__((swift_name("bimap(fa:fb:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using the Either DSL, or map + mapLeft")));
- (NSArray<SharedArrow_coreIor<id, id> *> *)bitraverseFa:(id (^)(A _Nullable))fa fb:(id (^)(B _Nullable))fb __attribute__((swift_name("bitraverse(fa:fb:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using Ior DSL, or explicit fold, or when. See the Arrow web migration guide for more info.")));
- (SharedArrow_coreEither<id, SharedArrow_coreIor<id, id> *> *)bitraverseEitherFa:(SharedArrow_coreEither<id, id> *(^)(A _Nullable))fa fb:(SharedArrow_coreEither<id, id> *(^)(B _Nullable))fb __attribute__((swift_name("bitraverseEither(fa:fb:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using Ior DSL, or explicit fold, or when. See the Arrow web migration guide for more info.")));
- (SharedArrow_coreIor<id, id> * _Nullable)bitraverseNullableFa:(id _Nullable (^)(A _Nullable))fa fb:(id _Nullable (^)(B _Nullable))fb __attribute__((swift_name("bitraverseNullable(fa:fb:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using Ior DSL, or explicit fold, or when. See the Arrow web migration guide for more info.")));
- (SharedArrow_coreOption<SharedArrow_coreIor<id, id> *> *)bitraverseOptionFa:(SharedArrow_coreOption<id> *(^)(A _Nullable))fa fb:(SharedArrow_coreOption<id> *(^)(B _Nullable))fb __attribute__((swift_name("bitraverseOption(fa:fb:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using Ior DSL, or explicit fold, or when. See the Arrow web migration guide for more info.")));
- (SharedArrow_coreValidated<id, SharedArrow_coreIor<id, id> *> *)bitraverseValidatedSA:(id<SharedArrow_coreSemigroup>)SA fa:(SharedArrow_coreValidated<id, id> *(^)(A _Nullable))fa fb:(SharedArrow_coreValidated<id, id> *(^)(B _Nullable))fb __attribute__((swift_name("bitraverseValidated(SA:fa:fb:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using Ior DSL, or explicit fold, or when. See the Arrow web migration guide for more info.")));
- (NSArray<SharedArrow_coreIor<A, id> *> *)crosswalkFa:(id (^)(B _Nullable))fa __attribute__((swift_name("crosswalk(fa:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using Ior DSL, or explicit fold, or when. See the Arrow web migration guide for more info.")));
- (NSDictionary<id, SharedArrow_coreIor<A, id> *> *)crosswalkMapFa:(NSDictionary<id, id> *(^)(B _Nullable))fa __attribute__((swift_name("crosswalkMap(fa:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using Ior DSL, or explicit fold, or when. See the Arrow web migration guide for more info.")));
- (SharedArrow_coreIor<id, id> * _Nullable)crosswalkNullIor:(SharedArrow_coreIor<id, id> *)ior fa:(id _Nullable (^)(id _Nullable))fa __attribute__((swift_name("crosswalkNull(ior:fa:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using Ior DSL, or explicit fold, or when. See the Arrow web migration guide for more info.")));
- (BOOL)existsPredicate:(SharedBoolean *(^)(B _Nullable))predicate __attribute__((swift_name("exists(predicate:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using fold, or map + getOrElse")));
- (B _Nullable)findOrNullPredicate:(SharedBoolean *(^)(B _Nullable))predicate __attribute__((swift_name("findOrNull(predicate:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer Kotlin nullable syntax instead")));
- (id _Nullable)foldFa:(id _Nullable (^)(A _Nullable))fa fb:(id _Nullable (^)(B _Nullable))fb fab:(id _Nullable (^)(A _Nullable, B _Nullable))fab __attribute__((swift_name("fold(fa:fb:fab:)")));
- (id _Nullable)foldLeftC:(id _Nullable)c f:(id _Nullable (^)(id _Nullable, B _Nullable))f __attribute__((swift_name("foldLeft(c:f:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer when or fold instead")));
- (id _Nullable)foldMapMN:(id<SharedArrow_coreMonoid>)MN f:(id _Nullable (^)(B _Nullable))f __attribute__((swift_name("foldMap(MN:f:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer when or fold instead")));
- (B _Nullable)getOrNull __attribute__((swift_name("getOrNull()")));

/**
 * @note annotations
 *   kotlin.jvm.JvmName(name="_isBoth")
*/
- (BOOL)isBoth __attribute__((swift_name("isBoth()")));
- (BOOL)isBothLeftPredicate:(SharedBoolean *(^)(A _Nullable))leftPredicate rightPredicate:(SharedBoolean *(^)(B _Nullable))rightPredicate __attribute__((swift_name("isBoth(leftPredicate:rightPredicate:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using isLeft")));

/**
 * @note annotations
 *   kotlin.jvm.JvmName(name="_isLeft")
*/
- (BOOL)isLeft __attribute__((swift_name("isLeft()")));
- (BOOL)isLeftPredicate:(SharedBoolean *(^)(A _Nullable))predicate __attribute__((swift_name("isLeft(predicate:)")));
- (BOOL)isNotEmpty __attribute__((swift_name("isNotEmpty()"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using isRight and isBoth")));

/**
 * @note annotations
 *   kotlin.jvm.JvmName(name="_isRight")
*/
- (BOOL)isRight __attribute__((swift_name("isRight()")));
- (BOOL)isRightPredicate:(SharedBoolean *(^)(B _Nullable))predicate __attribute__((swift_name("isRight(predicate:)")));
- (A _Nullable)leftOrNull __attribute__((swift_name("leftOrNull()")));
- (SharedArrow_coreIor<A, id> *)mapF:(id _Nullable (^)(B _Nullable))f __attribute__((swift_name("map(f:)")));
- (SharedArrow_coreIor<id, B> *)mapLeftFa:(id _Nullable (^)(A _Nullable))fa __attribute__((swift_name("mapLeft(fa:)")));
- (B _Nullable)orNull __attribute__((swift_name("orNull()"))) __attribute__((deprecated("orNull is being renamed to getOrNull to be more consistent with the Kotlin Standard Library naming")));
- (SharedKotlinPair<A, B> *)padNull __attribute__((swift_name("padNull()"))) __attribute__((deprecated("padNull is being renamed to toPair to be more consistent with the Kotlin Standard Library naming")));
- (SharedArrow_coreIor<B, A> *)swap __attribute__((swift_name("swap()")));
- (SharedArrow_coreEither<A, B> *)toEither __attribute__((swift_name("toEither()")));
- (SharedKotlinPair<A, B> *)toPair __attribute__((swift_name("toPair()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (SharedArrow_coreValidated<A, B> *)toValidated __attribute__((swift_name("toValidated()"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using fold. See the Arrow web migration guide for more info.")));
- (SharedArrow_coreEither<id, SharedArrow_coreIor<A, id> *> *)traverseFa:(SharedArrow_coreEither<id, id> *(^)(B _Nullable))fa __attribute__((swift_name("traverse(fa:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using Ior DSL, or explicit fold, or when. See the Arrow web migration guide for more info.")));
- (SharedArrow_coreOption<SharedArrow_coreIor<A, id> *> *)traverseFa_:(SharedArrow_coreOption<id> *(^)(B _Nullable))fa __attribute__((swift_name("traverse(fa_:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using Ior DSL, or explicit fold, or when. See the Arrow web migration guide for more info.")));
- (SharedArrow_coreValidated<id, SharedArrow_coreIor<A, id> *> *)traverseFa__:(SharedArrow_coreValidated<id, id> *(^)(B _Nullable))fa __attribute__((swift_name("traverse(fa__:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using Ior DSL, or explicit fold, or when")));
- (NSArray<SharedArrow_coreIor<A, id> *> *)traverseFa___:(id (^)(B _Nullable))fa __attribute__((swift_name("traverse(fa___:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using Ior DSL, or explicit fold, or when. See the Arrow web migration guide for more info.")));
- (SharedArrow_coreEither<id, SharedArrow_coreIor<A, id> *> *)traverseEitherFa:(SharedArrow_coreEither<id, id> *(^)(B _Nullable))fa __attribute__((swift_name("traverseEither(fa:)"))) __attribute__((deprecated("traverseEither is being renamed to traverse to simplify the Arrow API")));
- (SharedArrow_coreIor<A, id> * _Nullable)traverseNullableFa:(id _Nullable (^)(B _Nullable))fa __attribute__((swift_name("traverseNullable(fa:)"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using Ior DSL, or explicit fold, or when. See the Arrow web migration guide for more info.")));
- (SharedArrow_coreOption<SharedArrow_coreIor<A, id> *> *)traverseOptionFa:(SharedArrow_coreOption<id> *(^)(B _Nullable))fa __attribute__((swift_name("traverseOption(fa:)"))) __attribute__((deprecated("traverseOption is being renamed to traverse to simplify the Arrow API")));
- (SharedArrow_coreValidated<id, SharedArrow_coreIor<A, id> *> *)traverseValidatedFa:(SharedArrow_coreValidated<id, id> *(^)(B _Nullable))fa __attribute__((swift_name("traverseValidated(fa:)"))) __attribute__((deprecated("traverseValidated is being renamed to traverse to simplify the Arrow API")));
- (SharedArrow_coreEither<SharedArrow_coreEither<A, B> *, SharedKotlinPair<A, B> *> *)unwrap __attribute__((swift_name("unwrap()")));
- (SharedArrow_coreIor<A, SharedKotlinUnit *> *)void __attribute__((swift_name("void()"))) __attribute__((deprecated("This API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using map")));
@property (readonly, getter=isBoth_) BOOL isBoth __attribute__((swift_name("isBoth"))) __attribute__((deprecated("This API is considered redundant. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nUse isBoth()")));
@property (readonly, getter=isLeft_) BOOL isLeft __attribute__((swift_name("isLeft"))) __attribute__((deprecated("This API is considered redundant. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nUse isLeft()")));
@property (readonly, getter=isRight_) BOOL isRight __attribute__((swift_name("isRight"))) __attribute__((deprecated("This API is considered redundant. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nUse isRight()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreKoinApplication")))
@interface SharedKoin_coreKoinApplication : SharedBase
@property (class, readonly, getter=companion) SharedKoin_coreKoinApplicationCompanion *companion __attribute__((swift_name("companion")));
- (void)allowOverrideOverride:(BOOL)override __attribute__((swift_name("allowOverride(override:)")));
- (void)close __attribute__((swift_name("close()")));
- (void)createEagerInstances __attribute__((swift_name("createEagerInstances()")));
- (SharedKoin_coreKoinApplication *)loggerLogger:(SharedKoin_coreLogger *)logger __attribute__((swift_name("logger(logger:)")));
- (SharedKoin_coreKoinApplication *)modulesModules:(SharedKotlinArray<SharedKoin_coreModule *> *)modules __attribute__((swift_name("modules(modules:)")));
- (SharedKoin_coreKoinApplication *)modulesModules_:(NSArray<SharedKoin_coreModule *> *)modules __attribute__((swift_name("modules(modules_:)")));
- (SharedKoin_coreKoinApplication *)modulesModules__:(SharedKoin_coreModule *)modules __attribute__((swift_name("modules(modules__:)")));
- (SharedKoin_coreKoinApplication *)printLoggerLevel:(SharedKoin_coreLevel *)level __attribute__((swift_name("printLogger(level:)")));
- (SharedKoin_coreKoinApplication *)propertiesValues:(NSDictionary<NSString *, id> *)values __attribute__((swift_name("properties(values:)")));
@property (readonly) SharedKoin_coreKoin *koin __attribute__((swift_name("koin")));
@end

__attribute__((swift_name("KotlinFunction")))
@protocol SharedKotlinFunction
@required
@end

__attribute__((swift_name("KotlinSuspendFunction0")))
@protocol SharedKotlinSuspendFunction0 <SharedKotlinFunction>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreModule")))
@interface SharedKoin_coreModule : SharedBase
- (instancetype)initWith_createdAtStart:(BOOL)_createdAtStart __attribute__((swift_name("init(_createdAtStart:)"))) __attribute__((objc_designated_initializer));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (SharedKoin_coreKoinDefinition<id> *)factoryQualifier:(id<SharedKoin_coreQualifier> _Nullable)qualifier definition:(id _Nullable (^)(SharedKoin_coreScope *, SharedKoin_coreParametersHolder *))definition __attribute__((swift_name("factory(qualifier:definition:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (void)includesModule:(SharedKotlinArray<SharedKoin_coreModule *> *)module __attribute__((swift_name("includes(module:)")));
- (void)includesModule_:(id)module __attribute__((swift_name("includes(module_:)")));
- (void)indexPrimaryTypeInstanceFactory:(SharedKoin_coreInstanceFactory<id> *)instanceFactory __attribute__((swift_name("indexPrimaryType(instanceFactory:)")));
- (void)indexSecondaryTypesInstanceFactory:(SharedKoin_coreInstanceFactory<id> *)instanceFactory __attribute__((swift_name("indexSecondaryTypes(instanceFactory:)")));
- (NSArray<SharedKoin_coreModule *> *)plusModules:(NSArray<SharedKoin_coreModule *> *)modules __attribute__((swift_name("plus(modules:)")));
- (NSArray<SharedKoin_coreModule *> *)plusModule:(SharedKoin_coreModule *)module __attribute__((swift_name("plus(module:)")));
- (void)prepareForCreationAtStartInstanceFactory:(SharedKoin_coreSingleInstanceFactory<id> *)instanceFactory __attribute__((swift_name("prepareForCreationAtStart(instanceFactory:)")));
- (void)scopeScopeSet:(void (^)(SharedKoin_coreScopeDSL *))scopeSet __attribute__((swift_name("scope(scopeSet:)")));
- (void)scopeQualifier:(id<SharedKoin_coreQualifier>)qualifier scopeSet:(void (^)(SharedKoin_coreScopeDSL *))scopeSet __attribute__((swift_name("scope(qualifier:scopeSet:)")));
- (SharedKoin_coreKoinDefinition<id> *)singleQualifier:(id<SharedKoin_coreQualifier> _Nullable)qualifier createdAtStart:(BOOL)createdAtStart definition:(id _Nullable (^)(SharedKoin_coreScope *, SharedKoin_coreParametersHolder *))definition __attribute__((swift_name("single(qualifier:createdAtStart:definition:)")));
@property (readonly) SharedMutableSet<SharedKoin_coreSingleInstanceFactory<id> *> *eagerInstances __attribute__((swift_name("eagerInstances")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) NSMutableArray<SharedKoin_coreModule *> *includedModules __attribute__((swift_name("includedModules")));
@property (readonly) BOOL isLoaded __attribute__((swift_name("isLoaded")));
@property (readonly) SharedMutableDictionary<NSString *, SharedKoin_coreInstanceFactory<id> *> *mappings __attribute__((swift_name("mappings")));
@end

__attribute__((swift_name("Apollo_apiOptional")))
@interface SharedApollo_apiOptional<__covariant V> : SharedBase
@property (class, readonly, getter=companion) SharedApollo_apiOptionalCompanion *companion __attribute__((swift_name("companion")));
- (V _Nullable)getOrNull __attribute__((swift_name("getOrNull()")));
- (V _Nullable)getOrThrow __attribute__((swift_name("getOrThrow()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiExecutableVariables")))
@interface SharedApollo_apiExecutableVariables : SharedBase
- (instancetype)initWithValueMap:(NSDictionary<NSString *, id> *)valueMap __attribute__((swift_name("init(valueMap:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSDictionary<NSString *, id> *valueMap __attribute__((swift_name("valueMap")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiCompiledArgument")))
@interface SharedApollo_apiCompiledArgument : SharedBase
@property (readonly) SharedApollo_apiCompiledArgumentDefinition *definition __attribute__((swift_name("definition")));
@property (readonly) BOOL isKey __attribute__((swift_name("isKey"))) __attribute__((deprecated("Use definition.isKey instead")));
@property (readonly) NSString *name __attribute__((swift_name("name"))) __attribute__((deprecated("Use definition.name instead")));
@property (readonly) SharedApollo_apiOptional<id> *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiCompiledField.Builder")))
@interface SharedApollo_apiCompiledFieldBuilder : SharedBase
- (instancetype)initWithCompiledField:(SharedApollo_apiCompiledField *)compiledField __attribute__((swift_name("init(compiledField:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithName:(NSString *)name type:(SharedApollo_apiCompiledType *)type __attribute__((swift_name("init(name:type:)"))) __attribute__((objc_designated_initializer));
- (SharedApollo_apiCompiledFieldBuilder *)aliasAlias:(NSString * _Nullable)alias __attribute__((swift_name("alias(alias:)")));
- (SharedApollo_apiCompiledFieldBuilder *)argumentsArguments:(NSArray<SharedApollo_apiCompiledArgument *> *)arguments __attribute__((swift_name("arguments(arguments:)")));
- (SharedApollo_apiCompiledField *)build __attribute__((swift_name("build()")));
- (SharedApollo_apiCompiledFieldBuilder *)conditionCondition:(NSArray<SharedApollo_apiCompiledCondition *> *)condition __attribute__((swift_name("condition(condition:)")));
- (SharedApollo_apiCompiledFieldBuilder *)selectionsSelections:(NSArray<SharedApollo_apiCompiledSelection *> *)selections __attribute__((swift_name("selections(selections:)")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) SharedApollo_apiCompiledType *type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiCompiledCondition")))
@interface SharedApollo_apiCompiledCondition : SharedBase
- (instancetype)initWithName:(NSString *)name inverted:(BOOL)inverted __attribute__((swift_name("init(name:inverted:)"))) __attribute__((objc_designated_initializer));
- (SharedApollo_apiCompiledCondition *)doCopyName:(NSString *)name inverted:(BOOL)inverted __attribute__((swift_name("doCopy(name:inverted:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL inverted __attribute__((swift_name("inverted")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((swift_name("Apollo_apiUpload")))
@protocol SharedApollo_apiUpload
@required
- (void)writeToSink:(id<SharedOkioBufferedSink>)sink __attribute__((swift_name("writeTo(sink:)")));
@property (readonly) int64_t contentLength __attribute__((swift_name("contentLength")));
@property (readonly) NSString *contentType __attribute__((swift_name("contentType")));
@property (readonly) NSString * _Nullable fileName __attribute__((swift_name("fileName")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiJsonNumber")))
@interface SharedApollo_apiJsonNumber : SharedBase
- (instancetype)initWithValue:(NSString *)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((swift_name("Apollo_apiExecutionContextKey")))
@protocol SharedApollo_apiExecutionContextKey
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiCustomScalarAdapters.Key")))
@interface SharedApollo_apiCustomScalarAdaptersKey : SharedBase <SharedApollo_apiExecutionContextKey>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)key __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedApollo_apiCustomScalarAdaptersKey *shared __attribute__((swift_name("shared")));
@property (readonly) SharedApollo_apiCustomScalarAdapters *Empty __attribute__((swift_name("Empty")));

/**
 * @note annotations
 *   com.apollographql.apollo3.annotations.ApolloExperimental
*/
@property (readonly) SharedApollo_apiCustomScalarAdapters *PassThrough __attribute__((swift_name("PassThrough")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiCustomScalarAdapters.Builder")))
@interface SharedApollo_apiCustomScalarAdaptersBuilder : SharedBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (SharedApollo_apiCustomScalarAdaptersBuilder *)addCustomScalarType:(SharedApollo_apiCustomScalarType *)customScalarType customScalarAdapter:(id<SharedApollo_apiAdapter>)customScalarAdapter __attribute__((swift_name("add(customScalarType:customScalarAdapter:)")));
- (SharedApollo_apiCustomScalarAdaptersBuilder *)addName:(NSString *)name adapter:(id<SharedApollo_apiAdapter>)adapter __attribute__((swift_name("add(name:adapter:)")));
- (SharedApollo_apiCustomScalarAdaptersBuilder *)addAllCustomScalarAdapters:(SharedApollo_apiCustomScalarAdapters *)customScalarAdapters __attribute__((swift_name("addAll(customScalarAdapters:)")));
- (SharedApollo_apiCustomScalarAdapters *)build __attribute__((swift_name("build()")));
- (void)clear __attribute__((swift_name("clear()")));
- (SharedApollo_apiCustomScalarAdaptersBuilder *)deferredFragmentIdentifiersDeferredFragmentIdentifiers:(NSSet<SharedApollo_apiDeferredFragmentIdentifier *> * _Nullable)deferredFragmentIdentifiers __attribute__((swift_name("deferredFragmentIdentifiers(deferredFragmentIdentifiers:)")));
- (SharedApollo_apiCustomScalarAdaptersBuilder *)errorsErrors:(NSArray<SharedApollo_apiError *> * _Nullable)errors __attribute__((swift_name("errors(errors:)")));
- (SharedApollo_apiCustomScalarAdaptersBuilder *)falseVariablesFalseVariables:(NSSet<NSString *> * _Nullable)falseVariables __attribute__((swift_name("falseVariables(falseVariables:)")));

/**
 * @note annotations
 *   com.apollographql.apollo3.annotations.ApolloExperimental
*/
- (SharedApollo_apiCustomScalarAdaptersBuilder *)unsafeUnsafe:(BOOL)unsafe __attribute__((swift_name("unsafe(unsafe:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiDeferredFragmentIdentifier")))
@interface SharedApollo_apiDeferredFragmentIdentifier : SharedBase
- (instancetype)initWithPath:(NSArray<id> *)path label:(NSString * _Nullable)label __attribute__((swift_name("init(path:label:)"))) __attribute__((objc_designated_initializer));
- (SharedApollo_apiDeferredFragmentIdentifier *)doCopyPath:(NSArray<id> *)path label:(NSString * _Nullable)label __attribute__((swift_name("doCopy(path:label:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable label __attribute__((swift_name("label")));
@property (readonly) NSArray<id> *path __attribute__((swift_name("path")));
@end

__attribute__((swift_name("KotlinComparable")))
@protocol SharedKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end

__attribute__((swift_name("KotlinEnum")))
@interface SharedKotlinEnum<E> : SharedBase <SharedKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly, getter=name_) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiJsonReaderToken")))
@interface SharedApollo_apiJsonReaderToken : SharedKotlinEnum<SharedApollo_apiJsonReaderToken *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedApollo_apiJsonReaderToken *beginArray __attribute__((swift_name("beginArray")));
@property (class, readonly) SharedApollo_apiJsonReaderToken *endArray __attribute__((swift_name("endArray")));
@property (class, readonly) SharedApollo_apiJsonReaderToken *beginObject __attribute__((swift_name("beginObject")));
@property (class, readonly) SharedApollo_apiJsonReaderToken *endObject __attribute__((swift_name("endObject")));
@property (class, readonly) SharedApollo_apiJsonReaderToken *name __attribute__((swift_name("name")));
@property (class, readonly) SharedApollo_apiJsonReaderToken *string __attribute__((swift_name("string")));
@property (class, readonly) SharedApollo_apiJsonReaderToken *number __attribute__((swift_name("number")));
@property (class, readonly) SharedApollo_apiJsonReaderToken *long_ __attribute__((swift_name("long_")));
@property (class, readonly) SharedApollo_apiJsonReaderToken *boolean __attribute__((swift_name("boolean")));
@property (class, readonly) SharedApollo_apiJsonReaderToken *null __attribute__((swift_name("null")));
@property (class, readonly) SharedApollo_apiJsonReaderToken *endDocument __attribute__((swift_name("endDocument")));
@property (class, readonly) SharedApollo_apiJsonReaderToken *any __attribute__((swift_name("any")));
+ (SharedKotlinArray<SharedApollo_apiJsonReaderToken *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<SharedApollo_apiJsonReaderToken *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((swift_name("RuntimeQueryListener")))
@protocol SharedRuntimeQueryListener
@required
- (void)queryResultsChanged __attribute__((swift_name("queryResultsChanged()")));
@end

__attribute__((swift_name("RuntimeQueryResult")))
@protocol SharedRuntimeQueryResult
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)awaitWithCompletionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("await(completionHandler:)")));
@property (readonly) id _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((swift_name("RuntimeSqlPreparedStatement")))
@protocol SharedRuntimeSqlPreparedStatement
@required
- (void)bindBooleanIndex:(int32_t)index boolean:(SharedBoolean * _Nullable)boolean __attribute__((swift_name("bindBoolean(index:boolean:)")));
- (void)bindBytesIndex:(int32_t)index bytes:(SharedKotlinByteArray * _Nullable)bytes __attribute__((swift_name("bindBytes(index:bytes:)")));
- (void)bindDoubleIndex:(int32_t)index double:(SharedDouble * _Nullable)double_ __attribute__((swift_name("bindDouble(index:double:)")));
- (void)bindLongIndex:(int32_t)index long:(SharedLong * _Nullable)long_ __attribute__((swift_name("bindLong(index:long:)")));
- (void)bindStringIndex:(int32_t)index string:(NSString * _Nullable)string __attribute__((swift_name("bindString(index:string:)")));
@end

__attribute__((swift_name("RuntimeSqlCursor")))
@protocol SharedRuntimeSqlCursor
@required
- (SharedBoolean * _Nullable)getBooleanIndex:(int32_t)index __attribute__((swift_name("getBoolean(index:)")));
- (SharedKotlinByteArray * _Nullable)getBytesIndex:(int32_t)index __attribute__((swift_name("getBytes(index:)")));
- (SharedDouble * _Nullable)getDoubleIndex:(int32_t)index __attribute__((swift_name("getDouble(index:)")));
- (SharedLong * _Nullable)getLongIndex:(int32_t)index __attribute__((swift_name("getLong(index:)")));
- (NSString * _Nullable)getStringIndex:(int32_t)index __attribute__((swift_name("getString(index:)")));
- (id<SharedRuntimeQueryResult>)next __attribute__((swift_name("next()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RuntimeAfterVersion")))
@interface SharedRuntimeAfterVersion : SharedBase
- (instancetype)initWithAfterVersion:(int64_t)afterVersion block:(void (^)(id<SharedRuntimeSqlDriver>))block __attribute__((swift_name("init(afterVersion:block:)"))) __attribute__((objc_designated_initializer));
@property (readonly) int64_t afterVersion __attribute__((swift_name("afterVersion")));
@property (readonly) void (^block)(id<SharedRuntimeSqlDriver>) __attribute__((swift_name("block")));
@end

__attribute__((swift_name("Koin_coreLockable")))
@interface SharedKoin_coreLockable : SharedBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreScope")))
@interface SharedKoin_coreScope : SharedKoin_coreLockable
- (instancetype)initWithScopeQualifier:(id<SharedKoin_coreQualifier>)scopeQualifier id:(NSString *)id isRoot:(BOOL)isRoot _koin:(SharedKoin_coreKoin *)_koin __attribute__((swift_name("init(scopeQualifier:id:isRoot:_koin:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (void)close __attribute__((swift_name("close()")));
- (void)declareInstance:(id _Nullable)instance qualifier:(id<SharedKoin_coreQualifier> _Nullable)qualifier secondaryTypes:(NSArray<id<SharedKotlinKClass>> *)secondaryTypes allowOverride:(BOOL)allowOverride __attribute__((swift_name("declare(instance:qualifier:secondaryTypes:allowOverride:)")));
- (id)getQualifier:(id<SharedKoin_coreQualifier> _Nullable)qualifier parameters:(SharedKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("get(qualifier:parameters:)")));
- (id _Nullable)getClazz:(id<SharedKotlinKClass>)clazz qualifier:(id<SharedKoin_coreQualifier> _Nullable)qualifier parameters:(SharedKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("get(clazz:qualifier:parameters:)")));
- (NSArray<id> *)getAll __attribute__((swift_name("getAll()")));
- (NSArray<id> *)getAllClazz:(id<SharedKotlinKClass>)clazz __attribute__((swift_name("getAll(clazz:)")));
- (SharedKoin_coreKoin *)getKoin __attribute__((swift_name("getKoin()")));
- (id _Nullable)getOrNullQualifier:(id<SharedKoin_coreQualifier> _Nullable)qualifier parameters:(SharedKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("getOrNull(qualifier:parameters:)")));
- (id _Nullable)getOrNullClazz:(id<SharedKotlinKClass>)clazz qualifier:(id<SharedKoin_coreQualifier> _Nullable)qualifier parameters:(SharedKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("getOrNull(clazz:qualifier:parameters:)")));
- (id)getPropertyKey:(NSString *)key __attribute__((swift_name("getProperty(key:)")));
- (id)getPropertyKey:(NSString *)key defaultValue:(id)defaultValue __attribute__((swift_name("getProperty(key:defaultValue:)")));
- (id _Nullable)getPropertyOrNullKey:(NSString *)key __attribute__((swift_name("getPropertyOrNull(key:)")));
- (SharedKoin_coreScope *)getScopeScopeID:(NSString *)scopeID __attribute__((swift_name("getScope(scopeID:)")));
- (id _Nullable)getSource __attribute__((swift_name("getSource()")));
- (id<SharedKotlinLazy>)injectQualifier:(id<SharedKoin_coreQualifier> _Nullable)qualifier mode:(SharedKotlinLazyThreadSafetyMode *)mode parameters:(SharedKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("inject(qualifier:mode:parameters:)")));
- (id<SharedKotlinLazy>)injectOrNullQualifier:(id<SharedKoin_coreQualifier> _Nullable)qualifier mode:(SharedKotlinLazyThreadSafetyMode *)mode parameters:(SharedKoin_coreParametersHolder *(^ _Nullable)(void))parameters __attribute__((swift_name("injectOrNull(qualifier:mode:parameters:)")));
- (BOOL)isNotClosed __attribute__((swift_name("isNotClosed()")));
- (void)linkToScopes:(SharedKotlinArray<SharedKoin_coreScope *> *)scopes __attribute__((swift_name("linkTo(scopes:)")));
- (void)registerCallbackCallback:(id<SharedKoin_coreScopeCallback>)callback __attribute__((swift_name("registerCallback(callback:)")));
- (NSString *)description __attribute__((swift_name("description()")));
- (void)unlinkScopes:(SharedKotlinArray<SharedKoin_coreScope *> *)scopes __attribute__((swift_name("unlink(scopes:)")));
@property (readonly) SharedStately_concurrencyThreadLocalRef<NSMutableArray<SharedKoin_coreParametersHolder *> *> *_parameterStackLocal __attribute__((swift_name("_parameterStackLocal")));
@property id _Nullable _source __attribute__((swift_name("_source")));
@property (readonly) BOOL closed __attribute__((swift_name("closed")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) BOOL isRoot __attribute__((swift_name("isRoot")));
@property (readonly) SharedKoin_coreLogger *logger __attribute__((swift_name("logger")));
@property (readonly) id<SharedKoin_coreQualifier> scopeQualifier __attribute__((swift_name("scopeQualifier")));
@end

__attribute__((swift_name("Koin_coreKoinScopeComponent")))
@protocol SharedKoin_coreKoinScopeComponent <SharedKoin_coreKoinComponent>
@required
- (void)closeScope __attribute__((swift_name("closeScope()"))) __attribute__((deprecated("not used internaly anymore")));
@property (readonly) SharedKoin_coreScope *scope __attribute__((swift_name("scope")));
@end

__attribute__((swift_name("Koin_coreQualifier")))
@protocol SharedKoin_coreQualifier
@required
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((swift_name("KotlinKDeclarationContainer")))
@protocol SharedKotlinKDeclarationContainer
@required
@end

__attribute__((swift_name("KotlinKAnnotatedElement")))
@protocol SharedKotlinKAnnotatedElement
@required
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((swift_name("KotlinKClassifier")))
@protocol SharedKotlinKClassifier
@required
@end

__attribute__((swift_name("KotlinKClass")))
@protocol SharedKotlinKClass <SharedKotlinKDeclarationContainer, SharedKotlinKAnnotatedElement, SharedKotlinKClassifier>
@required

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
- (BOOL)isInstanceValue:(id _Nullable)value __attribute__((swift_name("isInstance(value:)")));
@property (readonly) NSString * _Nullable qualifiedName __attribute__((swift_name("qualifiedName")));
@property (readonly) NSString * _Nullable simpleName __attribute__((swift_name("simpleName")));
@end

__attribute__((swift_name("Koin_coreParametersHolder")))
@interface SharedKoin_coreParametersHolder : SharedBase
- (instancetype)initWith_values:(NSMutableArray<id> *)_values useIndexedValues:(SharedBoolean * _Nullable)useIndexedValues __attribute__((swift_name("init(_values:useIndexedValues:)"))) __attribute__((objc_designated_initializer));
- (SharedKoin_coreParametersHolder *)addValue:(id)value __attribute__((swift_name("add(value:)")));
- (id _Nullable)component1 __attribute__((swift_name("component1()")));
- (id _Nullable)component2 __attribute__((swift_name("component2()")));
- (id _Nullable)component3 __attribute__((swift_name("component3()")));
- (id _Nullable)component4 __attribute__((swift_name("component4()")));
- (id _Nullable)component5 __attribute__((swift_name("component5()")));
- (id _Nullable)elementAtI:(int32_t)i clazz:(id<SharedKotlinKClass>)clazz __attribute__((swift_name("elementAt(i:clazz:)")));
- (id)get __attribute__((swift_name("get()")));
- (id _Nullable)getI:(int32_t)i __attribute__((swift_name("get(i:)")));
- (id _Nullable)getOrNull __attribute__((swift_name("getOrNull()")));
- (id _Nullable)getOrNullClazz:(id<SharedKotlinKClass>)clazz __attribute__((swift_name("getOrNull(clazz:)")));
- (SharedKoin_coreParametersHolder *)insertIndex:(int32_t)index value:(id)value __attribute__((swift_name("insert(index:value:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (BOOL)isNotEmpty __attribute__((swift_name("isNotEmpty()")));
- (void)setI:(int32_t)i t:(id _Nullable)t __attribute__((swift_name("set(i:t:)")));
- (int32_t)size __attribute__((swift_name("size()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property int32_t index __attribute__((swift_name("index")));
@property (readonly) SharedBoolean * _Nullable useIndexedValues __attribute__((swift_name("useIndexedValues")));
@property (readonly) NSArray<id> *values __attribute__((swift_name("values")));
@end

__attribute__((swift_name("KotlinLazy")))
@protocol SharedKotlinLazy
@required
- (BOOL)isInitialized __attribute__((swift_name("isInitialized()")));
@property (readonly) id _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinLazyThreadSafetyMode")))
@interface SharedKotlinLazyThreadSafetyMode : SharedKotlinEnum<SharedKotlinLazyThreadSafetyMode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKotlinLazyThreadSafetyMode *synchronized __attribute__((swift_name("synchronized")));
@property (class, readonly) SharedKotlinLazyThreadSafetyMode *publication __attribute__((swift_name("publication")));
@property (class, readonly) SharedKotlinLazyThreadSafetyMode *none __attribute__((swift_name("none")));
+ (SharedKotlinArray<SharedKotlinLazyThreadSafetyMode *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<SharedKotlinLazyThreadSafetyMode *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((swift_name("Koin_coreLogger")))
@interface SharedKoin_coreLogger : SharedBase
- (instancetype)initWithLevel:(SharedKoin_coreLevel *)level __attribute__((swift_name("init(level:)"))) __attribute__((objc_designated_initializer));
- (void)debugMsg:(NSString *)msg __attribute__((swift_name("debug(msg:)")));
- (void)displayLevel:(SharedKoin_coreLevel *)level msg:(NSString *)msg __attribute__((swift_name("display(level:msg:)")));
- (void)errorMsg:(NSString *)msg __attribute__((swift_name("error(msg:)")));
- (void)infoMsg:(NSString *)msg __attribute__((swift_name("info(msg:)")));
- (BOOL)isAtLvl:(SharedKoin_coreLevel *)lvl __attribute__((swift_name("isAt(lvl:)")));
- (void)logLvl:(SharedKoin_coreLevel *)lvl msg:(NSString *(^)(void))msg __attribute__((swift_name("log(lvl:msg:)")));
- (void)logLvl:(SharedKoin_coreLevel *)lvl msg_:(NSString *)msg __attribute__((swift_name("log(lvl:msg_:)")));
- (void)warnMsg:(NSString *)msg __attribute__((swift_name("warn(msg:)")));
@property SharedKoin_coreLevel *level __attribute__((swift_name("level")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreExtensionManager")))
@interface SharedKoin_coreExtensionManager : SharedBase
- (instancetype)initWith_koin:(SharedKoin_coreKoin *)_koin __attribute__((swift_name("init(_koin:)"))) __attribute__((objc_designated_initializer));
- (void)close __attribute__((swift_name("close()")));
- (id<SharedKoin_coreKoinExtension>)getExtensionId:(NSString *)id __attribute__((swift_name("getExtension(id:)")));
- (id<SharedKoin_coreKoinExtension> _Nullable)getExtensionOrNullId:(NSString *)id __attribute__((swift_name("getExtensionOrNull(id:)")));
- (void)registerExtensionId:(NSString *)id extension:(id<SharedKoin_coreKoinExtension>)extension __attribute__((swift_name("registerExtension(id:extension:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreInstanceRegistry")))
@interface SharedKoin_coreInstanceRegistry : SharedBase
- (instancetype)initWith_koin:(SharedKoin_coreKoin *)_koin __attribute__((swift_name("init(_koin:)"))) __attribute__((objc_designated_initializer));
- (void)saveMappingAllowOverride:(BOOL)allowOverride mapping:(NSString *)mapping factory:(SharedKoin_coreInstanceFactory<id> *)factory logWarning:(BOOL)logWarning __attribute__((swift_name("saveMapping(allowOverride:mapping:factory:logWarning:)")));
- (int32_t)size __attribute__((swift_name("size()")));
@property (readonly) SharedKoin_coreKoin *_koin __attribute__((swift_name("_koin")));
@property (readonly) NSDictionary<NSString *, SharedKoin_coreInstanceFactory<id> *> *instances __attribute__((swift_name("instances")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_corePropertyRegistry")))
@interface SharedKoin_corePropertyRegistry : SharedBase
- (instancetype)initWith_koin:(SharedKoin_coreKoin *)_koin __attribute__((swift_name("init(_koin:)"))) __attribute__((objc_designated_initializer));
- (void)close __attribute__((swift_name("close()")));
- (void)deletePropertyKey:(NSString *)key __attribute__((swift_name("deleteProperty(key:)")));
- (id _Nullable)getPropertyKey:(NSString *)key __attribute__((swift_name("getProperty(key:)")));
- (void)savePropertiesProperties:(NSDictionary<NSString *, id> *)properties __attribute__((swift_name("saveProperties(properties:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreScopeRegistry")))
@interface SharedKoin_coreScopeRegistry : SharedBase
- (instancetype)initWith_koin:(SharedKoin_coreKoin *)_koin __attribute__((swift_name("init(_koin:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKoin_coreScopeRegistryCompanion *companion __attribute__((swift_name("companion")));
- (void)loadScopesModules:(NSSet<SharedKoin_coreModule *> *)modules __attribute__((swift_name("loadScopes(modules:)")));
@property (readonly) SharedKoin_coreScope *rootScope __attribute__((swift_name("rootScope")));
@property (readonly) NSSet<id<SharedKoin_coreQualifier>> *scopeDefinitions __attribute__((swift_name("scopeDefinitions")));
@end

__attribute__((swift_name("KotlinIterator")))
@protocol SharedKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext_()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiError.Location")))
@interface SharedApollo_apiErrorLocation : SharedBase
- (instancetype)initWithLine:(int32_t)line column:(int32_t)column __attribute__((swift_name("init(line:column:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t column __attribute__((swift_name("column")));
@property (readonly) int32_t line __attribute__((swift_name("line")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiHttpRequest.Builder")))
@interface SharedApollo_apiHttpRequestBuilder : SharedBase
- (instancetype)initWithMethod:(SharedApollo_apiHttpMethod *)method url:(NSString *)url __attribute__((swift_name("init(method:url:)"))) __attribute__((objc_designated_initializer));
- (SharedApollo_apiHttpRequestBuilder *)addExecutionContextExecutionContext:(id<SharedApollo_apiExecutionContext>)executionContext __attribute__((swift_name("addExecutionContext(executionContext:)")));
- (SharedApollo_apiHttpRequestBuilder *)addHeaderName:(NSString *)name value:(NSString *)value __attribute__((swift_name("addHeader(name:value:)")));
- (SharedApollo_apiHttpRequestBuilder *)addHeadersHeaders:(NSArray<SharedApollo_apiHttpHeader *> *)headers __attribute__((swift_name("addHeaders(headers:)")));
- (SharedApollo_apiHttpRequestBuilder *)bodyBody:(id<SharedApollo_apiHttpBody>)body __attribute__((swift_name("body(body:)")));
- (SharedApollo_apiHttpRequest *)build __attribute__((swift_name("build()")));
- (SharedApollo_apiHttpRequestBuilder *)headersHeaders:(NSArray<SharedApollo_apiHttpHeader *> *)headers __attribute__((swift_name("headers(headers:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiHttpMethod")))
@interface SharedApollo_apiHttpMethod : SharedKotlinEnum<SharedApollo_apiHttpMethod *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedApollo_apiHttpMethod *get __attribute__((swift_name("get")));
@property (class, readonly) SharedApollo_apiHttpMethod *post __attribute__((swift_name("post")));
+ (SharedKotlinArray<SharedApollo_apiHttpMethod *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<SharedApollo_apiHttpMethod *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((swift_name("Apollo_apiHttpBody")))
@protocol SharedApollo_apiHttpBody
@required
- (void)writeToBufferedSink:(id<SharedOkioBufferedSink>)bufferedSink __attribute__((swift_name("writeTo(bufferedSink:)")));
@property (readonly) int64_t contentLength __attribute__((swift_name("contentLength")));
@property (readonly) NSString *contentType __attribute__((swift_name("contentType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiHttpHeader")))
@interface SharedApollo_apiHttpHeader : SharedBase
- (instancetype)initWithName:(NSString *)name value:(NSString *)value __attribute__((swift_name("init(name:value:)"))) __attribute__((objc_designated_initializer));
- (SharedApollo_apiHttpHeader *)doCopyName:(NSString *)name value:(NSString *)value __attribute__((swift_name("doCopy(name:value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiHttpResponse.Builder")))
@interface SharedApollo_apiHttpResponseBuilder : SharedBase
- (instancetype)initWithStatusCode:(int32_t)statusCode __attribute__((swift_name("init(statusCode:)"))) __attribute__((objc_designated_initializer));
- (SharedApollo_apiHttpResponseBuilder *)addHeaderName:(NSString *)name value:(NSString *)value __attribute__((swift_name("addHeader(name:value:)")));
- (SharedApollo_apiHttpResponseBuilder *)addHeadersHeaders:(NSArray<SharedApollo_apiHttpHeader *> *)headers __attribute__((swift_name("addHeaders(headers:)")));
- (SharedApollo_apiHttpResponseBuilder *)bodyBodySource:(id<SharedOkioBufferedSource>)bodySource __attribute__((swift_name("body(bodySource:)")));
- (SharedApollo_apiHttpResponseBuilder *)bodyBodyString:(SharedOkioByteString *)bodyString __attribute__((swift_name("body(bodyString:)"))) __attribute__((deprecated("Use body(BufferedSource) instead")));
- (SharedApollo_apiHttpResponse *)build __attribute__((swift_name("build()")));
- (SharedApollo_apiHttpResponseBuilder *)headersHeaders:(NSArray<SharedApollo_apiHttpHeader *> *)headers __attribute__((swift_name("headers(headers:)")));
@property (readonly) int32_t statusCode __attribute__((swift_name("statusCode")));
@end

__attribute__((swift_name("OkioSource")))
@protocol SharedOkioSource <SharedOkioCloseable>
@required

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (int64_t)readSink:(SharedOkioBuffer *)sink byteCount:(int64_t)byteCount error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("read(sink:byteCount:)"))) __attribute__((swift_error(nonnull_error)));
- (SharedOkioTimeout *)timeout __attribute__((swift_name("timeout()")));
@end

__attribute__((swift_name("OkioBufferedSource")))
@protocol SharedOkioBufferedSource <SharedOkioSource>
@required
- (BOOL)exhausted __attribute__((swift_name("exhausted()")));
- (int64_t)indexOfB:(int8_t)b __attribute__((swift_name("indexOf(b:)")));
- (int64_t)indexOfBytes:(SharedOkioByteString *)bytes __attribute__((swift_name("indexOf(bytes:)")));
- (int64_t)indexOfB:(int8_t)b fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOf(b:fromIndex:)")));
- (int64_t)indexOfBytes:(SharedOkioByteString *)bytes fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOf(bytes:fromIndex:)")));
- (int64_t)indexOfB:(int8_t)b fromIndex:(int64_t)fromIndex toIndex:(int64_t)toIndex __attribute__((swift_name("indexOf(b:fromIndex:toIndex:)")));
- (int64_t)indexOfElementTargetBytes:(SharedOkioByteString *)targetBytes __attribute__((swift_name("indexOfElement(targetBytes:)")));
- (int64_t)indexOfElementTargetBytes:(SharedOkioByteString *)targetBytes fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOfElement(targetBytes:fromIndex:)")));
- (id<SharedOkioBufferedSource>)peek __attribute__((swift_name("peek_()")));
- (BOOL)rangeEqualsOffset:(int64_t)offset bytes:(SharedOkioByteString *)bytes __attribute__((swift_name("rangeEquals(offset:bytes:)")));
- (BOOL)rangeEqualsOffset:(int64_t)offset bytes:(SharedOkioByteString *)bytes bytesOffset:(int32_t)bytesOffset byteCount:(int32_t)byteCount __attribute__((swift_name("rangeEquals(offset:bytes:bytesOffset:byteCount:)")));
- (int32_t)readSink:(SharedKotlinByteArray *)sink __attribute__((swift_name("read(sink:)")));
- (int32_t)readSink:(SharedKotlinByteArray *)sink offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("read(sink:offset:byteCount:)")));
- (int64_t)readAllSink:(id<SharedOkioSink>)sink __attribute__((swift_name("readAll(sink:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (SharedKotlinByteArray *)readByteArray __attribute__((swift_name("readByteArray()")));
- (SharedKotlinByteArray *)readByteArrayByteCount:(int64_t)byteCount __attribute__((swift_name("readByteArray(byteCount:)")));
- (SharedOkioByteString *)readByteString __attribute__((swift_name("readByteString()")));
- (SharedOkioByteString *)readByteStringByteCount:(int64_t)byteCount __attribute__((swift_name("readByteString(byteCount:)")));
- (int64_t)readDecimalLong __attribute__((swift_name("readDecimalLong()")));
- (void)readFullySink:(SharedKotlinByteArray *)sink __attribute__((swift_name("readFully(sink:)")));
- (void)readFullySink:(SharedOkioBuffer *)sink byteCount:(int64_t)byteCount __attribute__((swift_name("readFully(sink:byteCount:)")));
- (int64_t)readHexadecimalUnsignedLong __attribute__((swift_name("readHexadecimalUnsignedLong()")));
- (int32_t)readInt __attribute__((swift_name("readInt()")));
- (int32_t)readIntLe __attribute__((swift_name("readIntLe()")));
- (int64_t)readLong __attribute__((swift_name("readLong()")));
- (int64_t)readLongLe __attribute__((swift_name("readLongLe()")));
- (int16_t)readShort __attribute__((swift_name("readShort()")));
- (int16_t)readShortLe __attribute__((swift_name("readShortLe()")));
- (NSString *)readUtf8 __attribute__((swift_name("readUtf8()")));
- (NSString *)readUtf8ByteCount:(int64_t)byteCount __attribute__((swift_name("readUtf8(byteCount:)")));
- (int32_t)readUtf8CodePoint __attribute__((swift_name("readUtf8CodePoint()")));
- (NSString * _Nullable)readUtf8Line __attribute__((swift_name("readUtf8Line()")));
- (NSString *)readUtf8LineStrict __attribute__((swift_name("readUtf8LineStrict()")));
- (NSString *)readUtf8LineStrictLimit:(int64_t)limit __attribute__((swift_name("readUtf8LineStrict(limit:)")));
- (BOOL)requestByteCount:(int64_t)byteCount __attribute__((swift_name("request(byteCount:)")));
- (void)requireByteCount:(int64_t)byteCount __attribute__((swift_name("require(byteCount:)")));
- (int32_t)selectOptions:(NSArray<SharedOkioByteString *> *)options __attribute__((swift_name("select(options:)")));
- (id _Nullable)selectOptions_:(NSArray<id> *)options __attribute__((swift_name("select(options_:)")));
- (void)skipByteCount:(int64_t)byteCount __attribute__((swift_name("skip(byteCount:)")));
@property (readonly) SharedOkioBuffer *buffer __attribute__((swift_name("buffer")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_runtimeApolloClient.Companion")))
@interface SharedApollo_runtimeApolloClientCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedApollo_runtimeApolloClientCompanion *shared __attribute__((swift_name("shared")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedApollo_runtimeApolloClientBuilder *)builder __attribute__((swift_name("builder()"))) __attribute__((unavailable("Used for backward compatibility with 2.x")));
@end

__attribute__((swift_name("Apollo_apiMutationData")))
@protocol SharedApollo_apiMutationData <SharedApollo_apiOperationData>
@required
@end

__attribute__((swift_name("Apollo_apiMutableExecutionOptions")))
@protocol SharedApollo_apiMutableExecutionOptions <SharedApollo_apiExecutionOptions>
@required
- (id _Nullable)addExecutionContextExecutionContext:(id<SharedApollo_apiExecutionContext>)executionContext __attribute__((swift_name("addExecutionContext(executionContext:)")));
- (id _Nullable)addHttpHeaderName:(NSString *)name value:(NSString *)value __attribute__((swift_name("addHttpHeader(name:value:)")));
- (id _Nullable)canBeBatchedCanBeBatched:(SharedBoolean * _Nullable)canBeBatched __attribute__((swift_name("canBeBatched(canBeBatched:)")));
- (id _Nullable)enableAutoPersistedQueriesEnableAutoPersistedQueries:(SharedBoolean * _Nullable)enableAutoPersistedQueries __attribute__((swift_name("enableAutoPersistedQueries(enableAutoPersistedQueries:)")));
- (id _Nullable)httpHeadersHttpHeaders:(NSArray<SharedApollo_apiHttpHeader *> * _Nullable)httpHeaders __attribute__((swift_name("httpHeaders(httpHeaders:)")));
- (id _Nullable)httpMethodHttpMethod:(SharedApollo_apiHttpMethod * _Nullable)httpMethod __attribute__((swift_name("httpMethod(httpMethod:)")));
- (id _Nullable)sendApqExtensionsSendApqExtensions:(SharedBoolean * _Nullable)sendApqExtensions __attribute__((swift_name("sendApqExtensions(sendApqExtensions:)")));
- (id _Nullable)sendDocumentSendDocument:(SharedBoolean * _Nullable)sendDocument __attribute__((swift_name("sendDocument(sendDocument:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_runtimeApolloCall")))
@interface SharedApollo_runtimeApolloCall<D> : SharedBase <SharedApollo_apiMutableExecutionOptions>
- (SharedApollo_runtimeApolloCall<D> *)addExecutionContextExecutionContext:(id<SharedApollo_apiExecutionContext>)executionContext __attribute__((swift_name("addExecutionContext(executionContext:)")));
- (SharedApollo_runtimeApolloCall<D> *)addHttpHeaderName:(NSString *)name value:(NSString *)value __attribute__((swift_name("addHttpHeader(name:value:)")));
- (SharedApollo_runtimeApolloCall<D> *)canBeBatchedCanBeBatched:(SharedBoolean * _Nullable)canBeBatched __attribute__((swift_name("canBeBatched(canBeBatched:)")));
- (SharedApollo_runtimeApolloCall<D> *)doCopy __attribute__((swift_name("doCopy()")));
- (SharedApollo_runtimeApolloCall<D> *)enableAutoPersistedQueriesEnableAutoPersistedQueries:(SharedBoolean * _Nullable)enableAutoPersistedQueries __attribute__((swift_name("enableAutoPersistedQueries(enableAutoPersistedQueries:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeWithCompletionHandler:(void (^)(SharedApollo_apiApolloResponse<D> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeV3WithCompletionHandler:(void (^)(SharedApollo_apiApolloResponse<D> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("executeV3(completionHandler:)"))) __attribute__((deprecated("Use execute() and handle ApolloResponse.exception instead")));
- (SharedApollo_runtimeApolloCall<D> *)failFastIfOfflineFailFastIfOffline:(SharedBoolean * _Nullable)failFastIfOffline __attribute__((swift_name("failFastIfOffline(failFastIfOffline:)")));
- (SharedApollo_runtimeApolloCall<D> *)httpHeadersHttpHeaders:(NSArray<SharedApollo_apiHttpHeader *> * _Nullable)httpHeaders __attribute__((swift_name("httpHeaders(httpHeaders:)")));
- (SharedApollo_runtimeApolloCall<D> *)httpMethodHttpMethod:(SharedApollo_apiHttpMethod * _Nullable)httpMethod __attribute__((swift_name("httpMethod(httpMethod:)")));
- (SharedApollo_runtimeApolloCall<D> *)ignoreApolloClientHttpHeadersIgnoreApolloClientHttpHeaders:(SharedBoolean * _Nullable)ignoreApolloClientHttpHeaders __attribute__((swift_name("ignoreApolloClientHttpHeaders(ignoreApolloClientHttpHeaders:)")));

/**
 * @note annotations
 *   com.apollographql.apollo3.annotations.ApolloExperimental
*/
- (SharedApollo_runtimeApolloCall<D> *)retryOnErrorRetryOnError:(SharedBoolean * _Nullable)retryOnError __attribute__((swift_name("retryOnError(retryOnError:)")));
- (SharedApollo_runtimeApolloCall<D> *)sendApqExtensionsSendApqExtensions:(SharedBoolean * _Nullable)sendApqExtensions __attribute__((swift_name("sendApqExtensions(sendApqExtensions:)")));
- (SharedApollo_runtimeApolloCall<D> *)sendDocumentSendDocument:(SharedBoolean * _Nullable)sendDocument __attribute__((swift_name("sendDocument(sendDocument:)")));
- (id<SharedKotlinx_coroutines_coreFlow>)toFlow __attribute__((swift_name("toFlow()")));
- (id<SharedKotlinx_coroutines_coreFlow>)toFlowV3 __attribute__((swift_name("toFlowV3()"))) __attribute__((deprecated("Use toFlow() and handle ApolloResponse.exception instead")));
@property (readonly) SharedBoolean * _Nullable canBeBatched __attribute__((swift_name("canBeBatched")));
@property (readonly) SharedBoolean * _Nullable enableAutoPersistedQueries __attribute__((swift_name("enableAutoPersistedQueries")));
@property (readonly) id<SharedApollo_apiExecutionContext> executionContext __attribute__((swift_name("executionContext")));

/**
 * @note annotations
 *   com.apollographql.apollo3.annotations.ApolloExperimental
*/
@property (readonly) SharedBoolean * _Nullable failFastIfOffline __attribute__((swift_name("failFastIfOffline")));
@property (readonly) NSArray<SharedApollo_apiHttpHeader *> * _Nullable httpHeaders __attribute__((swift_name("httpHeaders")));
@property (readonly) SharedApollo_apiHttpMethod * _Nullable httpMethod __attribute__((swift_name("httpMethod")));
@property (readonly) SharedBoolean * _Nullable ignoreApolloClientHttpHeaders __attribute__((swift_name("ignoreApolloClientHttpHeaders")));
@property (readonly) id<SharedApollo_apiOperation> operation __attribute__((swift_name("operation")));

/**
 * @note annotations
 *   com.apollographql.apollo3.annotations.ApolloExperimental
*/
@property (readonly) SharedBoolean * _Nullable retryOnError __attribute__((swift_name("retryOnError")));
@property (readonly) SharedBoolean * _Nullable sendApqExtensions __attribute__((swift_name("sendApqExtensions")));
@property (readonly) SharedBoolean * _Nullable sendDocument __attribute__((swift_name("sendDocument")));
@end

__attribute__((swift_name("Apollo_apiMutation")))
@protocol SharedApollo_apiMutation <SharedApollo_apiOperation>
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_runtimeApolloClient.Builder")))
@interface SharedApollo_runtimeApolloClientBuilder : SharedBase <SharedApollo_apiMutableExecutionOptions>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (SharedApollo_runtimeApolloClientBuilder *)addCustomScalarAdapterCustomScalarType:(SharedApollo_apiCustomScalarType *)customScalarType customScalarAdapter:(id<SharedApollo_apiAdapter>)customScalarAdapter __attribute__((swift_name("addCustomScalarAdapter(customScalarType:customScalarAdapter:)")));
- (SharedApollo_runtimeApolloClientBuilder *)addExecutionContextExecutionContext:(id<SharedApollo_apiExecutionContext>)executionContext __attribute__((swift_name("addExecutionContext(executionContext:)")));
- (SharedApollo_runtimeApolloClientBuilder *)addHttpHeaderName:(NSString *)name value:(NSString *)value __attribute__((swift_name("addHttpHeader(name:value:)")));
- (SharedApollo_runtimeApolloClientBuilder *)addHttpInterceptorHttpInterceptor:(id<SharedApollo_runtimeHttpInterceptor>)httpInterceptor __attribute__((swift_name("addHttpInterceptor(httpInterceptor:)")));
- (SharedApollo_runtimeApolloClientBuilder *)addInterceptorInterceptor:(id<SharedApollo_runtimeApolloInterceptor>)interceptor __attribute__((swift_name("addInterceptor(interceptor:)")));
- (SharedApollo_runtimeApolloClientBuilder *)addInterceptorsInterceptors:(NSArray<id<SharedApollo_runtimeApolloInterceptor>> *)interceptors __attribute__((swift_name("addInterceptors(interceptors:)"))) __attribute__((deprecated("Use addInterceptor() or interceptors()")));
- (SharedApollo_runtimeApolloClientBuilder *)addListenerListener:(id<SharedApollo_runtimeApolloClientListener>)listener __attribute__((swift_name("addListener(listener:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (SharedApollo_runtimeApolloClientBuilder *)autoPersistedQueriesHttpMethodForHashedQueries:(SharedApollo_apiHttpMethod *)httpMethodForHashedQueries httpMethodForDocumentQueries:(SharedApollo_apiHttpMethod *)httpMethodForDocumentQueries enableByDefault:(BOOL)enableByDefault __attribute__((swift_name("autoPersistedQueries(httpMethodForHashedQueries:httpMethodForDocumentQueries:enableByDefault:)")));
- (SharedApollo_runtimeApolloClient *)build __attribute__((swift_name("build()")));
- (SharedApollo_runtimeApolloClientBuilder *)canBeBatchedCanBeBatched:(SharedBoolean * _Nullable)canBeBatched __attribute__((swift_name("canBeBatched(canBeBatched:)")));
- (SharedApollo_runtimeApolloClientBuilder *)doCopy __attribute__((swift_name("doCopy()")));
- (SharedApollo_runtimeApolloClientBuilder *)customScalarAdaptersCustomScalarAdapters:(SharedApollo_apiCustomScalarAdapters *)customScalarAdapters __attribute__((swift_name("customScalarAdapters(customScalarAdapters:)")));
- (SharedApollo_runtimeApolloClientBuilder *)dispatcherDispatcher:(SharedKotlinx_coroutines_coreCoroutineDispatcher * _Nullable)dispatcher __attribute__((swift_name("dispatcher(dispatcher:)")));
- (SharedApollo_runtimeApolloClientBuilder *)enableAutoPersistedQueriesEnableAutoPersistedQueries:(SharedBoolean * _Nullable)enableAutoPersistedQueries __attribute__((swift_name("enableAutoPersistedQueries(enableAutoPersistedQueries:)")));
- (SharedApollo_runtimeApolloClientBuilder *)executionContextExecutionContext:(id<SharedApollo_apiExecutionContext>)executionContext __attribute__((swift_name("executionContext(executionContext:)")));

/**
 * @note annotations
 *   com.apollographql.apollo3.annotations.ApolloExperimental
*/
- (SharedApollo_runtimeApolloClientBuilder *)failFastIfOfflineFailFastIfOffline:(SharedBoolean * _Nullable)failFastIfOffline __attribute__((swift_name("failFastIfOffline(failFastIfOffline:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (SharedApollo_runtimeApolloClientBuilder *)httpBatchingBatchIntervalMillis:(int64_t)batchIntervalMillis maxBatchSize:(int32_t)maxBatchSize enableByDefault:(BOOL)enableByDefault __attribute__((swift_name("httpBatching(batchIntervalMillis:maxBatchSize:enableByDefault:)")));
- (SharedApollo_runtimeApolloClientBuilder *)httpEngineHttpEngine:(id<SharedApollo_runtimeHttpEngine> _Nullable)httpEngine __attribute__((swift_name("httpEngine(httpEngine:)")));
- (SharedApollo_runtimeApolloClientBuilder *)httpExposeErrorBodyHttpExposeErrorBody:(SharedBoolean * _Nullable)httpExposeErrorBody __attribute__((swift_name("httpExposeErrorBody(httpExposeErrorBody:)")));
- (SharedApollo_runtimeApolloClientBuilder *)httpHeadersHttpHeaders:(NSArray<SharedApollo_apiHttpHeader *> * _Nullable)httpHeaders __attribute__((swift_name("httpHeaders(httpHeaders:)")));
- (SharedApollo_runtimeApolloClientBuilder *)httpInterceptorsHttpInterceptors:(NSArray<id<SharedApollo_runtimeHttpInterceptor>> *)httpInterceptors __attribute__((swift_name("httpInterceptors(httpInterceptors:)")));
- (SharedApollo_runtimeApolloClientBuilder *)httpMethodHttpMethod:(SharedApollo_apiHttpMethod * _Nullable)httpMethod __attribute__((swift_name("httpMethod(httpMethod:)")));
- (SharedApollo_runtimeApolloClientBuilder *)httpServerUrlHttpServerUrl:(NSString * _Nullable)httpServerUrl __attribute__((swift_name("httpServerUrl(httpServerUrl:)")));
- (SharedApollo_runtimeApolloClientBuilder *)interceptorsInterceptors:(NSArray<id<SharedApollo_runtimeApolloInterceptor>> *)interceptors __attribute__((swift_name("interceptors(interceptors:)")));
- (SharedApollo_runtimeApolloClientBuilder *)listenersListeners:(NSArray<id<SharedApollo_runtimeApolloClientListener>> *)listeners __attribute__((swift_name("listeners(listeners:)")));

/**
 * @note annotations
 *   com.apollographql.apollo3.annotations.ApolloExperimental
*/
- (SharedApollo_runtimeApolloClientBuilder *)networkMonitorNetworkMonitor:(id<SharedApollo_runtimeNetworkMonitor> _Nullable)networkMonitor __attribute__((swift_name("networkMonitor(networkMonitor:)")));
- (SharedApollo_runtimeApolloClientBuilder *)networkTransportNetworkTransport:(id<SharedApollo_runtimeNetworkTransport> _Nullable)networkTransport __attribute__((swift_name("networkTransport(networkTransport:)")));

/**
 * @note annotations
 *   com.apollographql.apollo3.annotations.ApolloExperimental
*/
- (SharedApollo_runtimeApolloClientBuilder *)retryOnErrorRetryOnError:(SharedBoolean *(^ _Nullable)(SharedApollo_apiApolloRequest<id> *))retryOnError __attribute__((swift_name("retryOnError(retryOnError:)")));
- (SharedApollo_runtimeApolloClientBuilder *)sendApqExtensionsSendApqExtensions:(SharedBoolean * _Nullable)sendApqExtensions __attribute__((swift_name("sendApqExtensions(sendApqExtensions:)")));
- (SharedApollo_runtimeApolloClientBuilder *)sendDocumentSendDocument:(SharedBoolean * _Nullable)sendDocument __attribute__((swift_name("sendDocument(sendDocument:)")));
- (SharedApollo_runtimeApolloClientBuilder *)serverUrlServerUrl:(NSString *)serverUrl __attribute__((swift_name("serverUrl(serverUrl:)")));
- (SharedApollo_runtimeApolloClientBuilder *)subscriptionNetworkTransportSubscriptionNetworkTransport:(id<SharedApollo_runtimeNetworkTransport> _Nullable)subscriptionNetworkTransport __attribute__((swift_name("subscriptionNetworkTransport(subscriptionNetworkTransport:)")));
- (SharedApollo_runtimeApolloClientBuilder *)webSocketEngineWebSocketEngine:(id<SharedApollo_runtimeWebSocketEngine> _Nullable)webSocketEngine __attribute__((swift_name("webSocketEngine(webSocketEngine:)")));
- (SharedApollo_runtimeApolloClientBuilder *)webSocketIdleTimeoutMillisWebSocketIdleTimeoutMillis:(SharedLong * _Nullable)webSocketIdleTimeoutMillis __attribute__((swift_name("webSocketIdleTimeoutMillis(webSocketIdleTimeoutMillis:)")));
- (SharedApollo_runtimeApolloClientBuilder *)webSocketReopenWhenWebSocketReopenWhen:(id<SharedKotlinSuspendFunction2> _Nullable)webSocketReopenWhen __attribute__((swift_name("webSocketReopenWhen(webSocketReopenWhen:)")));
- (SharedApollo_runtimeApolloClientBuilder *)webSocketServerUrlWebSocketServerUrl:(NSString * _Nullable)webSocketServerUrl __attribute__((swift_name("webSocketServerUrl(webSocketServerUrl:)")));
- (SharedApollo_runtimeApolloClientBuilder *)webSocketServerUrlWebSocketServerUrl_:(id<SharedKotlinSuspendFunction0> _Nullable)webSocketServerUrl __attribute__((swift_name("webSocketServerUrl(webSocketServerUrl_:)")));
- (SharedApollo_runtimeApolloClientBuilder *)wsProtocolWsProtocolFactory:(id<SharedApollo_runtimeWsProtocolFactory> _Nullable)wsProtocolFactory __attribute__((swift_name("wsProtocol(wsProtocolFactory:)")));
@property (readonly) SharedBoolean * _Nullable canBeBatched __attribute__((swift_name("canBeBatched")));
@property (readonly) SharedApollo_apiCustomScalarAdapters *customScalarAdapters __attribute__((swift_name("customScalarAdapters")));
@property (readonly) SharedKotlinx_coroutines_coreCoroutineDispatcher * _Nullable dispatcher __attribute__((swift_name("dispatcher")));
@property (readonly) SharedBoolean * _Nullable enableAutoPersistedQueries __attribute__((swift_name("enableAutoPersistedQueries")));
@property (readonly) id<SharedApollo_apiExecutionContext> executionContext __attribute__((swift_name("executionContext")));

/**
 * @note annotations
 *   com.apollographql.apollo3.annotations.ApolloExperimental
*/
@property (readonly) SharedBoolean * _Nullable failFastIfOffline __attribute__((swift_name("failFastIfOffline")));
@property (readonly) id<SharedApollo_runtimeHttpEngine> _Nullable httpEngine __attribute__((swift_name("httpEngine")));
@property (readonly) SharedBoolean * _Nullable httpExposeErrorBody __attribute__((swift_name("httpExposeErrorBody")));
@property (readonly) NSArray<SharedApollo_apiHttpHeader *> * _Nullable httpHeaders __attribute__((swift_name("httpHeaders")));
@property (readonly) NSArray<id<SharedApollo_runtimeHttpInterceptor>> *httpInterceptors __attribute__((swift_name("httpInterceptors")));
@property (readonly) SharedApollo_apiHttpMethod * _Nullable httpMethod __attribute__((swift_name("httpMethod")));
@property (readonly) NSString * _Nullable httpServerUrl __attribute__((swift_name("httpServerUrl")));
@property (readonly) NSArray<id<SharedApollo_runtimeApolloInterceptor>> *interceptors __attribute__((swift_name("interceptors")));

/**
 * @note annotations
 *   com.apollographql.apollo3.annotations.ApolloExperimental
*/
@property (readonly) id<SharedApollo_runtimeNetworkMonitor> _Nullable networkMonitor __attribute__((swift_name("networkMonitor")));
@property (readonly) id<SharedApollo_runtimeNetworkTransport> _Nullable networkTransport __attribute__((swift_name("networkTransport")));

/**
 * @note annotations
 *   com.apollographql.apollo3.annotations.ApolloExperimental
*/
@property (readonly) SharedBoolean *(^ _Nullable retryOnError)(SharedApollo_apiApolloRequest<id> *) __attribute__((swift_name("retryOnError")));
@property (readonly) SharedBoolean * _Nullable sendApqExtensions __attribute__((swift_name("sendApqExtensions")));
@property (readonly) SharedBoolean * _Nullable sendDocument __attribute__((swift_name("sendDocument")));
@property (readonly) id<SharedApollo_runtimeNetworkTransport> _Nullable subscriptionNetworkTransport __attribute__((swift_name("subscriptionNetworkTransport")));
@property (readonly) id<SharedApollo_runtimeWebSocketEngine> _Nullable webSocketEngine __attribute__((swift_name("webSocketEngine")));
@property (readonly) SharedLong * _Nullable webSocketIdleTimeoutMillis __attribute__((swift_name("webSocketIdleTimeoutMillis")));
@property (readonly) id<SharedKotlinSuspendFunction0> _Nullable webSocketReopenServerUrl __attribute__((swift_name("webSocketReopenServerUrl")));
@property (readonly) id<SharedKotlinSuspendFunction2> _Nullable webSocketReopenWhen __attribute__((swift_name("webSocketReopenWhen")));
@property (readonly) NSString * _Nullable webSocketServerUrl __attribute__((swift_name("webSocketServerUrl")));
@property (readonly) id<SharedApollo_runtimeWsProtocolFactory> _Nullable wsProtocolFactory __attribute__((swift_name("wsProtocolFactory")));
@end

__attribute__((swift_name("Apollo_apiSubscriptionData")))
@protocol SharedApollo_apiSubscriptionData <SharedApollo_apiOperationData>
@required
@end

__attribute__((swift_name("Apollo_apiSubscription")))
@protocol SharedApollo_apiSubscription <SharedApollo_apiOperation>
@required
@end

__attribute__((swift_name("Apollo_runtimeNetworkTransport")))
@protocol SharedApollo_runtimeNetworkTransport
@required
- (void)dispose __attribute__((swift_name("dispose()")));
- (id<SharedKotlinx_coroutines_coreFlow>)executeRequest:(SharedApollo_apiApolloRequest<id<SharedApollo_apiOperationData>> *)request __attribute__((swift_name("execute(request:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreFlowCollector")))
@protocol SharedKotlinx_coroutines_coreFlowCollector
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)emitValue:(id _Nullable)value completionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("emit(value:completionHandler:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiApolloRequestBuilder")))
@interface SharedApollo_apiApolloRequestBuilder<D> : SharedBase <SharedApollo_apiMutableExecutionOptions>
- (instancetype)initWithOperation:(id<SharedApollo_apiOperation>)operation __attribute__((swift_name("init(operation:)"))) __attribute__((objc_designated_initializer));
- (SharedApollo_apiApolloRequestBuilder<D> *)addExecutionContextExecutionContext:(id<SharedApollo_apiExecutionContext>)executionContext __attribute__((swift_name("addExecutionContext(executionContext:)")));
- (SharedApollo_apiApolloRequestBuilder<D> *)addHttpHeaderName:(NSString *)name value:(NSString *)value __attribute__((swift_name("addHttpHeader(name:value:)")));
- (SharedApollo_apiApolloRequest<D> *)build __attribute__((swift_name("build()")));
- (SharedApollo_apiApolloRequestBuilder<D> *)canBeBatchedCanBeBatched:(SharedBoolean * _Nullable)canBeBatched __attribute__((swift_name("canBeBatched(canBeBatched:)")));
- (SharedApollo_apiApolloRequestBuilder<D> *)enableAutoPersistedQueriesEnableAutoPersistedQueries:(SharedBoolean * _Nullable)enableAutoPersistedQueries __attribute__((swift_name("enableAutoPersistedQueries(enableAutoPersistedQueries:)")));
- (SharedApollo_apiApolloRequestBuilder<D> *)executionContextExecutionContext:(id<SharedApollo_apiExecutionContext>)executionContext __attribute__((swift_name("executionContext(executionContext:)")));

/**
 * @note annotations
 *   com.apollographql.apollo3.annotations.ApolloExperimental
*/
- (SharedApollo_apiApolloRequestBuilder<D> *)failFastIfOfflineFailFastIfOffline:(SharedBoolean * _Nullable)failFastIfOffline __attribute__((swift_name("failFastIfOffline(failFastIfOffline:)")));
- (SharedApollo_apiApolloRequestBuilder<D> *)httpHeadersHttpHeaders:(NSArray<SharedApollo_apiHttpHeader *> * _Nullable)httpHeaders __attribute__((swift_name("httpHeaders(httpHeaders:)")));
- (SharedApollo_apiApolloRequestBuilder<D> *)httpMethodHttpMethod:(SharedApollo_apiHttpMethod * _Nullable)httpMethod __attribute__((swift_name("httpMethod(httpMethod:)")));
- (SharedApollo_apiApolloRequestBuilder<D> *)ignoreApolloClientHttpHeadersIgnoreApolloClientHttpHeaders:(SharedBoolean * _Nullable)ignoreApolloClientHttpHeaders __attribute__((swift_name("ignoreApolloClientHttpHeaders(ignoreApolloClientHttpHeaders:)")));
- (SharedApollo_apiApolloRequestBuilder<D> *)requestUuidRequestUuid:(SharedUuidUuid *)requestUuid __attribute__((swift_name("requestUuid(requestUuid:)")));

/**
 * @note annotations
 *   com.apollographql.apollo3.annotations.ApolloExperimental
*/
- (SharedApollo_apiApolloRequestBuilder<D> *)retryOnErrorRetryOnError:(SharedBoolean * _Nullable)retryOnError __attribute__((swift_name("retryOnError(retryOnError:)")));
- (SharedApollo_apiApolloRequestBuilder<D> *)sendApqExtensionsSendApqExtensions:(SharedBoolean * _Nullable)sendApqExtensions __attribute__((swift_name("sendApqExtensions(sendApqExtensions:)")));
- (SharedApollo_apiApolloRequestBuilder<D> *)sendDocumentSendDocument:(SharedBoolean * _Nullable)sendDocument __attribute__((swift_name("sendDocument(sendDocument:)")));
@property (readonly) SharedBoolean * _Nullable canBeBatched __attribute__((swift_name("canBeBatched")));
@property (readonly) SharedBoolean * _Nullable enableAutoPersistedQueries __attribute__((swift_name("enableAutoPersistedQueries")));
@property (readonly) id<SharedApollo_apiExecutionContext> executionContext __attribute__((swift_name("executionContext")));

/**
 * @note annotations
 *   com.apollographql.apollo3.annotations.ApolloExperimental
*/
@property (readonly) SharedBoolean * _Nullable failFastIfOffline __attribute__((swift_name("failFastIfOffline")));
@property (readonly) NSArray<SharedApollo_apiHttpHeader *> * _Nullable httpHeaders __attribute__((swift_name("httpHeaders")));
@property (readonly) SharedApollo_apiHttpMethod * _Nullable httpMethod __attribute__((swift_name("httpMethod")));
@property (readonly) SharedBoolean * _Nullable ignoreApolloClientHttpHeaders __attribute__((swift_name("ignoreApolloClientHttpHeaders")));
@property (readonly) id<SharedApollo_apiOperation> operation __attribute__((swift_name("operation")));
@property (readonly) SharedUuidUuid * _Nullable requestUuid __attribute__((swift_name("requestUuid")));

/**
 * @note annotations
 *   com.apollographql.apollo3.annotations.ApolloExperimental
*/
@property (readonly) SharedBoolean * _Nullable retryOnError __attribute__((swift_name("retryOnError")));
@property (readonly) SharedBoolean * _Nullable sendApqExtensions __attribute__((swift_name("sendApqExtensions")));
@property (readonly) SharedBoolean * _Nullable sendDocument __attribute__((swift_name("sendDocument")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UuidUuid")))
@interface SharedUuidUuid : SharedBase <SharedKotlinComparable>
- (instancetype)initWithUuidBytes:(SharedKotlinByteArray *)uuidBytes __attribute__((swift_name("init(uuidBytes:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("Use `uuidOf` instead.")));
- (instancetype)initWithMsb:(int64_t)msb lsb:(int64_t)lsb __attribute__((swift_name("init(msb:lsb:)"))) __attribute__((objc_designated_initializer));
- (int32_t)compareToOther:(SharedUuidUuid *)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t leastSignificantBits __attribute__((swift_name("leastSignificantBits")));
@property (readonly) int64_t mostSignificantBits __attribute__((swift_name("mostSignificantBits")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiObjectType.Builder")))
@interface SharedApollo_apiObjectTypeBuilder : SharedBase
- (instancetype)initWithObjectType:(SharedApollo_apiObjectType *)objectType __attribute__((swift_name("init(objectType:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithName:(NSString *)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
- (SharedApollo_apiObjectType *)build __attribute__((swift_name("build()")));
- (SharedApollo_apiObjectTypeBuilder *)embeddedFieldsEmbeddedFields:(NSArray<NSString *> *)embeddedFields __attribute__((swift_name("embeddedFields(embeddedFields:)")));
- (SharedApollo_apiObjectTypeBuilder *)interfacesImplements:(NSArray<SharedApollo_apiInterfaceType *> *)implements __attribute__((swift_name("interfaces(implements:)")));
- (SharedApollo_apiObjectTypeBuilder *)keyFieldsKeyFields:(NSArray<NSString *> *)keyFields __attribute__((swift_name("keyFields(keyFields:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiInterfaceType")))
@interface SharedApollo_apiInterfaceType : SharedApollo_apiCompiledNamedType
- (SharedApollo_apiInterfaceTypeBuilder *)doNewBuilder __attribute__((swift_name("doNewBuilder()")));
@property (readonly) NSArray<NSString *> *embeddedFields __attribute__((swift_name("embeddedFields")));
@property (readonly) NSArray<SharedApollo_apiInterfaceType *> *implements __attribute__((swift_name("implements")));
@property (readonly) NSArray<NSString *> *keyFields __attribute__((swift_name("keyFields")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiCompiledArgumentDefinition.Builder")))
@interface SharedApollo_apiCompiledArgumentDefinitionBuilder : SharedBase
- (instancetype)initWithArgumentDefinition:(SharedApollo_apiCompiledArgumentDefinition *)argumentDefinition __attribute__((swift_name("init(argumentDefinition:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithName:(NSString *)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
- (SharedApollo_apiCompiledArgumentDefinition *)build __attribute__((swift_name("build()")));
- (SharedApollo_apiCompiledArgumentDefinitionBuilder *)isKeyIsKey:(BOOL)isKey __attribute__((swift_name("isKey(isKey:)")));

/**
 * @note annotations
 *   com.apollographql.apollo3.annotations.ApolloExperimental
*/
- (SharedApollo_apiCompiledArgumentDefinitionBuilder *)isPaginationIsPagination:(BOOL)isPagination __attribute__((swift_name("isPagination(isPagination:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Arrow_coreOptionCompanion")))
@interface SharedArrow_coreOptionCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedArrow_coreOptionCompanion *shared __attribute__((swift_name("shared")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
 *   kotlin.jvm.JvmName(name="tryCatchOrNone")
*/
- (SharedArrow_coreOption<id> *)catchF:(id _Nullable (^)(void))f __attribute__((swift_name("catch(f:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
 *   kotlin.jvm.JvmName(name="tryCatch")
*/
- (SharedArrow_coreOption<id> *)catchRecover:(SharedArrow_coreOption<id> *(^)(SharedKotlinThrowable *))recover f:(id _Nullable (^)(void))f __attribute__((swift_name("catch(recover:f:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedArrow_coreOption<id> *)fromNullableA:(id _Nullable)a __attribute__((swift_name("fromNullable(a:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedArrow_coreOption<id> *)invokeA:(id _Nullable)a __attribute__((swift_name("invoke(a:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedArrow_coreOption<id> *(^)(SharedArrow_coreOption<id> *))liftF:(id _Nullable (^)(id _Nullable))f __attribute__((swift_name("lift(f:)"))) __attribute__((deprecated("This API is considered redundant. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer explicitly creating lambdas")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinPair")))
@interface SharedKotlinPair<__covariant A, __covariant B> : SharedBase
- (instancetype)initWithFirst:(A _Nullable)first second:(B _Nullable)second __attribute__((swift_name("init(first:second:)"))) __attribute__((objc_designated_initializer));
- (SharedKotlinPair<A, B> *)doCopyFirst:(A _Nullable)first second:(B _Nullable)second __attribute__((swift_name("doCopy(first:second:)")));
- (BOOL)equalsOther:(id _Nullable)other __attribute__((swift_name("equals(other:)")));
- (int32_t)hashCode __attribute__((swift_name("hashCode()")));
- (NSString *)toString __attribute__((swift_name("toString()")));
@property (readonly) A _Nullable first __attribute__((swift_name("first")));
@property (readonly) B _Nullable second __attribute__((swift_name("second")));
@end

__attribute__((swift_name("Arrow_coreEval")))
@interface SharedArrow_coreEval<__covariant A> : SharedBase
@property (class, readonly, getter=companion) SharedArrow_coreEvalCompanion *companion __attribute__((swift_name("companion")));
- (SharedArrow_coreEval<id> *)coflatMapF:(id _Nullable (^)(SharedArrow_coreEval<A> *))f __attribute__((swift_name("coflatMap(f:)")));
- (SharedArrow_coreEval<id> *)flatMapF:(SharedArrow_coreEval<id> *(^)(A _Nullable))f __attribute__((swift_name("flatMap(f:)")));
- (SharedArrow_coreEval<id> *)mapF:(id _Nullable (^)(A _Nullable))f __attribute__((swift_name("map(f:)")));
- (SharedArrow_coreEval<A> *)memoize __attribute__((swift_name("memoize()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (A _Nullable)value_ __attribute__((swift_name("value()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Arrow_coreValidatedCompanion")))
@interface SharedArrow_coreValidatedCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedArrow_coreValidatedCompanion *shared __attribute__((swift_name("shared")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
 *   kotlin.jvm.JvmName(name="tryCatch")
*/
- (SharedArrow_coreValidated<SharedKotlinThrowable *, id> *)catchF:(id _Nullable (^)(void))f __attribute__((swift_name("catch(f:)"))) __attribute__((deprecated("Validated functionality is being merged into Either.\nUse Either.catch instead")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
 *   kotlin.jvm.JvmName(name="tryCatch")
*/
- (SharedArrow_coreValidated<id, id> *)catchRecover:(id _Nullable (^)(SharedKotlinThrowable *))recover f:(id _Nullable (^)(void))f __attribute__((swift_name("catch(recover:f:)"))) __attribute__((deprecated("Validated functionality is being merged into Either, but this API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nUse Either.catch and mapLeft instead")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedArrow_coreValidated<NSArray<SharedKotlinThrowable *> *, id> *)catchNelF:(id _Nullable (^)(void))f __attribute__((swift_name("catchNel(f:)"))) __attribute__((deprecated("Validated functionality is being merged into Either, but this API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nUse Either.catch and toEitherNel instead")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedArrow_coreValidated<id, id> *)fromEitherE:(SharedArrow_coreEither<id, id> *)e __attribute__((swift_name("fromEither(e:)"))) __attribute__((deprecated("Validated functionality is being merged into Either.\n")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedArrow_coreValidated<id, id> *)fromNullableValue:(id _Nullable)value ifNull:(id _Nullable (^)(void))ifNull __attribute__((swift_name("fromNullable(value:ifNull:)"))) __attribute__((deprecated("Validated functionality is being merged into Either, but this API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer Kotlin nullable syntax, or ensureNotNull inside Either DSL")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedArrow_coreValidated<id, id> *)fromOptionO:(SharedArrow_coreOption<id> *)o ifNone:(id _Nullable (^)(void))ifNone __attribute__((swift_name("fromOption(o:ifNone:)"))) __attribute__((deprecated("Validated functionality is being merged into Either, but this API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer using toEither on Option instead")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedArrow_coreValidated<NSArray<id> *, id> *)invalidNelE:(id _Nullable)e __attribute__((swift_name("invalidNel(e:)"))) __attribute__((deprecated("Validated functionality is being merged into Either.\nUse leftNel instead to construct the equivalent Either value")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedArrow_coreValidated<id, id> *(^)(SharedArrow_coreValidated<id, id> *))liftF:(id _Nullable (^)(id _Nullable))f __attribute__((swift_name("lift(f:)"))) __attribute__((deprecated("Validated functionality is being merged into Either, but this API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer creating explicit lambdas instead")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedArrow_coreValidated<id, id> *(^)(SharedArrow_coreValidated<id, id> *))liftFl:(id _Nullable (^)(id _Nullable))fl fr:(id _Nullable (^)(id _Nullable))fr __attribute__((swift_name("lift(fl:fr:)"))) __attribute__((deprecated("Validated functionality is being merged into Either, but this API is niche and will be removed in the future. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer creating explicit lambdas instead")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedArrow_coreValidated<NSArray<id> *, id> *)validNelA:(id _Nullable)a __attribute__((swift_name("validNel(a:)"))) __attribute__((deprecated("Validated functionality is being merged into Either.\nUse right instead to construct the equivalent Either value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Arrow_coreIorCompanion")))
@interface SharedArrow_coreIorCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedArrow_coreIorCompanion *shared __attribute__((swift_name("shared")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedArrow_coreIor<NSArray<id> *, id> *)bothNelA:(id _Nullable)a b:(id _Nullable)b __attribute__((swift_name("bothNel(a:b:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedArrow_coreIor<id, id> * _Nullable)fromNullablesA:(id _Nullable)a b:(id _Nullable)b __attribute__((swift_name("fromNullables(a:b:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedArrow_coreIor<NSArray<id> *, id> *)leftNelA:(id _Nullable)a __attribute__((swift_name("leftNel(a:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedArrow_coreIor<id, id> *(^)(SharedArrow_coreIor<id, id> *))liftF:(id _Nullable (^)(id _Nullable))f __attribute__((swift_name("lift(f:)"))) __attribute__((deprecated("This API is considered redundant. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer explicitly creating lambdas")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedArrow_coreIor<id, id> *(^)(SharedArrow_coreIor<id, id> *))liftFa:(id _Nullable (^)(id _Nullable))fa fb:(id _Nullable (^)(id _Nullable))fb __attribute__((swift_name("lift(fa:fb:)"))) __attribute__((deprecated("This API is considered redundant. If this method is crucial for you, please let us know on the Arrow Github. Thanks!\n https://github.com/arrow-kt/arrow/issues\nPrefer explicitly creating lambdas")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreKoinApplication.Companion")))
@interface SharedKoin_coreKoinApplicationCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKoin_coreKoinApplicationCompanion *shared __attribute__((swift_name("shared")));
- (SharedKoin_coreKoinApplication *)doInit __attribute__((swift_name("doInit()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreLevel")))
@interface SharedKoin_coreLevel : SharedKotlinEnum<SharedKoin_coreLevel *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKoin_coreLevel *debug __attribute__((swift_name("debug")));
@property (class, readonly) SharedKoin_coreLevel *info __attribute__((swift_name("info")));
@property (class, readonly) SharedKoin_coreLevel *warning __attribute__((swift_name("warning")));
@property (class, readonly) SharedKoin_coreLevel *error __attribute__((swift_name("error")));
@property (class, readonly) SharedKoin_coreLevel *none __attribute__((swift_name("none")));
+ (SharedKotlinArray<SharedKoin_coreLevel *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<SharedKoin_coreLevel *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreKoinDefinition")))
@interface SharedKoin_coreKoinDefinition<R> : SharedBase
- (instancetype)initWithModule:(SharedKoin_coreModule *)module factory:(SharedKoin_coreInstanceFactory<R> *)factory __attribute__((swift_name("init(module:factory:)"))) __attribute__((objc_designated_initializer));
- (SharedKoin_coreKoinDefinition<R> *)doCopyModule:(SharedKoin_coreModule *)module factory:(SharedKoin_coreInstanceFactory<R> *)factory __attribute__((swift_name("doCopy(module:factory:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SharedKoin_coreInstanceFactory<R> *factory __attribute__((swift_name("factory")));
@property (readonly) SharedKoin_coreModule *module __attribute__((swift_name("module")));
@end

__attribute__((swift_name("Koin_coreInstanceFactory")))
@interface SharedKoin_coreInstanceFactory<T> : SharedKoin_coreLockable
- (instancetype)initWithBeanDefinition:(SharedKoin_coreBeanDefinition<T> *)beanDefinition __attribute__((swift_name("init(beanDefinition:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
@property (class, readonly, getter=companion) SharedKoin_coreInstanceFactoryCompanion *companion __attribute__((swift_name("companion")));
- (T _Nullable)createContext:(SharedKoin_coreInstanceContext *)context __attribute__((swift_name("create(context:)")));
- (void)dropScope:(SharedKoin_coreScope * _Nullable)scope __attribute__((swift_name("drop(scope:)")));
- (void)dropAll __attribute__((swift_name("dropAll()")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (T _Nullable)getContext:(SharedKoin_coreInstanceContext *)context __attribute__((swift_name("get(context:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isCreatedContext:(SharedKoin_coreInstanceContext * _Nullable)context __attribute__((swift_name("isCreated(context:)")));
@property (readonly) SharedKoin_coreBeanDefinition<T> *beanDefinition __attribute__((swift_name("beanDefinition")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreSingleInstanceFactory")))
@interface SharedKoin_coreSingleInstanceFactory<T> : SharedKoin_coreInstanceFactory<T>
- (instancetype)initWithBeanDefinition:(SharedKoin_coreBeanDefinition<T> *)beanDefinition __attribute__((swift_name("init(beanDefinition:)"))) __attribute__((objc_designated_initializer));
- (T _Nullable)createContext:(SharedKoin_coreInstanceContext *)context __attribute__((swift_name("create(context:)")));
- (void)dropScope:(SharedKoin_coreScope * _Nullable)scope __attribute__((swift_name("drop(scope:)")));
- (void)dropAll __attribute__((swift_name("dropAll()")));
- (T _Nullable)getContext:(SharedKoin_coreInstanceContext *)context __attribute__((swift_name("get(context:)")));
- (BOOL)isCreatedContext:(SharedKoin_coreInstanceContext * _Nullable)context __attribute__((swift_name("isCreated(context:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreScopeDSL")))
@interface SharedKoin_coreScopeDSL : SharedBase
- (instancetype)initWithScopeQualifier:(id<SharedKoin_coreQualifier>)scopeQualifier module:(SharedKoin_coreModule *)module __attribute__((swift_name("init(scopeQualifier:module:)"))) __attribute__((objc_designated_initializer));
- (SharedKoin_coreKoinDefinition<id> *)factoryQualifier:(id<SharedKoin_coreQualifier> _Nullable)qualifier definition:(id _Nullable (^)(SharedKoin_coreScope *, SharedKoin_coreParametersHolder *))definition __attribute__((swift_name("factory(qualifier:definition:)")));
- (SharedKoin_coreKoinDefinition<id> *)scopedQualifier:(id<SharedKoin_coreQualifier> _Nullable)qualifier definition:(id _Nullable (^)(SharedKoin_coreScope *, SharedKoin_coreParametersHolder *))definition __attribute__((swift_name("scoped(qualifier:definition:)")));
@property (readonly) SharedKoin_coreModule *module __attribute__((swift_name("module")));
@property (readonly) id<SharedKoin_coreQualifier> scopeQualifier __attribute__((swift_name("scopeQualifier")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiOptionalCompanion")))
@interface SharedApollo_apiOptionalCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedApollo_apiOptionalCompanion *shared __attribute__((swift_name("shared")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedApollo_apiOptionalAbsent *)absent __attribute__((swift_name("absent()")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedApollo_apiOptionalPresent<id> *)presentValue:(id _Nullable)value __attribute__((swift_name("present(value:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedApollo_apiOptional<id> *)presentIfNotNullValue:(id _Nullable)value __attribute__((swift_name("presentIfNotNull(value:)")));
@end

__attribute__((swift_name("OkioSink")))
@protocol SharedOkioSink <SharedOkioCloseable>
@required

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)flushAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("flush()")));
- (SharedOkioTimeout *)timeout __attribute__((swift_name("timeout()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)writeSource:(SharedOkioBuffer *)source byteCount:(int64_t)byteCount error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("write(source:byteCount_:)")));
@end

__attribute__((swift_name("OkioBufferedSink")))
@protocol SharedOkioBufferedSink <SharedOkioSink>
@required
- (id<SharedOkioBufferedSink>)emit __attribute__((swift_name("emit()")));
- (id<SharedOkioBufferedSink>)emitCompleteSegments __attribute__((swift_name("emitCompleteSegments()")));
- (id<SharedOkioBufferedSink>)writeSource:(SharedKotlinByteArray *)source __attribute__((swift_name("write(source:)")));
- (id<SharedOkioBufferedSink>)writeByteString:(SharedOkioByteString *)byteString __attribute__((swift_name("write(byteString:)")));
- (id<SharedOkioBufferedSink>)writeSource:(id<SharedOkioSource>)source byteCount:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount:)")));
- (id<SharedOkioBufferedSink>)writeSource:(SharedKotlinByteArray *)source offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("write(source:offset:byteCount:)")));
- (id<SharedOkioBufferedSink>)writeByteString:(SharedOkioByteString *)byteString offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("write(byteString:offset:byteCount:)")));
- (int64_t)writeAllSource:(id<SharedOkioSource>)source __attribute__((swift_name("writeAll(source:)")));
- (id<SharedOkioBufferedSink>)writeByteB:(int32_t)b __attribute__((swift_name("writeByte(b:)")));
- (id<SharedOkioBufferedSink>)writeDecimalLongV:(int64_t)v __attribute__((swift_name("writeDecimalLong(v:)")));
- (id<SharedOkioBufferedSink>)writeHexadecimalUnsignedLongV:(int64_t)v __attribute__((swift_name("writeHexadecimalUnsignedLong(v:)")));
- (id<SharedOkioBufferedSink>)writeIntI:(int32_t)i __attribute__((swift_name("writeInt(i:)")));
- (id<SharedOkioBufferedSink>)writeIntLeI:(int32_t)i __attribute__((swift_name("writeIntLe(i:)")));
- (id<SharedOkioBufferedSink>)writeLongV:(int64_t)v __attribute__((swift_name("writeLong(v:)")));
- (id<SharedOkioBufferedSink>)writeLongLeV:(int64_t)v __attribute__((swift_name("writeLongLe(v:)")));
- (id<SharedOkioBufferedSink>)writeShortS:(int32_t)s __attribute__((swift_name("writeShort(s:)")));
- (id<SharedOkioBufferedSink>)writeShortLeS:(int32_t)s __attribute__((swift_name("writeShortLe(s:)")));
- (id<SharedOkioBufferedSink>)writeUtf8String:(NSString *)string __attribute__((swift_name("writeUtf8(string:)")));
- (id<SharedOkioBufferedSink>)writeUtf8String:(NSString *)string beginIndex:(int32_t)beginIndex endIndex:(int32_t)endIndex __attribute__((swift_name("writeUtf8(string:beginIndex:endIndex:)")));
- (id<SharedOkioBufferedSink>)writeUtf8CodePointCodePoint:(int32_t)codePoint __attribute__((swift_name("writeUtf8CodePoint(codePoint:)")));
@property (readonly) SharedOkioBuffer *buffer __attribute__((swift_name("buffer")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface SharedKotlinEnumCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinByteArray")))
@interface SharedKotlinByteArray : SharedBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(SharedByte *(^)(SharedInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (SharedKotlinByteIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("Koin_coreScopeCallback")))
@protocol SharedKoin_coreScopeCallback
@required
- (void)onScopeCloseScope:(SharedKoin_coreScope *)scope __attribute__((swift_name("onScopeClose(scope:)")));
@end

__attribute__((swift_name("Stately_concurrencyThreadLocalRef")))
@interface SharedStately_concurrencyThreadLocalRef<T> : SharedBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (T _Nullable)get __attribute__((swift_name("get()")));
- (void)remove __attribute__((swift_name("remove()")));
- (void)setValue:(T _Nullable)value __attribute__((swift_name("set(value:)")));
@end

__attribute__((swift_name("Koin_coreKoinExtension")))
@protocol SharedKoin_coreKoinExtension
@required
- (void)onClose __attribute__((swift_name("onClose()")));
@property SharedKoin_coreKoin *koin __attribute__((swift_name("koin")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreScopeRegistry.Companion")))
@interface SharedKoin_coreScopeRegistryCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKoin_coreScopeRegistryCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("OkioByteString")))
@interface SharedOkioByteString : SharedBase <SharedKotlinComparable>
@property (class, readonly, getter=companion) SharedOkioByteStringCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)base64 __attribute__((swift_name("base64()")));
- (NSString *)base64Url __attribute__((swift_name("base64Url()")));
- (int32_t)compareToOther:(SharedOkioByteString *)other __attribute__((swift_name("compareTo(other:)")));
- (void)doCopyIntoOffset:(int32_t)offset target:(SharedKotlinByteArray *)target targetOffset:(int32_t)targetOffset byteCount:(int32_t)byteCount __attribute__((swift_name("doCopyInto(offset:target:targetOffset:byteCount:)")));
- (BOOL)endsWithSuffix:(SharedKotlinByteArray *)suffix __attribute__((swift_name("endsWith(suffix:)")));
- (BOOL)endsWithSuffix_:(SharedOkioByteString *)suffix __attribute__((swift_name("endsWith(suffix_:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)hex __attribute__((swift_name("hex()")));
- (SharedOkioByteString *)hmacSha1Key:(SharedOkioByteString *)key __attribute__((swift_name("hmacSha1(key:)")));
- (SharedOkioByteString *)hmacSha256Key:(SharedOkioByteString *)key __attribute__((swift_name("hmacSha256(key:)")));
- (SharedOkioByteString *)hmacSha512Key:(SharedOkioByteString *)key __attribute__((swift_name("hmacSha512(key:)")));
- (int32_t)indexOfOther:(SharedKotlinByteArray *)other fromIndex:(int32_t)fromIndex __attribute__((swift_name("indexOf(other:fromIndex:)")));
- (int32_t)indexOfOther:(SharedOkioByteString *)other fromIndex_:(int32_t)fromIndex __attribute__((swift_name("indexOf(other:fromIndex_:)")));
- (int32_t)lastIndexOfOther:(SharedKotlinByteArray *)other fromIndex:(int32_t)fromIndex __attribute__((swift_name("lastIndexOf(other:fromIndex:)")));
- (int32_t)lastIndexOfOther:(SharedOkioByteString *)other fromIndex_:(int32_t)fromIndex __attribute__((swift_name("lastIndexOf(other:fromIndex_:)")));
- (SharedOkioByteString *)md5 __attribute__((swift_name("md5()")));
- (BOOL)rangeEqualsOffset:(int32_t)offset other:(SharedKotlinByteArray *)other otherOffset:(int32_t)otherOffset byteCount:(int32_t)byteCount __attribute__((swift_name("rangeEquals(offset:other:otherOffset:byteCount:)")));
- (BOOL)rangeEqualsOffset:(int32_t)offset other:(SharedOkioByteString *)other otherOffset:(int32_t)otherOffset byteCount_:(int32_t)byteCount __attribute__((swift_name("rangeEquals(offset:other:otherOffset:byteCount_:)")));
- (SharedOkioByteString *)sha1 __attribute__((swift_name("sha1()")));
- (SharedOkioByteString *)sha256 __attribute__((swift_name("sha256()")));
- (SharedOkioByteString *)sha512 __attribute__((swift_name("sha512()")));
- (BOOL)startsWithPrefix:(SharedKotlinByteArray *)prefix __attribute__((swift_name("startsWith(prefix:)")));
- (BOOL)startsWithPrefix_:(SharedOkioByteString *)prefix __attribute__((swift_name("startsWith(prefix_:)")));
- (SharedOkioByteString *)substringBeginIndex:(int32_t)beginIndex endIndex:(int32_t)endIndex __attribute__((swift_name("substring(beginIndex:endIndex:)")));
- (SharedOkioByteString *)toAsciiLowercase __attribute__((swift_name("toAsciiLowercase()")));
- (SharedOkioByteString *)toAsciiUppercase __attribute__((swift_name("toAsciiUppercase()")));
- (SharedKotlinByteArray *)toByteArray __attribute__((swift_name("toByteArray()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (NSString *)utf8 __attribute__((swift_name("utf8()")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OkioBuffer")))
@interface SharedOkioBuffer : SharedBase <SharedOkioBufferedSource, SharedOkioBufferedSink>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)clear __attribute__((swift_name("clear()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)closeAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("close()")));
- (int64_t)completeSegmentByteCount __attribute__((swift_name("completeSegmentByteCount()")));
- (SharedOkioBuffer *)doCopy __attribute__((swift_name("doCopy()")));
- (SharedOkioBuffer *)doCopyToOut:(SharedOkioBuffer *)out offset:(int64_t)offset __attribute__((swift_name("doCopyTo(out:offset:)")));
- (SharedOkioBuffer *)doCopyToOut:(SharedOkioBuffer *)out offset:(int64_t)offset byteCount:(int64_t)byteCount __attribute__((swift_name("doCopyTo(out:offset:byteCount:)")));
- (SharedOkioBuffer *)emit __attribute__((swift_name("emit()")));
- (SharedOkioBuffer *)emitCompleteSegments __attribute__((swift_name("emitCompleteSegments()")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (BOOL)exhausted __attribute__((swift_name("exhausted()")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)flushAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("flush()")));
- (int8_t)getPos:(int64_t)pos __attribute__((swift_name("get(pos:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (SharedOkioByteString *)hmacSha1Key:(SharedOkioByteString *)key __attribute__((swift_name("hmacSha1(key:)")));
- (SharedOkioByteString *)hmacSha256Key:(SharedOkioByteString *)key __attribute__((swift_name("hmacSha256(key:)")));
- (SharedOkioByteString *)hmacSha512Key:(SharedOkioByteString *)key __attribute__((swift_name("hmacSha512(key:)")));
- (int64_t)indexOfB:(int8_t)b __attribute__((swift_name("indexOf(b:)")));
- (int64_t)indexOfBytes:(SharedOkioByteString *)bytes __attribute__((swift_name("indexOf(bytes:)")));
- (int64_t)indexOfB:(int8_t)b fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOf(b:fromIndex:)")));
- (int64_t)indexOfBytes:(SharedOkioByteString *)bytes fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOf(bytes:fromIndex:)")));
- (int64_t)indexOfB:(int8_t)b fromIndex:(int64_t)fromIndex toIndex:(int64_t)toIndex __attribute__((swift_name("indexOf(b:fromIndex:toIndex:)")));
- (int64_t)indexOfElementTargetBytes:(SharedOkioByteString *)targetBytes __attribute__((swift_name("indexOfElement(targetBytes:)")));
- (int64_t)indexOfElementTargetBytes:(SharedOkioByteString *)targetBytes fromIndex:(int64_t)fromIndex __attribute__((swift_name("indexOfElement(targetBytes:fromIndex:)")));
- (SharedOkioByteString *)md5 __attribute__((swift_name("md5()")));
- (id<SharedOkioBufferedSource>)peek __attribute__((swift_name("peek_()")));
- (BOOL)rangeEqualsOffset:(int64_t)offset bytes:(SharedOkioByteString *)bytes __attribute__((swift_name("rangeEquals(offset:bytes:)")));
- (BOOL)rangeEqualsOffset:(int64_t)offset bytes:(SharedOkioByteString *)bytes bytesOffset:(int32_t)bytesOffset byteCount:(int32_t)byteCount __attribute__((swift_name("rangeEquals(offset:bytes:bytesOffset:byteCount:)")));
- (int32_t)readSink:(SharedKotlinByteArray *)sink __attribute__((swift_name("read(sink:)")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (int64_t)readSink:(SharedOkioBuffer *)sink byteCount:(int64_t)byteCount error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("read(sink:byteCount:)"))) __attribute__((swift_error(nonnull_error)));
- (int32_t)readSink:(SharedKotlinByteArray *)sink offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("read(sink:offset:byteCount:)")));
- (int64_t)readAllSink:(id<SharedOkioSink>)sink __attribute__((swift_name("readAll(sink:)")));
- (SharedOkioBufferUnsafeCursor *)readAndWriteUnsafeUnsafeCursor:(SharedOkioBufferUnsafeCursor *)unsafeCursor __attribute__((swift_name("readAndWriteUnsafe(unsafeCursor:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (SharedKotlinByteArray *)readByteArray __attribute__((swift_name("readByteArray()")));
- (SharedKotlinByteArray *)readByteArrayByteCount:(int64_t)byteCount __attribute__((swift_name("readByteArray(byteCount:)")));
- (SharedOkioByteString *)readByteString __attribute__((swift_name("readByteString()")));
- (SharedOkioByteString *)readByteStringByteCount:(int64_t)byteCount __attribute__((swift_name("readByteString(byteCount:)")));
- (int64_t)readDecimalLong __attribute__((swift_name("readDecimalLong()")));
- (void)readFullySink:(SharedKotlinByteArray *)sink __attribute__((swift_name("readFully(sink:)")));
- (void)readFullySink:(SharedOkioBuffer *)sink byteCount:(int64_t)byteCount __attribute__((swift_name("readFully(sink:byteCount:)")));
- (int64_t)readHexadecimalUnsignedLong __attribute__((swift_name("readHexadecimalUnsignedLong()")));
- (int32_t)readInt __attribute__((swift_name("readInt()")));
- (int32_t)readIntLe __attribute__((swift_name("readIntLe()")));
- (int64_t)readLong __attribute__((swift_name("readLong()")));
- (int64_t)readLongLe __attribute__((swift_name("readLongLe()")));
- (int16_t)readShort __attribute__((swift_name("readShort()")));
- (int16_t)readShortLe __attribute__((swift_name("readShortLe()")));
- (SharedOkioBufferUnsafeCursor *)readUnsafeUnsafeCursor:(SharedOkioBufferUnsafeCursor *)unsafeCursor __attribute__((swift_name("readUnsafe(unsafeCursor:)")));
- (NSString *)readUtf8 __attribute__((swift_name("readUtf8()")));
- (NSString *)readUtf8ByteCount:(int64_t)byteCount __attribute__((swift_name("readUtf8(byteCount:)")));
- (int32_t)readUtf8CodePoint __attribute__((swift_name("readUtf8CodePoint()")));
- (NSString * _Nullable)readUtf8Line __attribute__((swift_name("readUtf8Line()")));
- (NSString *)readUtf8LineStrict __attribute__((swift_name("readUtf8LineStrict()")));
- (NSString *)readUtf8LineStrictLimit:(int64_t)limit __attribute__((swift_name("readUtf8LineStrict(limit:)")));
- (BOOL)requestByteCount:(int64_t)byteCount __attribute__((swift_name("request(byteCount:)")));
- (void)requireByteCount:(int64_t)byteCount __attribute__((swift_name("require(byteCount:)")));
- (int32_t)selectOptions:(NSArray<SharedOkioByteString *> *)options __attribute__((swift_name("select(options:)")));
- (id _Nullable)selectOptions_:(NSArray<id> *)options __attribute__((swift_name("select(options_:)")));
- (SharedOkioByteString *)sha1 __attribute__((swift_name("sha1()")));
- (SharedOkioByteString *)sha256 __attribute__((swift_name("sha256()")));
- (SharedOkioByteString *)sha512 __attribute__((swift_name("sha512()")));
- (void)skipByteCount:(int64_t)byteCount __attribute__((swift_name("skip(byteCount:)")));
- (SharedOkioByteString *)snapshot __attribute__((swift_name("snapshot()")));
- (SharedOkioByteString *)snapshotByteCount:(int32_t)byteCount __attribute__((swift_name("snapshot(byteCount:)")));
- (SharedOkioTimeout *)timeout __attribute__((swift_name("timeout()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (SharedOkioBuffer *)writeSource:(SharedKotlinByteArray *)source __attribute__((swift_name("write(source:)")));
- (SharedOkioBuffer *)writeByteString:(SharedOkioByteString *)byteString __attribute__((swift_name("write(byteString:)")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)writeSource:(SharedOkioBuffer *)source byteCount:(int64_t)byteCount error:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("write(source:byteCount_:)")));
- (SharedOkioBuffer *)writeSource:(id<SharedOkioSource>)source byteCount:(int64_t)byteCount __attribute__((swift_name("write(source:byteCount:)")));
- (SharedOkioBuffer *)writeSource:(SharedKotlinByteArray *)source offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("write(source:offset:byteCount:)")));
- (SharedOkioBuffer *)writeByteString:(SharedOkioByteString *)byteString offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("write(byteString:offset:byteCount:)")));
- (int64_t)writeAllSource:(id<SharedOkioSource>)source __attribute__((swift_name("writeAll(source:)")));
- (SharedOkioBuffer *)writeByteB:(int32_t)b __attribute__((swift_name("writeByte(b:)")));
- (SharedOkioBuffer *)writeDecimalLongV:(int64_t)v __attribute__((swift_name("writeDecimalLong(v:)")));
- (SharedOkioBuffer *)writeHexadecimalUnsignedLongV:(int64_t)v __attribute__((swift_name("writeHexadecimalUnsignedLong(v:)")));
- (SharedOkioBuffer *)writeIntI:(int32_t)i __attribute__((swift_name("writeInt(i:)")));
- (SharedOkioBuffer *)writeIntLeI:(int32_t)i __attribute__((swift_name("writeIntLe(i:)")));
- (SharedOkioBuffer *)writeLongV:(int64_t)v __attribute__((swift_name("writeLong(v:)")));
- (SharedOkioBuffer *)writeLongLeV:(int64_t)v __attribute__((swift_name("writeLongLe(v:)")));
- (SharedOkioBuffer *)writeShortS:(int32_t)s __attribute__((swift_name("writeShort(s:)")));
- (SharedOkioBuffer *)writeShortLeS:(int32_t)s __attribute__((swift_name("writeShortLe(s:)")));
- (SharedOkioBuffer *)writeUtf8String:(NSString *)string __attribute__((swift_name("writeUtf8(string:)")));
- (SharedOkioBuffer *)writeUtf8String:(NSString *)string beginIndex:(int32_t)beginIndex endIndex:(int32_t)endIndex __attribute__((swift_name("writeUtf8(string:beginIndex:endIndex:)")));
- (SharedOkioBuffer *)writeUtf8CodePointCodePoint:(int32_t)codePoint __attribute__((swift_name("writeUtf8CodePoint(codePoint:)")));
@property (readonly) SharedOkioBuffer *buffer __attribute__((swift_name("buffer")));
@property (readonly) int64_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("OkioTimeout")))
@interface SharedOkioTimeout : SharedBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) SharedOkioTimeoutCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiApolloResponse")))
@interface SharedApollo_apiApolloResponse<D> : SharedBase
- (D)dataOrThrow __attribute__((swift_name("dataOrThrow()")));
- (BOOL)hasErrors __attribute__((swift_name("hasErrors()")));
- (SharedApollo_apiApolloResponseBuilder<D> *)doNewBuilder __attribute__((swift_name("doNewBuilder()")));
@property (readonly) D _Nullable data __attribute__((swift_name("data")));
@property (readonly) D dataAssertNoErrors __attribute__((swift_name("dataAssertNoErrors")));
@property (readonly) NSArray<SharedApollo_apiError *> * _Nullable errors __attribute__((swift_name("errors")));
@property (readonly) SharedApollo_apiApolloException * _Nullable exception __attribute__((swift_name("exception")));
@property (readonly) id<SharedApollo_apiExecutionContext> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) NSDictionary<NSString *, id> *extensions __attribute__((swift_name("extensions")));
@property (readonly) BOOL isLast __attribute__((swift_name("isLast")));
@property (readonly) id<SharedApollo_apiOperation> operation __attribute__((swift_name("operation")));
@property (readonly) SharedUuidUuid *requestUuid __attribute__((swift_name("requestUuid")));
@end

__attribute__((swift_name("Apollo_runtimeApolloClientListener")))
@protocol SharedApollo_runtimeApolloClientListener
@required
- (void)requestCompletedRequest:(SharedApollo_apiApolloRequest<id> *)request __attribute__((swift_name("requestCompleted(request:)")));
- (void)requestStartedRequest:(SharedApollo_apiApolloRequest<id> *)request __attribute__((swift_name("requestStarted(request:)")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinCoroutineContext")))
@protocol SharedKotlinCoroutineContext
@required
- (id _Nullable)foldInitial:(id _Nullable)initial operation_:(id _Nullable (^)(id _Nullable, id<SharedKotlinCoroutineContextElement>))operation __attribute__((swift_name("fold(initial:operation_:)")));
- (id<SharedKotlinCoroutineContextElement> _Nullable)getKey_:(id<SharedKotlinCoroutineContextKey>)key __attribute__((swift_name("get(key_:)")));
- (id<SharedKotlinCoroutineContext>)minusKeyKey_:(id<SharedKotlinCoroutineContextKey>)key __attribute__((swift_name("minusKey(key_:)")));
- (id<SharedKotlinCoroutineContext>)plusContext_:(id<SharedKotlinCoroutineContext>)context __attribute__((swift_name("plus(context_:)")));
@end

__attribute__((swift_name("KotlinCoroutineContextElement")))
@protocol SharedKotlinCoroutineContextElement <SharedKotlinCoroutineContext>
@required
@property (readonly) id<SharedKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinAbstractCoroutineContextElement")))
@interface SharedKotlinAbstractCoroutineContextElement : SharedBase <SharedKotlinCoroutineContextElement>
- (instancetype)initWithKey:(id<SharedKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<SharedKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinContinuationInterceptor")))
@protocol SharedKotlinContinuationInterceptor <SharedKotlinCoroutineContextElement>
@required
- (id<SharedKotlinContinuation>)interceptContinuationContinuation:(id<SharedKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (void)releaseInterceptedContinuationContinuation:(id<SharedKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher")))
@interface SharedKotlinx_coroutines_coreCoroutineDispatcher : SharedKotlinAbstractCoroutineContextElement <SharedKotlinContinuationInterceptor>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithKey:(id<SharedKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) SharedKotlinx_coroutines_coreCoroutineDispatcherKey *companion __attribute__((swift_name("companion")));
- (void)dispatchContext:(id<SharedKotlinCoroutineContext>)context block:(id<SharedKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatch(context:block:)")));
- (void)dispatchYieldContext:(id<SharedKotlinCoroutineContext>)context block:(id<SharedKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatchYield(context:block:)")));
- (id<SharedKotlinContinuation>)interceptContinuationContinuation:(id<SharedKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (BOOL)isDispatchNeededContext:(id<SharedKotlinCoroutineContext>)context __attribute__((swift_name("isDispatchNeeded(context:)")));

/**
 * @note annotations
 *   kotlinx.coroutines.ExperimentalCoroutinesApi
*/
- (SharedKotlinx_coroutines_coreCoroutineDispatcher *)limitedParallelismParallelism:(int32_t)parallelism __attribute__((swift_name("limitedParallelism(parallelism:)")));
- (SharedKotlinx_coroutines_coreCoroutineDispatcher *)plusOther:(SharedKotlinx_coroutines_coreCoroutineDispatcher *)other __attribute__((swift_name("plus(other:)"))) __attribute__((unavailable("Operator '+' on two CoroutineDispatcher objects is meaningless. CoroutineDispatcher is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The dispatcher to the right of `+` just replaces the dispatcher to the left.")));
- (void)releaseInterceptedContinuationContinuation:(id<SharedKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("Apollo_runtimeHttpEngine")))
@protocol SharedApollo_runtimeHttpEngine <SharedOkioCloseable>
@required
- (void)dispose __attribute__((swift_name("dispose()"))) __attribute__((unavailable("Use close")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeRequest:(SharedApollo_apiHttpRequest *)request completionHandler:(void (^)(SharedApollo_apiHttpResponse * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(request:completionHandler:)")));
@end


/**
 * @note annotations
 *   com.apollographql.apollo3.annotations.ApolloExperimental
*/
__attribute__((swift_name("Apollo_runtimeNetworkMonitor")))
@protocol SharedApollo_runtimeNetworkMonitor <SharedOkioCloseable>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)isOnlineWithCompletionHandler:(void (^)(SharedBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("isOnline(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)waitForNetworkWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("waitForNetwork(completionHandler:)")));
@end

__attribute__((swift_name("Apollo_runtimeWebSocketEngine")))
@protocol SharedApollo_runtimeWebSocketEngine
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)openUrl:(NSString *)url headers:(NSArray<SharedApollo_apiHttpHeader *> *)headers completionHandler:(void (^)(id<SharedApollo_runtimeWebSocketConnection> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("open(url:headers:completionHandler:)")));
@end

__attribute__((swift_name("KotlinSuspendFunction2")))
@protocol SharedKotlinSuspendFunction2 <SharedKotlinFunction>
@required

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeP1:(id _Nullable)p1 p2:(id _Nullable)p2 completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(p1:p2:completionHandler:)")));
@end

__attribute__((swift_name("Apollo_runtimeWsProtocolFactory")))
@protocol SharedApollo_runtimeWsProtocolFactory
@required
- (SharedApollo_runtimeWsProtocol *)createWebSocketConnection:(id<SharedApollo_runtimeWebSocketConnection>)webSocketConnection listener:(id<SharedApollo_runtimeWsProtocolListener>)listener scope:(id<SharedKotlinx_coroutines_coreCoroutineScope>)scope __attribute__((swift_name("create(webSocketConnection:listener:scope:)")));
@property (readonly, getter=name_) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiInterfaceType.Builder")))
@interface SharedApollo_apiInterfaceTypeBuilder : SharedBase
- (instancetype)initWithInterfaceType:(SharedApollo_apiInterfaceType *)interfaceType __attribute__((swift_name("init(interfaceType:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithName:(NSString *)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
- (SharedApollo_apiInterfaceType *)build __attribute__((swift_name("build()")));
- (SharedApollo_apiInterfaceTypeBuilder *)embeddedFieldsEmbeddedFields:(NSArray<NSString *> *)embeddedFields __attribute__((swift_name("embeddedFields(embeddedFields:)")));
- (SharedApollo_apiInterfaceTypeBuilder *)interfacesImplements:(NSArray<SharedApollo_apiInterfaceType *> *)implements __attribute__((swift_name("interfaces(implements:)")));
- (SharedApollo_apiInterfaceTypeBuilder *)keyFieldsKeyFields:(NSArray<NSString *> *)keyFields __attribute__((swift_name("keyFields(keyFields:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Arrow_coreEvalCompanion")))
@interface SharedArrow_coreEvalCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedArrow_coreEvalCompanion *shared __attribute__((swift_name("shared")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedArrow_coreEvalAlways<id> *)alwaysF:(id _Nullable (^)(void))f __attribute__((swift_name("always(f:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedArrow_coreEval<id> *)deferF:(SharedArrow_coreEval<id> *(^)(void))f __attribute__((swift_name("defer(f:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedArrow_coreEvalLater<id> *)laterF:(id _Nullable (^)(void))f __attribute__((swift_name("later(f:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedArrow_coreEval<id> *)nowA:(id _Nullable)a __attribute__((swift_name("now(a:)")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedArrow_coreEval<SharedKotlinNothing *> *)raiseT:(SharedKotlinThrowable *)t __attribute__((swift_name("raise(t:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreBeanDefinition")))
@interface SharedKoin_coreBeanDefinition<T> : SharedBase
- (instancetype)initWithScopeQualifier:(id<SharedKoin_coreQualifier>)scopeQualifier primaryType:(id<SharedKotlinKClass>)primaryType qualifier:(id<SharedKoin_coreQualifier> _Nullable)qualifier definition:(T _Nullable (^)(SharedKoin_coreScope *, SharedKoin_coreParametersHolder *))definition kind:(SharedKoin_coreKind *)kind secondaryTypes:(NSArray<id<SharedKotlinKClass>> *)secondaryTypes __attribute__((swift_name("init(scopeQualifier:primaryType:qualifier:definition:kind:secondaryTypes:)"))) __attribute__((objc_designated_initializer));
- (SharedKoin_coreBeanDefinition<T> *)doCopyScopeQualifier:(id<SharedKoin_coreQualifier>)scopeQualifier primaryType:(id<SharedKotlinKClass>)primaryType qualifier:(id<SharedKoin_coreQualifier> _Nullable)qualifier definition:(T _Nullable (^)(SharedKoin_coreScope *, SharedKoin_coreParametersHolder *))definition kind:(SharedKoin_coreKind *)kind secondaryTypes:(NSArray<id<SharedKotlinKClass>> *)secondaryTypes __attribute__((swift_name("doCopy(scopeQualifier:primaryType:qualifier:definition:kind:secondaryTypes:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (BOOL)hasTypeClazz:(id<SharedKotlinKClass>)clazz __attribute__((swift_name("hasType(clazz:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)isClazz:(id<SharedKotlinKClass>)clazz qualifier:(id<SharedKoin_coreQualifier> _Nullable)qualifier scopeDefinition:(id<SharedKoin_coreQualifier>)scopeDefinition __attribute__((swift_name("is(clazz:qualifier:scopeDefinition:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property SharedKoin_coreCallbacks<T> *callbacks __attribute__((swift_name("callbacks")));
@property (readonly) T _Nullable (^definition)(SharedKoin_coreScope *, SharedKoin_coreParametersHolder *) __attribute__((swift_name("definition")));
@property (readonly) SharedKoin_coreKind *kind __attribute__((swift_name("kind")));
@property (readonly) id<SharedKotlinKClass> primaryType __attribute__((swift_name("primaryType")));
@property id<SharedKoin_coreQualifier> _Nullable qualifier __attribute__((swift_name("qualifier")));
@property (readonly) id<SharedKoin_coreQualifier> scopeQualifier __attribute__((swift_name("scopeQualifier")));
@property NSArray<id<SharedKotlinKClass>> *secondaryTypes __attribute__((swift_name("secondaryTypes")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreInstanceFactoryCompanion")))
@interface SharedKoin_coreInstanceFactoryCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKoin_coreInstanceFactoryCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *ERROR_SEPARATOR __attribute__((swift_name("ERROR_SEPARATOR")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreInstanceContext")))
@interface SharedKoin_coreInstanceContext : SharedBase
- (instancetype)initWithLogger:(SharedKoin_coreLogger *)logger scope:(SharedKoin_coreScope *)scope parameters:(SharedKoin_coreParametersHolder * _Nullable)parameters __attribute__((swift_name("init(logger:scope:parameters:)"))) __attribute__((objc_designated_initializer));
@property (readonly) SharedKoin_coreLogger *logger __attribute__((swift_name("logger")));
@property (readonly) SharedKoin_coreParametersHolder * _Nullable parameters __attribute__((swift_name("parameters")));
@property (readonly) SharedKoin_coreScope *scope __attribute__((swift_name("scope")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiOptionalAbsent")))
@interface SharedApollo_apiOptionalAbsent : SharedApollo_apiOptional<SharedKotlinNothing *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)absent __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedApollo_apiOptionalAbsent *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiOptionalPresent")))
@interface SharedApollo_apiOptionalPresent<V> : SharedApollo_apiOptional<V>
- (instancetype)initWithValue:(V _Nullable)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
- (SharedApollo_apiOptionalPresent<V> *)doCopyValue:(V _Nullable)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) V _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((swift_name("KotlinByteIterator")))
@interface SharedKotlinByteIterator : SharedBase <SharedKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (SharedByte *)next __attribute__((swift_name("next()")));
- (int8_t)nextByte __attribute__((swift_name("nextByte()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OkioByteString.Companion")))
@interface SharedOkioByteStringCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedOkioByteStringCompanion *shared __attribute__((swift_name("shared")));
- (SharedOkioByteString * _Nullable)decodeBase64:(NSString *)receiver __attribute__((swift_name("decodeBase64(_:)")));
- (SharedOkioByteString *)decodeHex:(NSString *)receiver __attribute__((swift_name("decodeHex(_:)")));
- (SharedOkioByteString *)encodeUtf8:(NSString *)receiver __attribute__((swift_name("encodeUtf8(_:)")));
- (SharedOkioByteString *)ofData:(SharedKotlinByteArray *)data __attribute__((swift_name("of(data:)")));
- (SharedOkioByteString *)toByteString:(NSData *)receiver __attribute__((swift_name("toByteString(_:)")));
- (SharedOkioByteString *)toByteString:(SharedKotlinByteArray *)receiver offset:(int32_t)offset byteCount:(int32_t)byteCount __attribute__((swift_name("toByteString(_:offset:byteCount:)")));
@property (readonly) SharedOkioByteString *EMPTY __attribute__((swift_name("EMPTY")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OkioBuffer.UnsafeCursor")))
@interface SharedOkioBufferUnsafeCursor : SharedBase <SharedOkioCloseable>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 * @note This method converts instances of IOException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (BOOL)closeAndReturnError:(NSError * _Nullable * _Nullable)error __attribute__((swift_name("close()")));
- (int64_t)expandBufferMinByteCount:(int32_t)minByteCount __attribute__((swift_name("expandBuffer(minByteCount:)")));
- (int32_t)next __attribute__((swift_name("next()")));
- (int64_t)resizeBufferNewSize:(int64_t)newSize __attribute__((swift_name("resizeBuffer(newSize:)")));
- (int32_t)seekOffset:(int64_t)offset __attribute__((swift_name("seek(offset:)")));
@property SharedOkioBuffer * _Nullable buffer __attribute__((swift_name("buffer")));
@property SharedKotlinByteArray * _Nullable data __attribute__((swift_name("data")));
@property int32_t end __attribute__((swift_name("end")));
@property int64_t offset __attribute__((swift_name("offset")));
@property BOOL readWrite __attribute__((swift_name("readWrite")));
@property int32_t start __attribute__((swift_name("start")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OkioTimeout.Companion")))
@interface SharedOkioTimeoutCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedOkioTimeoutCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) SharedOkioTimeout *NONE __attribute__((swift_name("NONE")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_apiApolloResponseBuilder")))
@interface SharedApollo_apiApolloResponseBuilder<D> : SharedBase
- (instancetype)initWithOperation:(id<SharedApollo_apiOperation>)operation requestUuid:(SharedUuidUuid *)requestUuid __attribute__((swift_name("init(operation:requestUuid:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithOperation:(id<SharedApollo_apiOperation>)operation requestUuid:(SharedUuidUuid *)requestUuid data:(D _Nullable)data __attribute__((swift_name("init(operation:requestUuid:data:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("Use 2 params constructor instead")));
- (SharedApollo_apiApolloResponseBuilder<D> *)addExecutionContextExecutionContext:(id<SharedApollo_apiExecutionContext>)executionContext __attribute__((swift_name("addExecutionContext(executionContext:)")));
- (SharedApollo_apiApolloResponse<D> *)build __attribute__((swift_name("build()")));
- (SharedApollo_apiApolloResponseBuilder<D> *)dataData:(D _Nullable)data __attribute__((swift_name("data(data:)")));
- (SharedApollo_apiApolloResponseBuilder<D> *)errorsErrors:(NSArray<SharedApollo_apiError *> * _Nullable)errors __attribute__((swift_name("errors(errors:)")));
- (SharedApollo_apiApolloResponseBuilder<D> *)exceptionException:(SharedApollo_apiApolloException * _Nullable)exception __attribute__((swift_name("exception(exception:)")));
- (SharedApollo_apiApolloResponseBuilder<D> *)extensionsExtensions:(NSDictionary<NSString *, id> * _Nullable)extensions __attribute__((swift_name("extensions(extensions:)")));
- (SharedApollo_apiApolloResponseBuilder<D> *)isLastIsLast:(BOOL)isLast __attribute__((swift_name("isLast(isLast:)")));
- (SharedApollo_apiApolloResponseBuilder<D> *)requestUuidRequestUuid:(SharedUuidUuid *)requestUuid __attribute__((swift_name("requestUuid(requestUuid:)")));
@end

__attribute__((swift_name("Apollo_apiApolloException")))
@interface SharedApollo_apiApolloException : SharedKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithCause:(SharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinCoroutineContextKey")))
@protocol SharedKotlinCoroutineContextKey
@required
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
*/
__attribute__((swift_name("KotlinContinuation")))
@protocol SharedKotlinContinuation
@required
- (void)resumeWithResult:(id _Nullable)result __attribute__((swift_name("resumeWith(result:)")));
@property (readonly) id<SharedKotlinCoroutineContext> context __attribute__((swift_name("context")));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.3")
 *   kotlin.ExperimentalStdlibApi
*/
__attribute__((swift_name("KotlinAbstractCoroutineContextKey")))
@interface SharedKotlinAbstractCoroutineContextKey<B, E> : SharedBase <SharedKotlinCoroutineContextKey>
- (instancetype)initWithBaseKey:(id<SharedKotlinCoroutineContextKey>)baseKey safeCast:(E _Nullable (^)(id<SharedKotlinCoroutineContextElement>))safeCast __attribute__((swift_name("init(baseKey:safeCast:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.ExperimentalStdlibApi
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher.Key")))
@interface SharedKotlinx_coroutines_coreCoroutineDispatcherKey : SharedKotlinAbstractCoroutineContextKey<id<SharedKotlinContinuationInterceptor>, SharedKotlinx_coroutines_coreCoroutineDispatcher *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithBaseKey:(id<SharedKotlinCoroutineContextKey>)baseKey safeCast:(id<SharedKotlinCoroutineContextElement> _Nullable (^)(id<SharedKotlinCoroutineContextElement>))safeCast __attribute__((swift_name("init(baseKey:safeCast:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)key __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKotlinx_coroutines_coreCoroutineDispatcherKey *shared __attribute__((swift_name("shared")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreRunnable")))
@protocol SharedKotlinx_coroutines_coreRunnable
@required
- (void)run __attribute__((swift_name("run()")));
@end

__attribute__((swift_name("Apollo_runtimeWebSocketConnection")))
@protocol SharedApollo_runtimeWebSocketConnection
@required
- (void)close __attribute__((swift_name("close_()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)receiveWithCompletionHandler:(void (^)(NSString * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("receive(completionHandler:)")));
- (void)sendString:(NSString *)string __attribute__((swift_name("send(string:)")));
- (void)sendData:(SharedOkioByteString *)data __attribute__((swift_name("send(data:)")));
@end

__attribute__((swift_name("Apollo_runtimeWsProtocol")))
@interface SharedApollo_runtimeWsProtocol : SharedBase
- (instancetype)initWithWebSocketConnection:(id<SharedApollo_runtimeWebSocketConnection>)webSocketConnection listener:(id<SharedApollo_runtimeWsProtocolListener>)listener __attribute__((swift_name("init(webSocketConnection:listener:)"))) __attribute__((objc_designated_initializer));
- (void)close __attribute__((swift_name("close_()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)connectionInitWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("connectionInit(completionHandler:)")));
- (void)handleServerMessageMessageMap:(NSDictionary<NSString *, id> *)messageMap __attribute__((swift_name("handleServerMessage(messageMap:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)receiveMessageMapWithCompletionHandler:(void (^)(NSDictionary<NSString *, id> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("receiveMessageMap(completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)runWithCompletionHandler:(void (^)(NSError * _Nullable))completionHandler __attribute__((swift_name("run(completionHandler:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)sendMessageMapMessageMap:(NSDictionary<NSString *, id> *)messageMap frameType:(SharedApollo_runtimeWsFrameType *)frameType __attribute__((swift_name("sendMessageMap(messageMap:frameType:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)sendMessageMapBinaryMessageMap:(NSDictionary<NSString *, id> *)messageMap __attribute__((swift_name("sendMessageMapBinary(messageMap:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (void)sendMessageMapTextMessageMap:(NSDictionary<NSString *, id> *)messageMap __attribute__((swift_name("sendMessageMapText(messageMap:)")));
- (void)startOperationRequest:(SharedApollo_apiApolloRequest<id<SharedApollo_apiOperationData>> *)request __attribute__((swift_name("startOperation(request:)")));
- (void)stopOperationRequest:(SharedApollo_apiApolloRequest<id<SharedApollo_apiOperationData>> *)request __attribute__((swift_name("stopOperation(request:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (SharedOkioByteString *)toByteString:(NSDictionary<NSString *, id> *)receiver __attribute__((swift_name("toByteString(_:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (NSDictionary<NSString *, id> * _Nullable)toMessageMap:(NSString *)receiver __attribute__((swift_name("toMessageMap(_:)")));

/**
 * @note This method has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
- (NSString *)toUtf8:(NSDictionary<NSString *, id> *)receiver __attribute__((swift_name("toUtf8(_:)")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) id<SharedApollo_runtimeWsProtocolListener> listener __attribute__((swift_name("listener")));

/**
 * @note This property has protected visibility in Kotlin source and is intended only for use by subclasses.
*/
@property (readonly) id<SharedApollo_runtimeWebSocketConnection> webSocketConnection __attribute__((swift_name("webSocketConnection")));
@end

__attribute__((swift_name("Apollo_runtimeWsProtocolListener")))
@protocol SharedApollo_runtimeWsProtocolListener
@required
- (void)generalErrorPayload:(NSDictionary<NSString *, id> * _Nullable)payload __attribute__((swift_name("generalError(payload:)")));
- (void)networkErrorCause:(SharedKotlinThrowable *)cause __attribute__((swift_name("networkError(cause:)")));
- (void)operationCompleteId:(NSString *)id __attribute__((swift_name("operationComplete(id:)")));
- (void)operationErrorId:(NSString *)id payload:(NSDictionary<NSString *, id> * _Nullable)payload __attribute__((swift_name("operationError(id:payload:)")));
- (void)operationResponseId:(NSString *)id payload:(NSDictionary<NSString *, id> *)payload __attribute__((swift_name("operationResponse(id:payload:)")));
@end

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineScope")))
@protocol SharedKotlinx_coroutines_coreCoroutineScope
@required
@property (readonly) id<SharedKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Arrow_coreEvalAlways")))
@interface SharedArrow_coreEvalAlways<__covariant A> : SharedArrow_coreEval<A>
- (instancetype)initWithF:(A _Nullable (^)(void))f __attribute__((swift_name("init(f:)"))) __attribute__((objc_designated_initializer));
- (SharedArrow_coreEvalAlways<A> *)doCopyF:(A _Nullable (^)(void))f __attribute__((swift_name("doCopy(f:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (SharedArrow_coreEval<A> *)memoize __attribute__((swift_name("memoize()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (A _Nullable)value_ __attribute__((swift_name("value()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Arrow_coreEvalLater")))
@interface SharedArrow_coreEvalLater<__covariant A> : SharedArrow_coreEval<A>
- (instancetype)initWithF:(A _Nullable (^)(void))f __attribute__((swift_name("init(f:)"))) __attribute__((objc_designated_initializer));
- (SharedArrow_coreEvalLater<A> *)doCopyF:(A _Nullable (^)(void))f __attribute__((swift_name("doCopy(f:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (SharedArrow_coreEval<A> *)memoize __attribute__((swift_name("memoize()")));
- (NSString *)description __attribute__((swift_name("description()")));
- (A _Nullable)value_ __attribute__((swift_name("value()")));
@property (readonly) A _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreKind")))
@interface SharedKoin_coreKind : SharedKotlinEnum<SharedKoin_coreKind *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKoin_coreKind *singleton __attribute__((swift_name("singleton")));
@property (class, readonly) SharedKoin_coreKind *factory __attribute__((swift_name("factory")));
@property (class, readonly) SharedKoin_coreKind *scoped __attribute__((swift_name("scoped")));
+ (SharedKotlinArray<SharedKoin_coreKind *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<SharedKoin_coreKind *> *entries __attribute__((swift_name("entries")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Koin_coreCallbacks")))
@interface SharedKoin_coreCallbacks<T> : SharedBase
- (instancetype)initWithOnClose:(void (^ _Nullable)(T _Nullable))onClose __attribute__((swift_name("init(onClose:)"))) __attribute__((objc_designated_initializer));
- (SharedKoin_coreCallbacks<T> *)doCopyOnClose:(void (^ _Nullable)(T _Nullable))onClose __attribute__((swift_name("doCopy(onClose:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) void (^ _Nullable onClose)(T _Nullable) __attribute__((swift_name("onClose")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Apollo_runtimeWsFrameType")))
@interface SharedApollo_runtimeWsFrameType : SharedKotlinEnum<SharedApollo_runtimeWsFrameType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedApollo_runtimeWsFrameType *text __attribute__((swift_name("text")));
@property (class, readonly) SharedApollo_runtimeWsFrameType *binary __attribute__((swift_name("binary")));
+ (SharedKotlinArray<SharedApollo_runtimeWsFrameType *> *)values __attribute__((swift_name("values()")));
@property (class, readonly) NSArray<SharedApollo_runtimeWsFrameType *> *entries __attribute__((swift_name("entries")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
